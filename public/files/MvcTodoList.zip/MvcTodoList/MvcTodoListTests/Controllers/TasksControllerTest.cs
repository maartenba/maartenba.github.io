﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MvcTodoList;
using MvcTodoList.Controllers;
using MvcTodoList.Models;
using MvcTodoList.Domain;
using MvcTodoList.Business;
using MvcTodoListTests.Mock;

namespace MvcTodoListTests.Controllers
{
    /// <summary>
    /// Summary description for TasksControllerTest
    /// </summary>
    [TestClass]
    public class TasksControllerTest
    {
        [TestMethod]
        public void All()
        {
            // Setup
            TasksController controller = new TasksController();
            controller.TaskManager = new MockTaskManager();

            // Execute
            ViewResult result = controller.All() as ViewResult;

            // Verify
            ViewDataDictionary viewData = result.ViewData;
            AllTasksModel model = viewData.Model as AllTasksModel;
            Assert.AreEqual("Overview of tasks", model.Title);
            Assert.AreEqual(2, model.Tasks.Count);
        }

        [TestMethod]
        public void Details()
        {
            // Setup
            TasksController controller = new TasksController();
            controller.TaskManager = new MockTaskManager();

            // Execute
            ViewResult result = controller.Details(new Guid("F883BEED-F034-472f-82D3-A0C5C1C0E0D4")) as ViewResult;

            // Verify
            ViewDataDictionary viewData = result.ViewData;
            SingleTaskModel model = viewData.Model as SingleTaskModel;
            Assert.AreEqual("Test task 1", model.Title);
        }

        [TestMethod]
        public void Edit()
        {
            // Setup
            TasksController controller = new TasksController();
            controller.TaskManager = new MockTaskManager();

            // Execute
            ViewResult result = controller.Edit(new Guid("F883BEED-F034-472f-82D3-A0C5C1C0E0D4")) as ViewResult;

            // Verify
            ViewDataDictionary viewData = result.ViewData;
            SingleTaskModel model = viewData.Model as SingleTaskModel;
            Assert.AreEqual("Test task 1", model.Title);
        }

        [TestMethod]
        public void Update()
        {
            // Setup
            TasksController controller = new TasksController();
            controller.TaskManager = new MockTaskManager();

            // Execute
            controller.Update(new Guid("F883BEED-F034-472f-82D3-A0C5C1C0E0D4"), "New title", "New description");

            // Verify
            MockTaskManager manager = controller.TaskManager as MockTaskManager;
            Assert.AreEqual("New title",  manager.LastUpdate.Title);
        }
    }
}
