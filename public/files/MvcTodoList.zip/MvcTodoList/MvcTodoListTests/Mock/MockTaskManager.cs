﻿using System;
using System.Collections.Generic;
using System.Linq;
using MvcTodoList.Business;
using MvcTodoList.Data;
using MvcTodoList.Domain;

namespace MvcTodoListTests.Mock
{
    public class MockTaskManager : ITaskManager
    {
        #region Example data

        private List<Task> data;

        private void CreateDummyData()
        {
            data = new List<Task>
            {
                new Task {
                    Id = new Guid("F883BEED-F034-472f-82D3-A0C5C1C0E0D4"),
                    UserId   = Guid.Empty,
                    Title = "Test task 1",
                    Description = "Test task 1 description",
                    CreatedDate = new DateTime(2008,07,22),
                    DueDate = new DateTime(2008,07,31),
                    Completed = false
                },
                new Task {
                    Id = new Guid("DAF7D8E9-FCE2-481f-AC1F-7072C4B55950"),
                    UserId   = Guid.Empty,
                    Title = "Test task 2",
                    Description = "Test task 2 description",
                    CreatedDate = new DateTime(2008,07,22),
                    DueDate = new DateTime(2008,07,31),
                    Completed = true
                }
            };
        }

        public MockTaskManager()
        {
            CreateDummyData();
        }

        #endregion

        #region Test verification 

        public Task LastUpdate { get; set; }
        public Task LastInsert { get; set; }
        public Task LastDelete { get; set; }

        #endregion

        #region ITaskManager Members

        public TodoListDataContext DataContext {
            get { return null; }
            set { }
        }

        public Task RetrieveTask(Guid id)
        {
            return data.SingleOrDefault(t => t.Id == id);
        }

        public List<Task> RetrieveAllTasks()
        {
            return data.ToList();
        }

        public List<Task> RetrieveAllIncompleteTasks()
        {
            return data.Where(t => t.Completed == false).ToList();
        }

        public List<Task> RetrieveAllCompleteTasks()
        {
            return data.Where(t => t.Completed == true).ToList();
        }

        public void CreateTask(Task task)
        {
            if (!task.CreatedDate.HasValue)
                task.CreatedDate = DateTime.Now;

            LastInsert = task;
        }

        public void UpdateTask(Task task)
        {
            LastUpdate = task;
        }

        public void CompleteTask(Guid id)
        {
            CompleteTask(id, true);
        }

        public void CompleteTask(Guid id, bool complete)
        {
            Task task = RetrieveTask(id);
            CompleteTask(task, complete);
        }

        public void CompleteTask(Task task)
        {
            CompleteTask(task, true);
        }

        public void CompleteTask(Task task, bool complete)
        {
            task.Completed = complete;
            UpdateTask(task);
        }

        public void DeleteTask(Task task)
        {
            data.Remove(task);
            LastDelete = task;
        }

        #endregion
    }
}
