﻿using System;
using System.Collections.Generic;
using MvcTodoList.Data;
using MvcTodoList.Domain;

namespace MvcTodoList.Business
{
    public interface ITaskManager
    {
        void CompleteTask(Guid id);
        void CompleteTask(Guid id, bool complete);
        void CompleteTask(Task task, bool complete);
        void CompleteTask(Task task);
        void CreateTask(Task task);
        TodoListDataContext DataContext { get; set; }
        Task RetrieveTask(Guid id);
        List<Task> RetrieveAllTasks();
        List<Task> RetrieveAllIncompleteTasks();
        List<Task> RetrieveAllCompleteTasks();
        void UpdateTask(Task task);
        void DeleteTask(Task task);
    }
}
