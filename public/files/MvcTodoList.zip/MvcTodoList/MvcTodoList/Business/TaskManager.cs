﻿using System;
using System.Linq;
using MvcTodoList.Data;
using MvcTodoList.Domain;
using System.Collections.Generic;

namespace MvcTodoList.Business
{
    public class TaskManager : ITaskManager
    {
        public TodoListDataContext DataContext { get; set; }

        public Task RetrieveTask(Guid id)
        {
            return DataContext.Tasks.SingleOrDefault(t => t.Id == id);
        }

        public List<Task> RetrieveAllTasks()
        {
            return DataContext.Tasks.ToList();
        }

        public List<Task> RetrieveAllIncompleteTasks()
        {
            return DataContext.Tasks.Where(t => t.Completed == false).ToList();
        }

        public List<Task> RetrieveAllCompleteTasks()
        {
            return DataContext.Tasks.Where(t => t.Completed == true).ToList();
        }

        public void CreateTask(Task task)
        {
            if (!task.CreatedDate.HasValue)
                task.CreatedDate = DateTime.Now;

            DataContext.Tasks.Attach(task);
            DataContext.SubmitChanges();
        }

        public void UpdateTask(Task task)
        {
            DataContext.SubmitChanges();
        }

        public void CompleteTask(Guid id)
        {
            CompleteTask(id, true);
        }

        public void CompleteTask(Guid id, bool complete)
        {
            Task task = RetrieveTask(id);
            CompleteTask(task, complete);
        }

        public void CompleteTask(Task task)
        {
            CompleteTask(task, true);
        }

        public void CompleteTask(Task task, bool complete)
        {
            task.Completed = complete;
            UpdateTask(task);
        }

        public void DeleteTask(Task task)
        {
            DataContext.Tasks.DeleteOnSubmit(task);
            DataContext.SubmitChanges();
        }
    }
}
