namespace MvcTodoList.Domain
{
    public partial class Task
    {
    }
}
