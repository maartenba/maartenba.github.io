﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcTodoList.Models;

namespace MvcTodoList.Views.Tasks
{
    public partial class All : ViewPage<AllTasksModel>
    {
    }
}
