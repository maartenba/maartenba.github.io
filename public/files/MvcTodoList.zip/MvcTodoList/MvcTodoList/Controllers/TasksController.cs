﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcTodoList.Domain;
using MvcTodoList.Data;
using MvcTodoList.Business;
using MvcTodoList.Models;

namespace MvcTodoList.Controllers
{
    public class TasksController : Controller
    {
        private ITaskManager taskManager;

        public ITaskManager TaskManager {
            get {
                if (taskManager == null)
                {
                    taskManager = new TaskManager();
                    taskManager.DataContext = new TodoListDataContext();
                }
                return taskManager; 
            }
            set { taskManager = value; }
        }

        // /Tasks/Index
        public ActionResult Index()
        {
            return All();
        }

        // /Tasks/All
        public ActionResult All()
        {
            List<Task> tasks = null;

            // Fetch data
            tasks = TaskManager.RetrieveAllTasks();

            AllTasksModel viewData = new AllTasksModel
            {
                Title = "Overview of tasks",
                Tasks = tasks
            };

            return View("All", viewData);
        }

        // /Tasks/Details/....
        public ViewResult Details(Guid guid)
        {
            Task task = TaskManager.RetrieveTask(guid);

            SingleTaskModel viewData = new SingleTaskModel
            {
                Title = task.Title,
                Task = task
            };

            return View("Details", viewData);
        }

        // /Tasks/Edit/....
        public ViewResult Edit(Guid guid)
        {
            Task task = TaskManager.RetrieveTask(guid);

            SingleTaskModel viewData = new SingleTaskModel
            {
                Title = task.Title,
                Task = task
            };

            return View("Edit", viewData);
        }

        public RedirectToRouteResult Update(Guid guid, string title, string description)
        {
            Task t = TaskManager.RetrieveTask(guid);
            t.Title = title;
            t.Description = description;

            TaskManager.UpdateTask(t);

            return RedirectToAction("All");
        }
    }
}
