﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcTodoList.Domain;
using MvcTodoList.Data;
using MvcTodoList.Business;

namespace MvcTodoList.Controllers
{
    public class TaskController : Controller
    {
        public ActionResult Index()
        {
            return All();
        }

        public ActionResult All()
        {
            List<Task> tasks = null;
            using (TodoListDataContext context = new TodoListDataContext())
            {
                // Set up task manager
                ITaskManager manager = new TaskManager();
                manager.DataContext = context;
            }

            ViewData["tasks"] = tasks;

            return View("All");
        }
    }
}
