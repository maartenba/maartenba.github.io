﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;
using LinqToTwitter;
using SignalR;
using SignalR.Hosting.AspNet;
using SignalR.Hosting.AspNet.Routing;
using SignalR.Hubs;
using SignalR.Infrastructure;

namespace WebApplication2
{
    [HubName("worker")]
    public class WorkerHub
        : Hub
    {
        public void StartProcessing(Person p)
        {
            Caller.notify("We've started processing, " + p.Name);
            Clients.setProgress(0);

            for (int i = 0; i <= 100; i++)
            {
                Clients.setProgress(i);
                if (i <= 50)
                {
                    Thread.Sleep(100);
                }
                else if (i <= 60)
                {
                    Thread.Sleep(150);
                }
                else if (i <= 95)
                {
                    Thread.Sleep(50);
                }
                else
                {
                    Thread.Sleep(1000);
                }
            }

            Caller.notify("And we're done!");
        }
    }

    public class Person
    {
        public string Name { get; set; }
    }

    public class TweetsConnection
        : PersistentConnection
    {
    }

    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            RouteTable.Routes.MapConnection<TweetsConnection>("tweets", "tweets/{*operation}");

            ThreadPool.QueueUserWorkItem(_ =>
                                             {
                                                 var connectionManager = AspNetHost.DependencyResolver.Resolve<IConnectionManager>();
                                                 var connection = connectionManager.GetConnection<TweetsConnection>();

                                                 while (true)
                                                 {
                                                     using (TwitterContext context = new TwitterContext())
                                                     {
                                                         var tweets = context.Search.Where(t => t.Type == SearchType.Search && t.Query == "#guquotes")
                                                             .SingleOrDefault().Results;

                                                         connection.Broadcast(tweets);
                                                     }

                                                     System.Threading.Thread.Sleep(1000);
                                                 }
                                             });
        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}