﻿using System.Web.Mvc;
using DeckCast.Models;

namespace DeckCast.Controllers
{
    public class DeckController : Controller
    {
        private IDeckRepository _deckRepository;

        public DeckController()
        {
            _deckRepository = new DeckRepository();
        }

        public ActionResult View(string id)
        {
            var model = _deckRepository.GetDeck(id);

            return View(model);
        }

        public ActionResult Present(string id)
        {
            var model = _deckRepository.GetDeck(id);

            return View(model);
        }
    }
}
