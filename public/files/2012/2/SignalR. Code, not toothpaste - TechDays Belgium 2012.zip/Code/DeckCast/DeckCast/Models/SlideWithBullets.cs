using System.Collections.Generic;

namespace DeckCast.Models
{
    public class SlideWithBullets : Slide
    {
        public SlideWithBullets()
        {
            Bullets = new List<string>();
        }

        public List<string> Bullets { get; set; }
    }
}