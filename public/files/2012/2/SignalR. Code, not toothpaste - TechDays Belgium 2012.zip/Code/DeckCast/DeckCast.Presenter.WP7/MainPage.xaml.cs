﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using SignalR.Client.Hubs;

namespace DeckCast.Presenter.WP7
{
    public partial class MainPage : PhoneApplicationPage
    {
        private HubConnection connection;
        private IHubProxy presentationHub;
        private int slide;

        // Constructor
        public MainPage()
        {
            InitializeComponent();
            this.Loaded += (sender, args) =>
                               {
                                   connection = new HubConnection("http://localhost:56285/");
                                   presentationHub = connection.CreateProxy("DeckCast.Hubs.PresentationHub");
                                   presentationHub.On<int>("showSlide", slideId =>
                                   {
                                       Dispatcher.BeginInvoke(() =>
                                       {
                                           slide = slideId;
                                           SlideId.Text = slideId.ToString();
                                       });
                                   });
                                   connection.Start();
                               };
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (slide > 0)
            {
                presentationHub.Invoke("GotoSlide", --slide).Start();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            presentationHub.Invoke("GotoSlide", ++slide).Start();
        }

        private void DeckId_LostFocus(object sender, RoutedEventArgs e)
        {
            slide = 0;

            presentationHub.Invoke("Join", DeckId.Text)
                .ContinueWith(result => presentationHub.Invoke("GotoSlide", slide));
        }
    }
}