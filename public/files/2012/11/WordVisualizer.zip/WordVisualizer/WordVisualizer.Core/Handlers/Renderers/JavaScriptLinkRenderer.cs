﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WordVisualizer.Core.Extensions;

namespace WordVisualizer.Core.Handlers.Renderers
{
    /// <summary>
    /// JavaScript link renderer
    /// </summary>
    public class JavaScriptLinkRenderer : IWordDocumentRenderer
    {
        #region Private static properties

        private static JavaScriptLinkRenderer instance;

        #endregion

        #region Private constructor

        /// <summary>
        /// Default constructor
        /// </summary>
        private JavaScriptLinkRenderer() { }

        #endregion

        #region Static properties

        /// <summary>
        /// Current JavaScriptLinkRenderer instance
        /// </summary>
        public static JavaScriptLinkRenderer Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new JavaScriptLinkRenderer();
                }
                return instance;
            }
        }

        #endregion

        #region IWordDocumentRenderer Members

        /// <summary>
        /// Render
        /// </summary>
        /// <param name="context">Current http context</param>
        public void Render(System.Web.HttpContext context)
        {
            if (!string.IsNullOrEmpty(WordVisualizerSettings.Default.UseJavaScriptFile))
            {
                string jsPath = WordVisualizerSettings.Default.UseJavaScriptFile.Replace("~", context.Request.ApplicationPath);
                context.Response.WriteLine("<script type=\"text/javascript\" src=\"" + jsPath + "\"></script>");
            }
        }

        #endregion
    }
}
