﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using WordVisualizer.Core.Extensions;

namespace WordVisualizer.Core.Handlers.Renderers
{
    /// <summary>
    /// Default renderer
    /// </summary>
    public class DefaultRenderer : IWordDocumentRenderer
    {
        #region IWordDocumentRenderer Members

        /// <summary>
        /// Render
        /// </summary>
        /// <param name="context">Current http context</param>
        public void Render(System.Web.HttpContext context)
        {
            // Set content type
            context.Response.ContentType = "text/html";

            // Set response code
            context.Response.StatusCode = 200;

            // Render
            context.Response.WriteLine(@"<html>");

            context.Response.WriteLine(@"  <head>");
            context.Response.WriteLine(@"    <title>WordVisualizer</title>");
            CssLinkRenderer.Instance.Render(context);
            context.Response.WriteLine(@"  </head>");

            context.Response.WriteLine(@"  <body>");
            context.Response.WriteLine(@"    <h1>WordVisualizer</h1>");
            context.Response.WriteLine("     <p>WordVisualizer - &copy; <a href=\"http://blog.maartenballiauw.be\">Maarten Balliauw</a> 2008</p>");
            context.Response.WriteLine(@"  </body>");

            context.Response.WriteLine(@"</html>");
        }

        #endregion
    }
}
