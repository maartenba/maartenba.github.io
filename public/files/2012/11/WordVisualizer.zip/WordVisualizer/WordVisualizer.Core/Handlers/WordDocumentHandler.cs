﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.IO;
using WordVisualizer.Core.Handlers.Renderers;

namespace WordVisualizer.Core.Handlers
{
    /// <summary>
    /// Word document HTTP handler
    /// </summary>
    public class WordDocumentHandler : IHttpHandler
    {
        #region IHttpHandler Members

        /// <summary>
        /// Is the handler reusable?
        /// </summary>
        public bool IsReusable
        {
            get { return true; }
        }

        /// <summary>
        /// Process request
        /// </summary>
        /// <param name="context">Current http context</param>
        public void ProcessRequest(HttpContext context)
        {
            // Renderer
            IWordDocumentRenderer renderer = null;

            try
            {
                // Parameters
                DisplayMode displayMode = DisplayMode.Display;
                string virtualFilePath = context.Request["filename"] ?? context.Request.FilePath;
                string relationShipId = context.Request["partrelationship"] ?? "";

                // Fetch real path
                virtualFilePath = virtualFilePath.Replace("\\", "/");
                if (!virtualFilePath.StartsWith(context.Request.ApplicationPath))
                {
                    virtualFilePath = context.Request.ApplicationPath + "/" + virtualFilePath;
                }
                string realPath = context.Server.MapPath(virtualFilePath);

                // Check if file exists
                if (!File.Exists(realPath))
                {
                    throw new FileNotFoundException("File not found.", virtualFilePath);
                }

                // Verify "mode" parameter
                if (!string.IsNullOrEmpty(context.Request["mode"]))
                {
                    switch (context.Request["mode"].ToLower())
                    {
                        case "display":
                            displayMode = DisplayMode.Display;
                            break;
                        case "download":
                            displayMode = DisplayMode.Download;
                            break;
                        case "renderpart":
                            displayMode = DisplayMode.RenderPart;
                            break;
                    }
                }

                // Take action
                switch (displayMode)
                {
                    case DisplayMode.RenderPart:
                        renderer = new RelationshipPartRenderer
                        {
                            FileName = realPath,
                            RelationshipId = relationShipId
                        };
                        break;
                    case DisplayMode.Download:
                        renderer = new WordDocumentFileRenderer
                        {
                            FileName = realPath,
                            ContentType = "application/vnd.ms-word.document.12"
                        };
                        break;
                    case DisplayMode.Display:
                    default:
                        renderer = new WordDocumentDisplayRenderer
                        {
                            FileName = realPath,
                            ContentType = "text/html"
                        };
                        break;
                }
            }
            catch (FileNotFoundException fileNotFoundException)
            {
                renderer = new FileNotFoundExceptionRenderer
                {
                    Exception = fileNotFoundException
                };
            }
            catch (Exception exception)
            {
                renderer = new ExceptionRenderer
                {
                    Exception = exception
                };
            }
            finally
            {
                // Render
                if (renderer == null)
                {
                    renderer = new DefaultRenderer();
                }
                renderer.Render(context);
            }
        }

        #endregion
    }
}
