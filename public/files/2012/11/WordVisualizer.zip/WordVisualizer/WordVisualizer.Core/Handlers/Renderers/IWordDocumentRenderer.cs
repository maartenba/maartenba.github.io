﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace WordVisualizer.Core.Handlers.Renderers
{
    /// <summary>
    /// Word document renderer
    /// </summary>
    public interface IWordDocumentRenderer
    {
        /// <summary>
        /// Render
        /// </summary>
        /// <param name="context">Current http context</param>
        void Render(HttpContext context);
    }
}
