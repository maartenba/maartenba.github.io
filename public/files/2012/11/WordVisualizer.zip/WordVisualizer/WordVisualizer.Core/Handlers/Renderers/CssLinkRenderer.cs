﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WordVisualizer.Core.Extensions;

namespace WordVisualizer.Core.Handlers.Renderers
{
    /// <summary>
    /// Css link renderer
    /// </summary>
    public class CssLinkRenderer : IWordDocumentRenderer
    {
        #region Private static properties

        private static CssLinkRenderer instance;

        #endregion

        #region Private constructor

        /// <summary>
        /// Default constructor
        /// </summary>
        private CssLinkRenderer() { }

        #endregion

        #region Static properties

        /// <summary>
        /// Current CssLinkRenderer instance
        /// </summary>
        public static CssLinkRenderer Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new CssLinkRenderer();
                }
                return instance;
            }
        }

        #endregion

        #region IWordDocumentRenderer Members

        /// <summary>
        /// Render
        /// </summary>
        /// <param name="context">Current http context</param>
        public void Render(System.Web.HttpContext context)
        {
            if (!string.IsNullOrEmpty(WordVisualizerSettings.Default.UseCssFile))
            {
                string cssPath = WordVisualizerSettings.Default.UseCssFile.Replace("~", context.Request.ApplicationPath);
                context.Response.WriteLine("<link type=\"text/css\" rel=\"Stylesheet\" href=\"" + cssPath + "\" />");
            }
        }

        #endregion
    }
}
