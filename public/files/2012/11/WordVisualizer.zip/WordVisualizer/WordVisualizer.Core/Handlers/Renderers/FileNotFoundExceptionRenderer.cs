﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using WordVisualizer.Core.Extensions;

namespace WordVisualizer.Core.Handlers.Renderers
{
    /// <summary>
    /// FileNotFoundException renderer
    /// </summary>
    public class FileNotFoundExceptionRenderer : IExceptionRenderer
    {
        #region IExceptionRenderer Members

        /// <summary>
        /// Exception to render
        /// </summary>
        public Exception Exception{ get; set;}

        #endregion

        #region IWordDocumentRenderer Members

        /// <summary>
        /// Render
        /// </summary>
        /// <param name="context">Current http context</param>
        public void Render(System.Web.HttpContext context)
        {
            // Set content type
            context.Response.ContentType = "text/html";

            // Set response code
            context.Response.StatusCode = 404;

            // Render
            context.Response.WriteLine(@"<html>");

            context.Response.WriteLine(@"  <head>");
            context.Response.WriteLine(@"    <title>File not found</title>");
            CssLinkRenderer.Instance.Render(context);
            context.Response.WriteLine(@"  </head>");

            context.Response.WriteLine(@"  <body>");
            context.Response.WriteLine(@"    <h1>File not found</h1>");
            context.Response.WriteLine(@"    <p>The file <em>" + (Exception as FileNotFoundException).FileName + "</em> was not found on this server.</p>");
            context.Response.WriteLine(@"    <p>Please verify that you spelled the filename correctly.</p>");
            WhiteSpaceRenderer.Instance.Render(context);
            context.Response.WriteLine(@"  </body>");

            context.Response.WriteLine(@"</html>");
        }

        #endregion
    }
}
