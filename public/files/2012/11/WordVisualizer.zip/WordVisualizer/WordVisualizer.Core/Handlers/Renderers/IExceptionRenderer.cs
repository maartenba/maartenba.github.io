﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace WordVisualizer.Core.Handlers.Renderers
{
    /// <summary>
    /// Exception renderer
    /// </summary>
    public interface IExceptionRenderer : IWordDocumentRenderer
    {
        /// <summary>
        /// Exception to render
        /// </summary>
        Exception Exception { get; set; }
    }
}
