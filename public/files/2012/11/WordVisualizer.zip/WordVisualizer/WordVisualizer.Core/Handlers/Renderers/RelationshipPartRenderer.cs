﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Microsoft.Office.DocumentFormat.OpenXml.Packaging;
using System.Drawing;

namespace WordVisualizer.Core.Handlers.Renderers
{
    /// <summary>
    /// Relationship part renderer
    /// </summary>
    public class RelationshipPartRenderer : IFileRenderer
    {
        #region Public properties

        /// <summary>
        /// Relationship id to render
        /// </summary>
        public string RelationshipId { get; set; }

        #endregion

        #region IFileRenderer Members

        /// <summary>
        /// FileName
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// ContentType
        /// </summary>
        public string ContentType { get; set; }

        #endregion

        #region IWordDocumentRenderer Members

        /// <summary>
        /// Render
        /// </summary>
        /// <param name="context">Current http context</param>
        public void Render(System.Web.HttpContext context)
        {
            // Open document
            using (WordprocessingDocument document = WordprocessingDocument.Open(FileName, false))
            {
                // Fetch document part
                OpenXmlPart partToRender = document.MainDocumentPart.GetPartById(RelationshipId);

                // Part found?
                if (partToRender != null)
                {
                    // Set response code
                    context.Response.StatusCode = 200;

                    // Set content type
                    context.Response.ContentType = partToRender.ContentType;

                    // Render to output stream
                    byte[] outputBytes = new byte[partToRender.GetStream().Length];
                    partToRender.GetStream().Read(outputBytes, 0, outputBytes.Length);
                    context.Response.BinaryWrite(outputBytes);
                }
                else
                {
                    // Render Exception...
                    IWordDocumentRenderer innerRenderer = new ExceptionRenderer
                    {
                        Exception = new FileNotFoundException("Part not found in document.", RelationshipId)
                    };
                    innerRenderer.Render(context);
                }
            }
        }

        #endregion
    }
}
