﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace WordVisualizer.Core.Handlers.Renderers
{
    /// <summary>
    /// Word document file renderer
    /// </summary>
    public class WordDocumentFileRenderer : IFileRenderer
    {
        #region IFileRenderer Members

        /// <summary>
        /// FileName
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// ContentType
        /// </summary>
        public string ContentType { get; set; }

        #endregion

        #region IWordDocumentRenderer Members

        /// <summary>
        /// Render
        /// </summary>
        /// <param name="context">Current http context</param>
        public void Render(System.Web.HttpContext context)
        {
            // Set content type
            if (string.IsNullOrEmpty(ContentType))
            {
                ContentType = "application/vnd.ms-word.document.12";
            }
            context.Response.ContentType = ContentType;

            // Set response code
            context.Response.StatusCode = 200;

            // Add extra header
            context.Response.AddHeader("content-disposition", "attachment; filename=" + Path.GetFileName(FileName));
            
            // Render
            context.Response.TransmitFile(FileName);
        }

        #endregion
    }
}
