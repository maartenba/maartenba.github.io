﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using WordVisualizer.Core.Extensions;

namespace WordVisualizer.Core.Handlers.Renderers
{
    /// <summary>
    /// Exception renderer
    /// </summary>
    public class ExceptionRenderer : IExceptionRenderer
    {
        #region IExceptionRenderer Members

        /// <summary>
        /// Exception to render
        /// </summary>
        public Exception Exception{ get; set;}

        #endregion

        #region IWordDocumentRenderer Members

        /// <summary>
        /// Render
        /// </summary>
        /// <param name="context">Current http context</param>
        public void Render(System.Web.HttpContext context)
        {
            // Set content type
            context.Response.ContentType = "text/html";

            // Set response code
            context.Response.StatusCode = 500;

            // Render
            context.Response.WriteLine(@"<html>");

            context.Response.WriteLine(@"  <head>");
            context.Response.WriteLine(@"    <title>An error has occurred...</title>");
            CssLinkRenderer.Instance.Render(context);
            context.Response.WriteLine(@"  </head>");

            context.Response.WriteLine(@"  <body>");
            context.Response.WriteLine(@"    <h1>An error has occurred...</h1>");
            context.Response.WriteLine(@"    <p>The following error has occurred:</p>");
            context.Response.WriteLine(@"    <p>Message: <em>" + (Exception as Exception).Message + "</em></p>");
            context.Response.WriteLine(@"    <p>Please try again.</p>");
            WhiteSpaceRenderer.Instance.Render(context);
            context.Response.WriteLine(@"  </body>");

            context.Response.WriteLine(@"</html>");
        }

        #endregion
    }
}
