﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace WordVisualizer.Core.Handlers.Renderers
{
    /// <summary>
    /// File renderer
    /// </summary>
    public interface IFileRenderer : IWordDocumentRenderer
    {
        /// <summary>
        /// FileName
        /// </summary>
        string FileName { get; set; }

        /// <summary>
        /// ContentType
        /// </summary>
        string ContentType { get; set; }
    }
}
