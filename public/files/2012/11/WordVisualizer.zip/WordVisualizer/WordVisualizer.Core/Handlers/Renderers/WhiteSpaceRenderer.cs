﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WordVisualizer.Core.Extensions;

namespace WordVisualizer.Core.Handlers.Renderers
{
    /// <summary>
    /// WhiteSpace renderer
    /// </summary>
    public class WhiteSpaceRenderer : IWordDocumentRenderer
    {
        #region Private static properties

        private static WhiteSpaceRenderer instance;

        #endregion

        #region Private constructor

        /// <summary>
        /// Default constructor
        /// </summary>
        private WhiteSpaceRenderer() { }

        #endregion

        #region Static properties

        /// <summary>
        /// Current WhiteSpaceRenderer instance
        /// </summary>
        public static WhiteSpaceRenderer Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new WhiteSpaceRenderer();
                }
                return instance;
            }
        }

        #endregion

        #region IWordDocumentRenderer Members

        /// <summary>
        /// Render
        /// </summary>
        /// <param name="context">Current http context</param>
        public void Render(System.Web.HttpContext context)
        {
            context.Response.WriteLine();
            context.Response.WriteLine("<!--");
            context.Response.WriteLine("  --------------------------------------------------");
            context.Response.WriteLine("  Internet Explorer prevents custom error pages from");
            context.Response.WriteLine("  showing when there is not enough data passed.");
            context.Response.WriteLine();
            context.Response.WriteLine("  This comment helps to solve the above problem.");
            context.Response.WriteLine("  --------------------------------------------------");
            context.Response.WriteLine("-->");
        }

        #endregion
    }
}
