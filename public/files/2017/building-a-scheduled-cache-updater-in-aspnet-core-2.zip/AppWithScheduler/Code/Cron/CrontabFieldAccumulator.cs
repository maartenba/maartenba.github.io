﻿namespace AppWithScheduler.Code
{
    public delegate void CrontabFieldAccumulator(int start, int end, int interval);
}