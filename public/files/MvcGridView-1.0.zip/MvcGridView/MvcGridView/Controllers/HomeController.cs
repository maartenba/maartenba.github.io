﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcGridView.Code;
using MvcGridView.Models;

namespace MvcGridView.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        private const string SessionKeyEmployees = "HomeController_Employees";
        private const string SessionKeyCurrentPage = "HomeController_CurrentPage";

        private List<Employee> Employees
        {
            get
            {
                if (Session[SessionKeyEmployees] == null)
                {
                    Session[SessionKeyEmployees] = new List<Employee>{
                        new Employee { Id = 0, Name = "Maarten", Email = "maarten@example.com" },
                        new Employee { Id = 1, Name = "Alan", Email = "alan@example.com" },
                        new Employee { Id = 2, Name = "Scott", Email = "scott@example.com" },
                        new Employee { Id = 3, Name = "Andy", Email = "andy@example.com" },
                        new Employee { Id = 4, Name = "Joe", Email = "joe@example.com" },
                        new Employee { Id = 5, Name = "Troy", Email = "troy@example.com" }
                    };
                }
                return Session[SessionKeyEmployees] as List<Employee>;
            }
            set
            {
                Session[SessionKeyEmployees] = value;
            }
        }

        private int CurrentPage
        {
            get
            {
                if (Session[SessionKeyCurrentPage] == null)
                {
                    Session[SessionKeyCurrentPage] = 0;
                }
                return int.Parse(Session[SessionKeyCurrentPage].ToString());
            }
            set
            {
                Session[SessionKeyCurrentPage] = value;
            }
        }

        public ActionResult Reset()
        {
            Session[SessionKeyEmployees] = null;
            Session[SessionKeyCurrentPage] = null;

            return RedirectToAction("Show");
        }

        public ActionResult Index()
        {
            return RedirectToAction("Show");
        }

        public ActionResult Show(int? page)
        {
            CurrentPage = page.HasValue ? page.Value : CurrentPage;

            GridViewData<Employee> viewData = new GridViewData<Employee>
            {
                PagedList = Employees.ToPagedList<Employee>(CurrentPage, 4)
            };

            return View("Index", viewData);
        }

        public ActionResult Edit(int id)
        {
            GridViewData<Employee> viewData = new GridViewData<Employee>
            {
                PagedList = Employees.ToPagedList<Employee>(CurrentPage, 4),
                EditItem = Employees.Where(e => e.Id == id).FirstOrDefault()
            };

            return View("Index", viewData);
        }

        public ActionResult Save(int id, FormCollection form)
        {
            UpdateModel(
                Employees.Where(e => e.Id == id).FirstOrDefault(),
                form.ToValueProvider()
            );

            return RedirectToAction("Show");
        }

        public ActionResult Delete(int id)
        {
            Employees.Remove(
                Employees.Where(e => e.Id == id).FirstOrDefault()
            );

            return RedirectToAction("Show");
        }

        public ActionResult Add(Employee e)
        {
            e.Id = Employees.Count;
            Employees.Add(e);

            return RedirectToAction("Show");
        }
    }
}
