﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using MvcCommentForm.Models;
using Microsoft.Web.Mvc;
using MvcCommentForm.Extensions;

namespace MvcCommentForm.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewData["Title"] = "Home Page";
            ViewData["Message"] = "Welcome to ASP.NET MVC!";

            return View();
        }

        public ActionResult About()
        {
            ViewData["Title"] = "About Page";

            return View();
        }

        [AcceptVerbs("GET")]
        public ActionResult AddComment()
        {
            return View("AddComment", new Comment());
        }

        [AcceptVerbs("POST")]
        public ActionResult AddComment(FormCollection form)
        {
            Comment comment = new Comment();

            this.UpdateModel(comment, new[] { "Name", "Email", "Description" });

            try
            {
                comment.EnsureValid();
            }
            catch (ValidationException validationException)
            {
                this.UpdateModelState(validationException.ValidationIssues, ViewData.ModelState);
            }

            return View("AddComment", comment);
        }
    }
}
