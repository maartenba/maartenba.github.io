﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcCommentForm.Models;

namespace MvcCommentForm.Extensions
{
    public static class ControllerExtensions
    {
        public static void UpdateModelState(this Controller controller, List<ValidationIssue> validationIssues, ModelStateDictionary modelState)
        {
            foreach (var validationIssue in validationIssues)
            {
                modelState.AddModelError(validationIssue.PropertyName, validationIssue.AttemptedValue, validationIssue.Description);
            }
        }
    }
}
