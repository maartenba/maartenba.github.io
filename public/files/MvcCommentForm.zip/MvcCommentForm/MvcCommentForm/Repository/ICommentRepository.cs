﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcCommentForm.Models;

namespace MvcCommentForm.Repository
{
    public interface ICommentRepository
    {
        void AddComment(Comment comment);
    }
}
