﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcCommentForm.Models;

namespace MvcCommentForm.Repository
{
    public class CommentRepository : ICommentRepository
    {
        #region Public properties

        public List<Comment> Comments { get; set; }

        #endregion

        #region ICommentRepository Members

        public void AddComment(Comment comment)
        {
            comment.EnsureValid();

            Comments.Add(comment);
        }

        #endregion
    }
}
