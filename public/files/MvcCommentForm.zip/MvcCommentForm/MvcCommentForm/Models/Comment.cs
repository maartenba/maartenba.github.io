﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcCommentForm.Models
{
    public class Comment
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Description { get; set; }

        public List<ValidationIssue> GetValidationIssues()
        {
            List<ValidationIssue> validationIssues = new List<ValidationIssue>();

            if (string.IsNullOrEmpty(Name))
                validationIssues.Add(new ValidationIssue("Name", Name, "Name should not be empty!"));

            if (string.IsNullOrEmpty(Email))
                validationIssues.Add(new ValidationIssue("Email", Email, "Email should not be empty!"));

            if (string.IsNullOrEmpty(Description))
                validationIssues.Add(new ValidationIssue("Description", Description, "Description should not be empty!"));

            return validationIssues;
        }

        public void EnsureValid()
        {
            List<ValidationIssue> validationIssues = GetValidationIssues();

            if (validationIssues.Count > 0)
                throw new ValidationException("Validation issues", validationIssues);
        }
    }
}
