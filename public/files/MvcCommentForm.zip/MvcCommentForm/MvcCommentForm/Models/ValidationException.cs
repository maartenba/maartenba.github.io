﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcCommentForm.Models
{
    public class ValidationException : Exception
    {
        public List<ValidationIssue> ValidationIssues { get; set; }

        public ValidationException() : base() {}
        public ValidationException(string message) : base(message) {}
        public ValidationException(string message, Exception innerException) : base(message, innerException) { }
        public ValidationException(string message, List<ValidationIssue> validationIssues) : base(message) {
            ValidationIssues = validationIssues;
        }
    }
}
