﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcCommentForm.Models
{
       public class ValidationIssue 
    {
        public string PropertyName { get; set; }
        public string AttemptedValue { get; set; }
        public string Description { get; set; }

        public ValidationIssue(string propertyName, string attemptedValue, string description) {
            PropertyName = propertyName;
            AttemptedValue = attemptedValue;
            Description = description;
        }
    }
}
