﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using MvcChainedControllerFactory.Controllers;

namespace MvcChainedControllerFactory.Code
{
    public class OnlyHomeControllerFactory : IControllerFactory
    {
        public IController CreateController(RequestContext requestContext, string controllerName)
        {
            if (requestContext.RouteData.Values["controller"] != null &&
                requestContext.RouteData.Values["controller"].ToString() == "Home")
            {
                return new HomeController();
            }
            return null;
        }

        public void ReleaseController(IController controller)
        {
            IDisposable disposable = controller as IDisposable;
            if (disposable != null)
                disposable.Dispose();
        }
    }
}
