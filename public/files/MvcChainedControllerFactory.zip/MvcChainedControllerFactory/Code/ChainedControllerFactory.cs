﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace MvcChainedControllerFactory.Code
{
    public class ChainedControllerFactory : IControllerFactory
    {
        const string CHAINEDCONTROLLERFACTORY = "__chainedControllerFactory";

        protected List<IControllerFactory> factories = new List<IControllerFactory>();

        public ChainedControllerFactory Register(IControllerFactory factory)
        {
            factories.Add(factory);
            return this;
        }

        public IController CreateController(RequestContext requestContext, string controllerName)
        {
            IController controller = null;
            foreach (IControllerFactory factory in factories)
            {
                controller = factory.CreateController(requestContext, controllerName);
                if (controller != null)
                {
                    requestContext.HttpContext.Items[CHAINEDCONTROLLERFACTORY] = factory;
                    return controller;
                }
            }

            return null;
        }

        public void ReleaseController(IController controller)
        {
            IControllerFactory factory =
                HttpContext.Current.Items[CHAINEDCONTROLLERFACTORY] as IControllerFactory;
            if (factory != null)
                factory.ReleaseController(controller);
        }
    }
}
