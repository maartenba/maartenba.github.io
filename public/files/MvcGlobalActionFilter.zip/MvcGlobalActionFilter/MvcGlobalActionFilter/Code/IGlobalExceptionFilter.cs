﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcGlobalActionFilter.Code
{
    /// <summary>
    /// Global exception filter
    /// </summary>
    public interface IGlobalExceptionFilter : IGlobalFilter, IExceptionFilter
    {
    }
}
