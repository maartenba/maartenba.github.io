﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcGlobalActionFilter.Code
{
    /// <summary>
    /// Global filter
    /// </summary>
    public interface IGlobalFilter 
    {
        /// <summary>
        /// Determines if the filter should be invoked
        /// </summary>
        /// <param name="controllerContext">Current controller context</param>
        /// <returns>True/false</returns>
        bool ShouldBeInvoked(ControllerContext controllerContext);
    }
}
