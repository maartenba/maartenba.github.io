﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcGlobalActionFilter.Code
{
    public class SampleGlobalTitleFilter : IGlobalResultFilter
    {
        public bool ShouldBeInvoked(System.Web.Mvc.ControllerContext controllerContext)
        {
            return true;
        }

        public void OnResultExecuted(System.Web.Mvc.ResultExecutedContext filterContext)
        {
            return;
        }

        public void OnResultExecuting(System.Web.Mvc.ResultExecutingContext filterContext)
        {
            if (filterContext.Controller.ViewData["PageTitle"] == null)
                filterContext.Controller.ViewData["PageTitle"] = "";

            string pageTitle = filterContext.Controller.ViewData["PageTitle"].ToString();

            if (!string.IsNullOrEmpty(pageTitle))
                pageTitle += " - ";

            pageTitle += "Sample Application";

            filterContext.Controller.ViewData["PageTitle"] = pageTitle;
        }
    }
}
