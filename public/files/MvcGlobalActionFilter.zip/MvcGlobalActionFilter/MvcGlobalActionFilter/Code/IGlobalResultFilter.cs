﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcGlobalActionFilter.Code
{
    /// <summary>
    /// Global result filter
    /// </summary>
    public interface IGlobalResultFilter : IGlobalFilter, IResultFilter
    {
    }
}
