﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcGlobalActionFilter.Code
{
    public class GlobalFilterControllerFactory : DefaultControllerFactory
    {
        protected GlobalFilterActionInvoker actionInvoker;

        public GlobalFilterControllerFactory(GlobalFilterActionInvoker invoker)
        {
            actionInvoker = invoker;
        }

        public override IController CreateController(System.Web.Routing.RequestContext requestContext, string controllerName)
        {
            IController controller = base.CreateController(requestContext, controllerName);
            Controller controllerInstance = controller as Controller;
            if (controllerInstance != null)
            {
                controllerInstance.ActionInvoker = actionInvoker;
            }
            return controller;
        }
    }
}
