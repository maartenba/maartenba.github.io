﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcGlobalActionFilter.Code
{
    /// <summary>
    /// ActionInvoker injecting global filters
    /// </summary>
    public class GlobalFilterActionInvoker : ControllerActionInvoker
    {
        protected FilterInfo globalFilters;

        public GlobalFilterActionInvoker()
        {
            globalFilters = new FilterInfo();
        }

        public GlobalFilterActionInvoker(FilterInfo filters)
        {
            globalFilters = filters;
        }

        public GlobalFilterActionInvoker(List<IGlobalFilter> filters)
            : this(new FilterInfo())
        {
            foreach (var filter in filters)
                RegisterGlobalFilter(filter);
        }

        public FilterInfo Filters
        {
            get { return globalFilters; }
        }

        public void RegisterGlobalFilter(IGlobalFilter filter)
        {
            if (filter is IGlobalAuthorizationFilter)
                globalFilters.AuthorizationFilters.Add((IGlobalAuthorizationFilter)filter);

            if (filter is IGlobalActionFilter)
                globalFilters.ActionFilters.Add((IGlobalActionFilter)filter);

            if (filter is IGlobalResultFilter)
                globalFilters.ResultFilters.Add((IGlobalResultFilter)filter);

            if (filter is IGlobalExceptionFilter)
                globalFilters.ExceptionFilters.Add((IGlobalExceptionFilter)filter);
        }

        protected override FilterInfo GetFilters(ControllerContext controllerContext, ActionDescriptor actionDescriptor)
        {
            FilterInfo definedFilters = base.GetFilters(controllerContext, actionDescriptor);

            foreach (var filter in Filters.AuthorizationFilters)
            {
                IGlobalFilter globalFilter = filter as IGlobalFilter;
                if (globalFilter == null ||
                    (globalFilter != null && globalFilter.ShouldBeInvoked(controllerContext)))
                {
                    definedFilters.AuthorizationFilters.Add(filter);
                }
            }

            foreach (var filter in Filters.ActionFilters)
            {

                IGlobalFilter globalFilter = filter as IGlobalFilter;
                if (globalFilter == null ||
                    (globalFilter != null && globalFilter.ShouldBeInvoked(controllerContext)))
                {
                    definedFilters.ActionFilters.Add(filter);
                }
            }

            foreach (var filter in Filters.ResultFilters)
            {
                IGlobalFilter globalFilter = filter as IGlobalFilter;
                if (globalFilter == null ||
                    (globalFilter != null && globalFilter.ShouldBeInvoked(controllerContext)))
                {
                    definedFilters.ResultFilters.Add(filter);
                }
            }

            foreach (var filter in Filters.ExceptionFilters)
            {
                IGlobalFilter globalFilter = filter as IGlobalFilter;
                if (globalFilter == null ||
                    (globalFilter != null && globalFilter.ShouldBeInvoked(controllerContext)))
                {
                    definedFilters.ExceptionFilters.Add(filter);
                }
            }

            return definedFilters;
        }
    }
}
