﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.Composition;

namespace Mvc3WithMEF.Code
{
    [Export(typeof(IFilterProvider))]
    public class MefFilterAttributeProvider 
        : FilterAttributeFilterProvider
    {
        MefServiceLocator locator;

        [ImportingConstructor]
        public MefFilterAttributeProvider(MefServiceLocator locator)
        {
            this.locator = locator;
        }

        public override IEnumerable<Filter> GetFilters(ControllerContext controllerContext, ActionDescriptor actionDescriptor)
        {
            List<Filter> filters = new List<Filter>();
            filters.AddRange(base.GetFilters(controllerContext, actionDescriptor));
            filters.AddRange(((IFilterProvider)GlobalFilters.Filters).GetFilters(controllerContext, actionDescriptor));

            foreach (var filter in filters)
            {
                locator.Container.ComposeParts(filter.Instance);
                yield return filter;
            }
        }
    }
}