﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition.Hosting;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.ComponentModel.Composition;

namespace Mvc3WithMEF.Code
{
    [Export(typeof(IControllerFactory))]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public class ServiceLocatorControllerFactory
        : DefaultControllerFactory
    {
        private IMvcServiceLocator serviceLocator;

        [ImportingConstructor]
        public ServiceLocatorControllerFactory(IMvcServiceLocator serviceLocator)
        {
            this.serviceLocator = serviceLocator;
        }

        public override IController CreateController(RequestContext requestContext, string controllerName)
        {
            var controllerType = GetControllerType(requestContext, controllerName);
            if (controllerType != null)
            {
                return this.serviceLocator.GetInstance(controllerType) as IController;
            }

            return base.CreateController(requestContext, controllerName);
        }

        public override void ReleaseController(IController controller)
        {
            this.serviceLocator.Release(controller);
        }
    }
}

