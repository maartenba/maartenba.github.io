﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition.Hosting;
using System.ComponentModel.Composition.Primitives;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.Composition;

namespace Mvc3WithMEF.Code
{
    [Export(typeof(IMvcServiceLocator))]
    [Export(typeof(MefServiceLocator))]
    [PartCreationPolicy(CreationPolicy.Shared)]
    public class MefServiceLocator
        : IMvcServiceLocator
    {
        const string HttpContextKey = "__MefServiceLocator_Container";

        private ComposablePartCatalog catalog;
        private IMvcServiceLocator defaultLocator;

        [ImportingConstructor]
        public MefServiceLocator()
        {
            // Get the catalog from the MvcServiceLocator.
            // This is a bit dirty, but currently
            // the only way to ensure one application-wide catalog
            // and a per-request container.
            MefServiceLocator mefServiceLocator = MvcServiceLocator.Current as MefServiceLocator;
            if (mefServiceLocator != null)
            {
                this.catalog = mefServiceLocator.catalog;
            }

            // And the fallback locator...
            this.defaultLocator = MvcServiceLocator.Default;
        }

        public MefServiceLocator(ComposablePartCatalog catalog)
            : this(catalog, MvcServiceLocator.Default)
        {
        }

        public MefServiceLocator(ComposablePartCatalog catalog, IMvcServiceLocator defaultLocator)
        {
            this.catalog = catalog;
            this.defaultLocator = defaultLocator;
        }

        public CompositionContainer Container
        {
            get
            {
                if (!HttpContext.Current.Items.Contains(HttpContextKey))
                {
                    HttpContext.Current.Items.Add(HttpContextKey, new CompositionContainer(catalog));
                }

                return (CompositionContainer)HttpContext.Current.Items[HttpContextKey];
            }
        }

        private object Resolve(Type serviceType, string key = null)
        {
            System.Diagnostics.Debug.WriteLine("Resolve called for serviceType: {0}", serviceType);
            
            var exports = this.Container.GetExports(serviceType, null, null);
            if (exports.Any())
            {
                return exports.First().Value;
            }

            var instance = defaultLocator.GetInstance(serviceType, key);
            if (instance != null)
            {
                return instance;
            }

            throw new ActivationException(string.Format("Could not resolve service type {0}.", serviceType.FullName)); 
        }

        private IEnumerable<object> ResolveAll(Type serviceType)
        {
            System.Diagnostics.Debug.WriteLine("Resolve called for serviceType: {0}", serviceType);

            var exports = this.Container.GetExports(serviceType, null, null);
            if (exports.Any())
            {
                return exports.Select(e => e.Value).AsEnumerable();
            }

            var instances = defaultLocator.GetAllInstances(serviceType);
            if (instances != null)
            {
                return instances;
            }

            throw new ActivationException(string.Format("Could not resolve service type {0}.", serviceType.FullName));
        }

        #region IMvcServiceLocator Members

        public void Release(object instance)
        {
            var export = instance as Lazy<object>;
            if (export != null)
            {
                this.Container.ReleaseExport(export);
            }

            defaultLocator.Release(export);
        }

        #endregion

        #region IServiceLocator Members

        public IEnumerable<object> GetAllInstances(Type serviceType)
        {
            return ResolveAll(serviceType);
        }

        public IEnumerable<TService> GetAllInstances<TService>()
        {
            var instances = ResolveAll(typeof (TService));
            foreach (TService instance in instances)
            {
                yield return (TService)instance;
            }
        }

        public TService GetInstance<TService>(string key)
        {
            return (TService)Resolve(typeof(TService), key);
        }

        public object GetInstance(Type serviceType)
        {
            return Resolve(serviceType);
        }

        public object GetInstance(Type serviceType, string key)
        {
            return Resolve(serviceType, key);
        }

        public TService GetInstance<TService>()
        {
            return (TService)Resolve(typeof(TService));
        }

        #endregion

        #region IServiceProvider Members

        public object GetService(Type serviceType)
        {
            return Resolve(serviceType);
        }

        #endregion
    }
}



