﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.Composition;

namespace Mvc3WithMEF.Code.Sample
{
    public class Settings
    {
        [Export("Title")]
        public string Title { get { return "MEF and MVC3 Sample"; } }
    }

    public class SampleTitleFilterAttribute
        : ActionFilterAttribute
    {
        [Import("Title")]
        public string Title { get; set; }

        public override void OnResultExecuting(ResultExecutingContext filterContext)
        {
            if (filterContext.Controller.ViewData["Title"] != null)
            {
                filterContext.Controller.ViewData["Title"] += " - " + Title;
            }
            else
            {
                filterContext.Controller.ViewData["Title"] = Title;
            }
        }
    }
}