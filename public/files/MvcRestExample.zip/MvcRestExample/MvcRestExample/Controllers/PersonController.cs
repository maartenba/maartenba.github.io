using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using MvcRestExample.Models;
using System.Web.Mvc.Resources;

namespace MvcRestExample.Controllers
{
    [WebApiEnabled]
    public class PersonController : Controller
    {
        protected List<Person> Data
        {
            get
            {
                if (Session["Persons"] == null)
                {
                    Session["Persons"] = new List<Person>();
                }
                return (List<Person>)Session["Persons"];
            }
        }

        //
        // GET: /Person/

        public ActionResult Index()
        {
            return View(Data);
        }

        //
        // GET: /Person/Details/5

        public ActionResult Details(int id)
        {
            return View(Data.FirstOrDefault(p => p.Id == id));
        }

        //
        // GET: /Person/Create

        public ActionResult Create()
        {
            return View(new Person());
        } 

        //
        // POST: /Person/Create

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Create(Person person)
        {
            try
            {
                person.Id = Data.Count + 1;
                Data.Add(person);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Person/Edit/5
 
        public ActionResult Edit(int id)
        {
            return View(Data.FirstOrDefault(p => p.Id == id));
        }

        //
        // POST: /Person/Edit/5

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                Person person = Data.FirstOrDefault(p => p.Id == id);
                UpdateModel(person, new string[] { "FirstName", "LastName" }, collection.ToValueProvider());
 
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
