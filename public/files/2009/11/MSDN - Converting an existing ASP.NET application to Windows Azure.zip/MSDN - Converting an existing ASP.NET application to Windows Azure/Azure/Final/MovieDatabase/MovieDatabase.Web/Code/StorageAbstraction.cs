﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;
using System.IO;

namespace MovieDatabase.Web.Code
{
    public class StorageAbstraction
    {
        CloudBlobContainer container = null;

        public StorageAbstraction()
        {
            CloudStorageAccount account = CloudStorageAccount.FromConfigurationSetting("DataConnectionString");
            CloudBlobClient storage = account.CreateCloudBlobClient();
            container = storage.GetContainerReference("files");

            container.CreateIfNotExist();
        }

        public void Store(string fileName, System.IO.Stream stream)
        {
            container.GetBlockBlobReference(fileName).UploadFromStream(stream);
        }

        public System.IO.Stream Retrieve(string fileName)
        {
            return container.GetBlockBlobReference(fileName).OpenRead();
        }
    }
}
