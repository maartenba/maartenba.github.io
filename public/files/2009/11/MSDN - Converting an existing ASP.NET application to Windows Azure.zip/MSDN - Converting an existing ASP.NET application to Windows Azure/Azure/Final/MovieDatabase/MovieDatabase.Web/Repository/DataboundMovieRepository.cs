﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MovieDatabase.Web.Model;
using Microsoft.WindowsAzure.StorageClient;
using Microsoft.WindowsAzure;

namespace MovieDatabase.Web.Repository
{
    public class DataboundMovieRepository : IDataboundRepository, IMovieRepository
    {
        #region Private members

        MovieEntityContext dataSource = null;

        #endregion

        #region Constructor

        public DataboundMovieRepository()
        {
            CloudStorageAccount account = CloudStorageAccount.FromConfigurationSetting("DataConnectionString");
            dataSource = new MovieEntityContext(account);
            dataSource.RetryPolicy = RetryPolicies.Retry(3, TimeSpan.FromSeconds(1));

            CloudTableClient.CreateTablesFromModel(typeof(MovieEntityContext), account.TableEndpoint.ToString(), account.Credentials);
        }

        #endregion

        #region IDataboundRepository Members

        public MovieEntityContext Datasource
        {
            get { return dataSource; }
        }

        #endregion

        #region IMovieRepository Members

        public List<MovieDatabase.Web.Model.Movie> RetrieveAllMovies()
        {
            List<Movie> movies = Datasource.Movie.ToList();
            List<Director> directors = Datasource.Director.ToList();
            foreach (var movie in movies)
            {
                movie.SetDirector(directors.Where(
                    d => d.RowKey == movie.DirectorRowKey
                    && d.PartitionKey == movie.DirectorPartitionKey)
                    .FirstOrDefault());
            }

            return movies;
        }

        public MovieDatabase.Web.Model.Movie RetrieveMovie(Guid id)
        {
            return RetrieveAllMovies().Where(m => m.RowKey == id.ToString()).FirstOrDefault();
        }

        public void AddMovie(MovieDatabase.Web.Model.Movie movie)
        {
            if (movie.GetDirector() != null && string.IsNullOrEmpty(movie.DirectorRowKey))
            {
                movie.DirectorPartitionKey = movie.GetDirector().PartitionKey;
                movie.DirectorRowKey = movie.GetDirector().RowKey;
            }

            Datasource.AddToMovie(movie);
            Datasource.SaveChanges();
        }

        public void AddDirector(MovieDatabase.Web.Model.Director director)
        {
            Datasource.AddToDirector(director);
            Datasource.SaveChanges();
        }

        #endregion
    }
}
