﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.WindowsAzure.StorageClient;
using Microsoft.WindowsAzure;

namespace MovieDatabase.Web.Model
{
    public class MovieEntityContext : TableServiceContext
    {
        public MovieEntityContext(CloudStorageAccount accountInfo)
            : base(accountInfo.TableEndpoint.ToString(), accountInfo.Credentials)
        {
            this.IgnoreMissingProperties = true;
        }

        internal const string MovieTable = "Movie";
        internal const string DirectorTable = "Director";

        public IQueryable<Movie> Movie
        {
            get
            {
                return this.CreateQuery<Movie>(MovieTable);
            }
        }

        public void AddToMovie(Movie movie)
        {
            this.AddObject(MovieTable, movie);
        }

        public IQueryable<Director> Director
        {
            get
            {
                return this.CreateQuery<Director>(DirectorTable);
            }
        }

        public void AddToDirector(Director director)
        {
            this.AddObject(DirectorTable, director);
        }
    }
}
