﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MovieDatabase.Web.Model;
using MovieDatabase.Web.Repository;
using MovieDatabase.Web.Code;

namespace MovieDatabase.Web
{
    public partial class AddMovie : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (ReleaseDate.SelectedDate == DateTime.MinValue)
                ReleaseDate.SelectedDate = DateTime.Now;
        }

        protected void SaveButton_Click(object sender, EventArgs e)
        {
            // Load repository
            IMovieRepository repository = new DataboundMovieRepository();

            // Upload file
            string photoFileName = TitleValue.Text.ToLower().Replace(" ", "_") + ".jpg";

            StorageAbstraction storage = new StorageAbstraction();
            storage.Store(photoFileName, Photo.FileContent);

            // Build director
            Director director = new Director();
            director.RowKey = Guid.NewGuid().ToString();
            director.Name = Director.Text;

            repository.AddDirector(director);

            // Build movie
            Movie movie = new Movie();
            movie.RowKey = Guid.NewGuid().ToString();
            movie.Title = TitleValue.Text;
            movie.SetDirector(director);
            movie.DateReleased = ReleaseDate.SelectedDate;
            movie.Description = Description.Text;
            movie.Photo = photoFileName;

            repository.AddMovie(movie);

            // Link movie and director
            //repository.AddDirectorToMovie(director, movie);

            // Redirect
            Response.Redirect("~/Default.aspx");
        }
    }
}
