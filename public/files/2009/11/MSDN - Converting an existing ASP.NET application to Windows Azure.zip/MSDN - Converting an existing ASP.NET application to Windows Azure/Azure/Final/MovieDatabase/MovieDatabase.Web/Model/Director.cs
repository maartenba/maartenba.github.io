﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.WindowsAzure.StorageClient;

namespace MovieDatabase.Web.Model
{
    public partial class Director : TableServiceEntity
    {
        public Director()
        {
            PartitionKey = "moviedatabase";
            Timestamp = DateTime.Now;
        }

        public string Name { get; set; }
    }
}
