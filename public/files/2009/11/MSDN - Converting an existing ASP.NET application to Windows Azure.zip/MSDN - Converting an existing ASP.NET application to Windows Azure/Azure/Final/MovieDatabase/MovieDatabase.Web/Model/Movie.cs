﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.WindowsAzure.StorageClient;

namespace MovieDatabase.Web.Model
{
    public partial class Movie : TableServiceEntity
    {
        public Movie()
        {
            PartitionKey = "moviedatabase";
            Timestamp = DateTime.Now;
        }

        public string Title { get; set; }
        public DateTime DateReleased { get; set; }
        public string Description { get; set; }

        protected Director director;
        public Director GetDirector()
        {
            return director;
        }
        public void SetDirector(Director value)
        {
            director = value;
        }

        public string Photo { get; set; }

        public string DirectorName { get { return this.GetDirector().Name; } set { } }


        public string DirectorRowKey { get; set; }
        public string DirectorPartitionKey { get; set; }
    }
}
