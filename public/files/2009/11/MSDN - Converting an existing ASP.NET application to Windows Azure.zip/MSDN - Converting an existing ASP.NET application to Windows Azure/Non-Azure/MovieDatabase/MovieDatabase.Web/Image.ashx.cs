﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MovieDatabase.Web.Repository;
using MovieDatabase.Web.Model;

namespace MovieDatabase.Web
{
    /// <summary>
    /// Summary description for $codebehindclassname$
    /// </summary>
    public class Image : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            // Fetch movie
            IMovieRepository repository = new DataboundMovieRepository();
            Movie movie = repository.RetrieveMovie(
                new Guid(context.Request["id"]));

            // Map image path
            string imagePath = context.Server.MapPath(
                movie.Photo);

            // Stream image
            context.Response.ContentType = "image/jpeg";
            context.Response.WriteFile(imagePath);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}
