﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MovieDatabase.Web.Model;

namespace MovieDatabase.Web.Repository
{
    public interface IMovieRepository
    {
        List<Movie> RetrieveAllMovies();
        Movie RetrieveMovie(Guid id);
        void AddMovie(Movie movie);
        void AddDirector(Director director);
        void AddDirectorToMovie(Director director, Movie movie);
    }
}
