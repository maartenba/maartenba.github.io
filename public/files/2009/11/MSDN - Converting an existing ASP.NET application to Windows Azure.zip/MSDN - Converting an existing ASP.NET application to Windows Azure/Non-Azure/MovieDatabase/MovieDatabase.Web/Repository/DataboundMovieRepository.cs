﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MovieDatabase.Web.Model;

namespace MovieDatabase.Web.Repository
{
    public class DataboundMovieRepository : IDataboundRepository, IMovieRepository
    {
        #region Private members

        MovieDatabaseEntities dataSource = null;

        #endregion

        #region Constructor

        public DataboundMovieRepository()
        {
            dataSource = new MovieDatabaseEntities();
        }

        #endregion

        #region IDataboundRepository Members

        public MovieDatabase.Web.Model.MovieDatabaseEntities Datasource
        {
            get { return dataSource; }
        }

        #endregion

        #region IMovieRepository Members

        public List<MovieDatabase.Web.Model.Movie> RetrieveAllMovies()
        {
            return Datasource.Movie.Include("Director").ToList();
        }

        public MovieDatabase.Web.Model.Movie RetrieveMovie(Guid id)
        {
            return Datasource.Movie.Include("Director").Where(m => m.Id == id).FirstOrDefault();
        }

        public void AddMovie(MovieDatabase.Web.Model.Movie movie)
        {
            Datasource.AddToMovie(movie);
            Datasource.SaveChanges();
        }

        public void AddDirector(MovieDatabase.Web.Model.Director director)
        {
            Datasource.AddToDirector(director);
            Datasource.SaveChanges();
        }

        public void AddDirectorToMovie(MovieDatabase.Web.Model.Director director, MovieDatabase.Web.Model.Movie movie)
        {
            movie.Director = director;
            Datasource.SaveChanges();
        }

        #endregion
    }
}
