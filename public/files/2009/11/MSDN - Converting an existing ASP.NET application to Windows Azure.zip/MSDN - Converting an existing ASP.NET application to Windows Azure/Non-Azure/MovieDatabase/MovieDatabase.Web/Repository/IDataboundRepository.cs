﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MovieDatabase.Web.Model;

namespace MovieDatabase.Web.Repository
{
    public interface IDataboundRepository
    {
        MovieDatabaseEntities Datasource { get; }
    }
}
