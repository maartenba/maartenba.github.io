﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MovieDatabase.Web.Model
{
    public partial class Movie
    {
        public string DirectorName { get { return this.Director.Name; } }
    }
}
