﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RealDolmenMobile.Web.Models
{
    /// <summary>
    /// PostsModel
    /// </summary>
    public class PostModel
    {
        /// <summary>
        /// Gets or sets the title.
        /// </summary>
        /// <value>The title.</value>
        public string Title { get; set; }

        /// <summary>
        /// Gets or sets the body.
        /// </summary>
        /// <value>The body.</value>
        public string Body { get; set; }

        /// <summary>
        /// Gets or sets the published on.
        /// </summary>
        /// <value>The published on.</value>
        public DateTime PublishedOn { get; set; }
    }
}