﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RealDolmenMobile.Web.Models
{
    /// <summary>
    /// ListPostsModel
    /// </summary>
    public class ListPostsModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ListPostsModel"/> class.
        /// </summary>
        public ListPostsModel()
        {
            Posts = new List<PostModel>();
        }

        /// <summary>
        /// Gets or sets the posts.
        /// </summary>
        /// <value>The posts.</value>
        public List<PostModel> Posts { get; set; }
    }
}