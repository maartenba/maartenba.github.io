﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Argotic.Syndication;
using RealDolmenMobile.Web.Models;
using System.Web.Caching;

namespace RealDolmenMobile.Web.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        private static readonly Uri Feed = new Uri("http://microsoft.realdolmenblogs.com/Syndication.axd");

        public ActionResult Index()
        {
            // Create model
            var model = new ListPostsModel();

            GenericSyndicationFeed feed = GenericSyndicationFeed.Create(Feed);
            foreach (GenericSyndicationItem item in feed.Items)
            {
                model.Posts.Add(new PostModel
                {
                    Title = item.Title,
                    Body = item.Summary,
                    PublishedOn = item.PublishedOn
                });
            }

            return View(model);
        }

        public ActionResult Post(string title)
        {
            // Create model
            var model = new PostModel();

            GenericSyndicationFeed feed = GenericSyndicationFeed.Create(Feed);
            foreach (GenericSyndicationItem item in feed.Items)
            {
                if (item.Title == title)
                {
                    model.Title = item.Title;
                    model.Body = item.Summary;
                    model.PublishedOn = item.PublishedOn;
                    break;
                }
            }

            return View(model);
        }
    }
}
