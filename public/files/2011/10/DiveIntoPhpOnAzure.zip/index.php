<?php
/** Requires */
require_once 'library/Microsoft/AutoLoader.php';
require_once 'library/shortenr/AutoLoader.php';
require_once 'configuration.php';

/** Create a repository */
$repository = new shortenr_Repositories_UrlTableStorageRepository($configuration);

/** Determine action to take */
$url = null;
$action = '';
if (isset($_GET['url'])) {
	// Store via repository
	$url = $repository->shortenUrl( trim($_GET['url']) );
	$action = 'created';
} else if (isset($_SERVER['REQUEST_URI']) && strlen($_SERVER['REQUEST_URI']) > 0) {
	// Alias
	$alias = str_replace('index.php', '', str_replace('/', '', trim($_SERVER['REQUEST_URI'])));
	
	if ($alias != '') {
		// Retrieve from repository
		$url = $repository->retrieveUrlFromAlias( $alias );

		// Track visits
		$repository->trackVisitedUrlFromAlias( $alias );
		
		// Redirect
		header('Location: ' . $url->Url);
		exit();
	}
}
?>
<html>
	<head>
		<title>Shortnr - Shortening long URLs to short ones since 1945</title>
		
		<link rel="stylesheet" href="styles.css" type="text/css" media="all" />
		
		<script src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.6.4.min.js" type="text/javascript"></script>
		<script type="text/javascript">
		$(function() {
			$('input:first').focus();
		});
		</script>
	</head>
	<body>
		<div id="container">
			<h1 class="logo">Shortenr</h1>
			<h2>Shortening long URLs to short ones since 1945</h2>
			<?php if ($action == '') { ?>
			<form>
				<input type="text" name="url" class="wide" /><br />
				<input type="submit" value="Shorten" />
				</table>
			</form>
			<?php } else if ($action == 'created') { ?>
			<p>
				Congratulations! We've shortened <a href="<?php echo $url->Url; ?>"><?php echo $url->Url; ?></a>
				into <a href="http://<?php echo $_SERVER["HTTP_HOST"]; ?>/<?php echo $url->Alias; ?>">http://<?php echo $_SERVER["HTTP_HOST"]; ?>/<?php echo $url->Alias; ?></a>.</p>
			<p><a href="/">Create another one!</a>
			<?php }?>
		</div>
	</body>
</html>