<?php
/** Shortenr root directory */
if (!defined('SHORTENR_ROOT')) {
	define('SHORTENR_ROOT', realpath(dirname(__FILE__) . '/../') . DIRECTORY_SEPARATOR);
}
shortenr_AutoLoader::Register();

class shortenr_AutoLoader
{
	public static function Register() {
		return spl_autoload_register(array('shortenr_AutoLoader', 'Load'));
	}
	
	public static function Load($className){
		if ((class_exists($className)) || (strpos($className, 'shortenr') === false)) {
			return false;
		}

		$classFilePath = SHORTENR_ROOT . str_replace('_', DIRECTORY_SEPARATOR, $className) . '.php';
		
		if ((file_exists($classFilePath) === false) || (is_readable($classFilePath) === false)) {
			return false;
		}

		require($classFilePath);
	}
}