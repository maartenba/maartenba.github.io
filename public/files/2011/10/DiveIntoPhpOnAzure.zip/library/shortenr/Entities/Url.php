<?php
class shortenr_Entities_Url
	extends Microsoft_WindowsAzure_Storage_TableEntity {
	/**
	 * @azure Alias
	 */
	public $Alias;
	
	/**
	 * @azure Url
	 */
	public $Url;
	
	/**
	 * @azure Visits Edm.Int64
	 */
	public $Visits;
}