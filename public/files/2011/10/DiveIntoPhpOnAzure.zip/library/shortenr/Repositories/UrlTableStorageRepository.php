<?php
class shortenr_Repositories_UrlTableStorageRepository {
	protected $_tableName = 'shortenr';
	protected $_tableStorageClient = null;
	
	protected $_queueName = 'totrackvisits';
	protected $_queueClient = null;
	
	public function __construct($configuration) {
		$this->_tableStorageClient = new Microsoft_WindowsAzure_Storage_Table($configuration->Storage->TableEndpoint, $configuration->Storage->AccountName, $configuration->Storage->AccountKey);
		$this->_tableStorageClient->createTableIfNotExists($this->_tableName);
		
		$this->_queueClient = new Microsoft_WindowsAzure_Storage_Queue($configuration->Storage->QueueEndpoint, $configuration->Storage->AccountName, $configuration->Storage->AccountKey);
		$this->_queueClient->createQueueIfNotExists($this->_queueName);
	}
	
	public function shortenUrl($url) {
		$alias = substr(uniqid(), -10);
		$entity = new shortenr_Entities_Url('url_' . md5($url), $alias);
		$entity->Alias = $alias;
		$entity->Url = $url;
		$entity->Visits = 0;
		
		$this->_tableStorageClient->insertEntity($this->_tableName, $entity);
		
		return $entity;
	}
	
	public function retrieveUrlFromAlias($alias) {
        $results = $this->_tableStorageClient->retrieveEntities(
            $this->_tableStorageClient->select()
								->from($this->_tableName)
								->where('RowKey eq ?', $alias),
            '',
            'shortenr_Entities_Url'
        );
		if (count($results) > 0) {
			return $results[0];
		}
		
		return null;
	}
	
	public function trackVisitedUrlFromAlias($alias) {
		$this->_queueClient->putMessage($this->_queueName, $alias);
	}
	
	public function storeUrl($entity) {
		$this->_tableStorageClient->updateEntity($this->_tableName, $entity);
	}
}