<?php
$configuration = (object)array(
	'Storage' => (object)array(
		'TableEndpoint' => 'table.core.windows.net',
		'BlobEndpoint' => 'blob.core.windows.net',
		'QueueEndpoint' => 'queue.core.windows.net',
		'AccountName' => 'xxxxxx',
		'AccountKey' => 'xxxxxxxxxxxxxxxxxxxx'
	)
);