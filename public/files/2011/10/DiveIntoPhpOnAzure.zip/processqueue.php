<?php
/** Requires */
require_once 'library/Microsoft/AutoLoader.php';
require_once 'library/shortenr/AutoLoader.php';
require_once 'configuration.php';

/** Create queue client */
$queueName = 'totrackvisits';
$queueClient = new Microsoft_WindowsAzure_Storage_Queue($configuration->Storage->QueueEndpoint, $configuration->Storage->AccountName, $configuration->Storage->AccountKey);
$queueClient->createQueueIfNotExists($queueName);

/** Use repository as well */
$repository = new shortenr_Repositories_UrlTableStorageRepository($configuration);

/** Start polling using back-off */
$currentBackOff = 0;
$maxBackOff = 10;

echo "Start polling queue $queueName...\r\n";
while(true) {
	$messages = $queueClient->getMessages($queueName, 5);

	if (count($messages) > 0) {
		$currentBackOff = 0;
		
		foreach ($messages as $message)
		{
			$alias = $message->MessageText;
			echo "Adding a download to URL with alias $alias...\r\n";
			
			$url = $repository->retrieveUrlFromAlias($alias);
			if (!is_null($url)) {
				$url->Visits += 1;
				$repository->storeUrl($url);
			}
			
			$queueClient->deleteMessage($queueName, $message);
			
			echo "Added download to URL with alias $alias.\r\n";
		}
	} else {
		if ($currentBackOff < $maxBackOff) {
			$currentBackOff++;
		}
		sleep($currentBackOff);
	}
}
echo "Finished polling queue $queueName. Which should never happen. Which means the building is on fire. HELP!\r\n";