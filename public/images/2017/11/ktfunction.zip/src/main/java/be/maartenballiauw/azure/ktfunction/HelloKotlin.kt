package be.maartenballiauw.azure.ktfunction

import com.microsoft.azure.serverless.functions.annotation.*

class HelloKotlin {
    @FunctionName("hello")
    fun hello(
            @HttpTrigger(name = "name", methods = arrayOf("get"), authLevel = AuthorizationLevel.ANONYMOUS)
            name: String): String {
        return String.format("Hello, %s!", name)
    }
}