﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.Web.Mvc;
using System.IO;
using System.Threading;

namespace MvcAsyncControllersExample.Controllers
{
    [HandleError]
    public class HomeController : AsyncController
    {
        public ActionResult Index()
        {
            ViewData["Message"] = "Welcome to ASP.NET MVC!";
            ViewData["MethodDescription"] = "This page has been rendered using a synchronous action method (the default ASP.NET MVC manner).";
            return View();
        }

        public IAsyncResult BeginIndexIAsync(AsyncCallback callback, object state) {
            // Do some lengthy I/O processing... Can be a DB call, file I/O, custom, ...
            FileStream fs = new FileStream(@"C:\Windows\Installing.bmp",
                FileMode.Open, FileAccess.Read, FileShare.None, 1, true);
            byte[] data = new byte[1024]; // buffer

            return fs.BeginRead(data, 0, data.Length, callback, fs);
        }

        public ActionResult EndIndexIAsync(IAsyncResult asyncResult)
        {
            // Fetch the result of the lengthy operation
            FileStream fs = asyncResult.AsyncState as FileStream;
            int bytesRead = fs.EndRead(asyncResult);
            fs.Close();

            // ... do something with the file contents ...

            // Return the view
            ViewData["Message"] = "Welcome to ASP.NET MVC!";
            ViewData["MethodDescription"] = "This page has been rendered using an asynchronous action method (IAsyncResult pattern).";
            return View("Index");
        }

        public void IndexEvent() {
            // Eventually pass parameters to the IndexEventCompleted action method
            // ... AsyncManager.Parameters["contact"] = new Contact();

            // Add an asynchronous operation
            AsyncManager.OutstandingOperations.Increment();
            ThreadPool.QueueUserWorkItem(o =>
            {
                Thread.Sleep(2000);
                AsyncManager.OutstandingOperations.Decrement();
            }, null);
        }

        public ActionResult IndexEventCompleted() {
            // Return the view
            ViewData["Message"] = "Welcome to ASP.NET MVC!";
            ViewData["MethodDescription"] = "This page has been rendered using an asynchronous action method (Event pattern).";
            return View("Index");
        }

        public ActionResult IndexDelegate()
        {
            // Perform asynchronous stuff
            //AsyncManager.RegisterTask(
            //    callback => ...,
            //    asyncResult =>
            //    {
            //        ...
            //    });

            // Return the view
            ViewData["Message"] = "Welcome to ASP.NET MVC!";
            ViewData["MethodDescription"] = "This page has been rendered using an asynchronous action method (Delegate pattern).";
            return View("Index");
        }
    }
}
