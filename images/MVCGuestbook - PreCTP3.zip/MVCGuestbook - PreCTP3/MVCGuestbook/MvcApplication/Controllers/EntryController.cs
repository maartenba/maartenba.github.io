﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Linq;
using MvcApplication.Models.Data;
using MvcApplication.Models.ViewData;
using System.Security.Permissions;
using System.Web.Routing;
using MvcApplication.Filters;

namespace MvcApplication.Controllers
{
    public class EntryController : Controller
    {

        public ActionResult New(int guestbookId)
        {
            GuestbookDataContext ctx = new GuestbookDataContext();

            CreateEntry viewData = new CreateEntry
            {
                Guestbook = ctx.Guestbooks.Single(g => g.Id == guestbookId)
            };

            return RenderView("New", viewData);
        }

        public ActionResult Preview(int guestbookId)
        {
            GuestbookDataContext ctx = new GuestbookDataContext();

            Entry entry = new Entry();
            BindingHelperExtensions.UpdateFrom(entry, Request.Form);
            entry.PostedDate = DateTime.Now;
            entry.GuestbookId = guestbookId;

            CreateEntry viewData = new CreateEntry
            {
                Guestbook = ctx.Guestbooks.Single(g => g.Id == guestbookId),
                Entry = entry
            };

            return RenderView("New", viewData);
        }

        public ActionResult Create(int guestbookId)
        {
            Entry entry = new Entry();
            BindingHelperExtensions.UpdateFrom(entry, Request.Form);
            entry.PostedDate = DateTime.Now;
            entry.GuestbookId = guestbookId;

            GuestbookDataContext ctx = new GuestbookDataContext();
            ctx.AddEntry(entry);
            ctx.SubmitChanges();

            return RedirectToAction(
                new RouteValueDictionary(new { controller = "Guestbook", action = "Show", id = guestbookId })
            );
        }

        [RequiresAuthentication()]
        [RequiresRole(RoleToCheckFor="Administrators")]
        public ActionResult Remove(int guestbookId, int entryId)
        {
            GuestbookDataContext ctx = new GuestbookDataContext();
            Entry entry = ctx.Entries.Single(e => e.Id == entryId);
            ctx.Entries.DeleteOnSubmit(entry);
            ctx.SubmitChanges();

            return RedirectToAction(
                new RouteValueDictionary(new { controller = "Guestbook", action = "Show", id = guestbookId })
            );
        }
    }
}