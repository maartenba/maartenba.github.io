﻿using System;
using System.Web;
using System.Web.Mvc;
using MvcApplication.Models.ViewData;
using MvcApplication.Models.Data;

namespace MvcApplication.Views.Shared
{
    public partial class Error : ViewPage<Exception>
    {
    }
}
