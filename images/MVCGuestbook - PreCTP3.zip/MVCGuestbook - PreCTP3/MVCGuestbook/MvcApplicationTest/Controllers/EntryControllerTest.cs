﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Web;
using System.Web.Mvc;
using MvcApplication.Controllers;
using MvcApplication.Models.ViewData;
using System.Web.Routing;
using MvcApplicationTest.HelperClasses;
using MvcApplication.Models.Data;

namespace MvcApplicationTest.Controllers
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class EntryControllerTest : BaseTest
    {
        [TestMethod]
        public void TestRouteNew()
        {
            HttpContextBase context = MvcMockHelpers.FakeHttpContext();
            context.Request.SetupRequestUrl("~/Entry/New/1");

            RouteData routeData = routes.GetRouteData(context);
            Assert.AreEqual("Entry", routeData.Values["controller"]);
            Assert.AreEqual("New", routeData.Values["action"]);
            Assert.AreEqual("1", routeData.Values["guestbookid"]);
            Assert.AreEqual(typeof(MvcRouteHandler), routeData.RouteHandler.GetType());
        }

        [TestMethod]
        public void TestNew()
        {
            EntryController controller = new EntryController();

            var result = controller.New(1) as RenderViewResult;

            Assert.IsNotNull(result);
            Assert.AreEqual(result.ViewName, "New");
            Assert.AreEqual(((CreateEntry)result.ViewData).Guestbook.Id, 1);
        }

        [TestMethod]
        public void TestPreview()
        {
            EntryController controller = new EntryController();

            controller.SetFakeControllerContext();
            controller.HttpContext.Request.SetupFormParameters();

            controller.HttpContext.Request.Form.Add("Entry.Author", "TestUser");
            controller.HttpContext.Request.Form.Add("Entry.Email", "test@test.com");
            controller.HttpContext.Request.Form.Add("Entry.Description", "This is a test");

            var result = controller.Preview(1) as RenderViewResult;

            Assert.IsNotNull(result);
            Assert.AreEqual(result.ViewName, "New");
            Assert.AreEqual(((CreateEntry)result.ViewData).Guestbook.Id, 1);
            Assert.AreEqual(((CreateEntry)result.ViewData).Entry.GuestbookId, 1);

            Assert.AreEqual(((CreateEntry)result.ViewData).Entry.Author, "TestUser");
            Assert.AreEqual(((CreateEntry)result.ViewData).Entry.Email, "test@test.com");
            Assert.AreEqual(((CreateEntry)result.ViewData).Entry.Description, "This is a test");
        }

        [TestMethod]
        public void TestCreate()
        {
            EntryController controller = new EntryController();

            controller.SetFakeControllerContext();
            controller.HttpContext.Request.SetupFormParameters();

            controller.HttpContext.Request.Form.Add("Entry.Author", "TestUser");
            controller.HttpContext.Request.Form.Add("Entry.Email", "test@test.com");
            controller.HttpContext.Request.Form.Add("Entry.Description", "This is a test");

            var result = controller.Create(1) as ActionRedirectResult;

            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void TestRemove()
        {
            EntryController controller = new EntryController();

            var result = controller.Remove(1, 10) as ActionRedirectResult;

            Assert.IsNotNull(result);
        }
    }
}