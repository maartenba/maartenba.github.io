﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Web;
using System.Web.Mvc;
using MvcApplication.Controllers;
using MvcApplicationTest.HelperClasses;
using System.Web.Routing;
using Moq;
using MvcApplication.Models.Data;

namespace MvcApplicationTest.Controllers
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class HomeControllerTest : BaseTest
    {
        [TestMethod]
        public void TestRouteIndex()
        {
            HttpContextBase context = MvcMockHelpers.FakeHttpContext();
            context.Request.SetupRequestUrl("~/Home/Index");

            RouteData routeData = routes.GetRouteData(context);
            Assert.AreEqual("Home", routeData.Values["controller"]);
            Assert.AreEqual("Index", routeData.Values["action"]);
            Assert.AreEqual(typeof(MvcRouteHandler), routeData.RouteHandler.GetType());
        }

        [TestMethod]
        public void TestRouteAbout()
        {
            HttpContextBase context = MvcMockHelpers.FakeHttpContext();
            context.Request.SetupRequestUrl("~/Home/About");

            RouteData routeData = routes.GetRouteData(context);
            Assert.AreEqual("Home", routeData.Values["controller"]);
            Assert.AreEqual("About", routeData.Values["action"]);
            Assert.AreEqual(typeof(MvcRouteHandler), routeData.RouteHandler.GetType());
        }

        [TestMethod]
        public void TestIndex()
        {
            HomeController controller = new HomeController();

            var result = controller.Index() as RenderViewResult;

            Assert.IsNotNull(result);
            Assert.AreEqual(result.ViewName, "Index");
            Assert.IsNotNull(result.ViewData);
        }

        [TestMethod]
        public void TestAbout()
        {
            HomeController controller = new HomeController();

            var result = controller.About() as RenderViewResult;

            Assert.IsNotNull(result);
            Assert.AreEqual(result.ViewName, "About");
            Assert.IsNotNull(result.ViewData);
        }
    }
}
