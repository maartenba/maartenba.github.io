﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using jQueryPartialUpdates.Models;
using jQueryPartialUpdates.Filters;

namespace jQueryPartialUpdates.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        #region Data

        public List<Employee> Employees
        {
            get {
                return new List<Employee>
                {
                    new Employee { Id = 1, FirstName = "Maarten", LastName = "Balliauw", Bio = "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum." },
                    new Employee { Id = 2, FirstName = "John", LastName = "Johnson", Bio = "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum." },
                    new Employee { Id = 3, FirstName = "Eric", LastName = "Ericson", Bio = "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum." }
                };
            }
        }

        #endregion

        public ActionResult Index()
        {
            ViewData["Title"] = "Home Page";

            return View(Employees);
        }

        [jQueryPartial(MasterPage = "Empty")]
        public ActionResult Details(int id)
        {
            Employee employee = 
                Employees.Where(e => e.Id == id).SingleOrDefault();

            ViewData["Title"] = "Details for " + 
                employee.LastName + ", " + employee.FirstName;
            
            return View(employee);
        }
    }
}
