﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web.Mvc;

namespace jQueryPartialUpdates.Filters
{
    public class jQueryPartial : ActionFilterAttribute
    {
        public string MasterPage { get; set; }

        public override void OnResultExecuting(ResultExecutingContext filterContext)
        {
            // Verify if a XMLHttpRequest is fired.
            // This can be done by checking the X-Requested-With
            // HTTP header.
            if (filterContext.HttpContext.Request.Headers["X-Requested-With"] != null
                && filterContext.HttpContext.Request.Headers["X-Requested-With"] == "XMLHttpRequest")
            {
                ViewResult viewResult = filterContext.Result as ViewResult;
                if (viewResult != null)
                {
                    viewResult.MasterName = MasterPage;
                }
            }
        }
    }
}


