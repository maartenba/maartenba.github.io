﻿using System.Web.Mvc;

namespace MvcGridView.Extensions
{
    public class GridViewData<T>
    {
        public PagedList<T> PagedList
        {
            get;
            set;
        }

        public T EditItem
        {
            get;
            set;
        }
    }
}
