﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Security.Permissions;
using System.Text;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace MvcGridView.Extensions
{
    [AspNetHostingPermission(SecurityAction.LinkDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    public static class HtmlHelperExtensions
    {
        public static string ActionImage<T>(this HtmlHelper html, Expression<Action<T>> action, string imageRelativeUrl, string alt, object imageAttributes)
             where T : Controller
        {
            string image = html.Image(imageRelativeUrl, alt, imageAttributes);
            return string.Format("<a href=\"{0}\">{1}</a>",
                html.BuildUrlFromExpression<T>(action),
                image);
        }
    }
}
