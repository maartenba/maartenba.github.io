﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Security.Permissions;
using System.Text;
using System.Collections.Generic;

namespace MvcGridView.Extensions
{
    [AspNetHostingPermission(SecurityAction.LinkDemand, Level = AspNetHostingPermissionLevel.Minimal)]
    public static class GridViewExtensions
    {
        public static void GridView<T>(
            this HtmlHelper html,
            GridViewData<T> data,
            Action<GridViewData<T>> headerTemplate,
            Action<T, string> itemTemplate,
            string cssClass,
            string cssAlternatingClass,
            Action<T> editItemTemplate, 
            Action<GridViewData<T>> footerTemplate)
        {
            headerTemplate(data);

            int i = 0;
            foreach (var item in data.PagedList)
            {
                if (!item.Equals(data.EditItem))
                {
                    itemTemplate(item, (i % 2 == 0 ? cssClass : cssAlternatingClass));
                }
                else
                {
                    editItemTemplate(item);
                }

                i++;
            }

            footerTemplate(data);
        }
    }
}
