﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcGridView.Models;
using MvcGridView.Extensions;

namespace MvcGridView.Views.Home
{
    public partial class Index : ViewPage<GridViewData<Employee>>
    {
    }
}
