﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ConfirmPhoneNumberDemo.Hubs;
using ConfirmPhoneNumberDemo.Models;
using SignalR;
using Twilio.TwiML;
using Twilio.TwiML.Mvc;

namespace ConfirmPhoneNumberDemo.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View(new SignUpModel());
        }

        [HttpPost, ActionName("SignUp")]
        public ActionResult SignUp_Post(SignUpModel model)
        {
            if (ModelState.IsValid)
            {
                return View();
            }
            return View("Index", model);
        }

        public ActionResult TwilioValidationMessage(string passcode, string phoneNumber)
        {
            var response = new TwilioResponse();
            response.Say("Hi there, welcome to Maarten's Awesome Service.");
            response.Say("To validate your phone number, please enter the 4 digit passcode displayed on your screen followed by the pound sign.");
            response.BeginGather(new { numDigits = 4, action = "http://mas.cloudapp.net/Home/TwilioValidationCallback?phoneNumber=" + Server.UrlEncode(phoneNumber), method = "GET" });
            response.EndGather();

            return new TwiMLResult(response);
        }

        public ActionResult TwilioValidationCallback(string phoneNumber)
        {
            var hubContext = GlobalHost.ConnectionManager.GetHubContext<PhoneValidatorHub>();
            hubContext.Clients.validated(phoneNumber);

            var response = new TwilioResponse();
            response.Say("Thank you! Your browser should automatically continue. Bye!");
            response.Hangup();

            return new TwiMLResult(response);
        }

        public JsonResult VerifyUsername(string username)
        {
            // Always valid, better to check this with your database
            return Json(true);
        }
    }
}
