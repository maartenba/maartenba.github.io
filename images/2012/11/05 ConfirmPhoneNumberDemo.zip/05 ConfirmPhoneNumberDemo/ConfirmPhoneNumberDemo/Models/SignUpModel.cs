﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ConfirmPhoneNumberDemo.Models
{
    public class SignUpModel
    {
        [Required(ErrorMessage = "Please provide your username")]
        [Display(Name = "Your username")]
        [Remote("VerifyUsername", "Home", ErrorMessage = "That username is already in use...")]
        [StringLength(255, MinimumLength = 6, ErrorMessage = "A username should be at least 6 characters long.")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Please provide your password")]
        [Display(Name = "Your password")]
        [DataType(DataType.Password)]
        [StringLength(255, MinimumLength = 6, ErrorMessage = "A password should be at least 6 characters long.")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Please provide your phone number")]
        [Display(Name = "Your phone number")]
        public string Phone { get; set; }
    }
}