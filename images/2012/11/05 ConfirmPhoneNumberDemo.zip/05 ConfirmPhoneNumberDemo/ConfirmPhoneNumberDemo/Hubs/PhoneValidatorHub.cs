﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using SignalR.Hubs;
using Twilio;

namespace ConfirmPhoneNumberDemo.Hubs
{
    [HubName("phonevalidator")]
    public class PhoneValidatorHub
        : Hub
    {
        public void StartValidation(string phoneNumber)
        {
            var twilioClient = new TwilioRestClient("api user", "api password");

            string url = "http://mas.cloudapp.net/Home/TwilioValidationMessage?passcode=1743&phoneNumber=" + HttpContext.Current.Server.UrlEncode(phoneNumber);

            // Instantiate the call options that are passed to the outbound call
            CallOptions options = new CallOptions();
            options.From = "+14155992671";
            options.To = phoneNumber;
            options.Url = url;

            // Make the call.
            twilioClient.InitiateOutboundCall(options);
        }
    }
}