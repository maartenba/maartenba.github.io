﻿
using System.Collections.Generic;

namespace DeckCast.Models
{
    public class Deck
    {
        public Deck()
        {
            Slides = new List<Slide>();
        }

        public string DeckId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Author { get; set; }

        public List<Slide> Slides { get; set; }
    }
}