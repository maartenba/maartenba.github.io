﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;
using LinqToTwitter;
using SignalR;
using SignalR.Routing;

namespace HelloWorld
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            RouteTable.Routes.MapConnection<TimeConnection>("time", "time/{*operation}");
            RouteTable.Routes.MapConnection<TweetsConnection>("tweets", "tweets/{*operation}");


            ThreadPool.QueueUserWorkItem(_ =>
            {
                var connection = Connection.GetConnection<TimeConnection>();
                while (true)
                {
                    connection.Broadcast(DateTime.Now.ToString());
                    Thread.Sleep(1000);
                }
            });

            ThreadPool.QueueUserWorkItem(_ =>
            {
                List<AtomEntry> tweets = new List<AtomEntry>();

                var connection = Connection.GetConnection<TweetsConnection>();
                while (true) 
                { 
                    using (TwitterContext context = new TwitterContext())
                    {
                        try
                        {
                            tweets = context.Search.Where(t => t.Type == SearchType.Search && t.Query == "#uan12").SingleOrDefault().Entries;
                        }
                        catch
                        {
                            // Nomnomnom
                        }

                        connection.Broadcast(tweets.ToList());
                    }
                    Thread.Sleep(5000);
                }
            });
        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}