﻿using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Windows.Threading;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SignalR.Client;
using SignalR.Client.Hubs;


namespace SevenTweets
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private Connection connection;

        public MainViewModel()
        {
            this.Items = new ObservableCollection<ItemViewModel>();

            connection = new Connection("http://localhost:6502/tweets");
            connection.Received += data => Deployment.Current.Dispatcher.BeginInvoke(() => UpdateItems(data));
            connection.Start();
        }

        protected void UpdateItems(string data)
        {
            this.Items.Clear();

            JArray entries = JArray.Parse(data);
            foreach (JObject entry in entries)
            {
                string content = Regex.Replace(entry["Content"].ToString(), "<.*?>", string.Empty);
                this.Items.Add(new ItemViewModel() { LineOne = entry["Title"].ToString().Substring(0, 6), LineTwo = ((JObject)entry["Author"])["Name"].ToString(), LineThree = content });
            }

            this.IsDataLoaded = true;
        }

        /// <summary>
        /// A collection for ItemViewModel objects.
        /// </summary>
        public ObservableCollection<ItemViewModel> Items { get; private set; }

        private string _sampleProperty = "Sample Runtime Property Value";

        /// <summary>
        /// Sample ViewModel property; this property is used in the view to display its value using a Binding
        /// </summary>
        /// <returns></returns>
        public string SampleProperty
        {
            get
            {
                return _sampleProperty;
            }
            set
            {
                if (value != _sampleProperty)
                {
                    _sampleProperty = value;
                    NotifyPropertyChanged("SampleProperty");
                }
            }
        }

        public bool IsDataLoaded
        {
            get;
            private set;
        }

        /// <summary>
        /// Creates and adds a few ItemViewModel objects into the Items collection.
        /// </summary>
        public void LoadData()
        {
            if (!connection.IsActive)
            {
                connection.Start();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}