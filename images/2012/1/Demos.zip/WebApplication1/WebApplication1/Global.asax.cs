﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using SignalR;
using SignalR.Hubs;
using SignalR.Routing;

namespace WebApplication1
{
    public class Person
    {
        public string Name { get; set; }
    }
    [HubName("worker")]
    public class WorkerHub : Hub
    {
        public void Work(Person p)
        {
            this.Caller.notify("Started work, " + p.Name + "...");

            for (int i = 0; i <= 100; i++)
            {
                this.Clients.setProgress(i);
                Thread.Sleep(100);
            }

            this.Caller.notify("Finished!");
        }
    }

    public class TimeConnection : PersistentConnection
    {
    }

    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            System.Web.Routing.RouteTable.Routes.MapConnection<TimeConnection>("time", "time/{*operation}");

            ThreadPool.QueueUserWorkItem(_ =>
                                             {
                                                 var connection = Connection.GetConnection<TimeConnection>();
                                                 while (true)
                                                 {
                                                     connection.Broadcast(DateTime.Now.ToLongTimeString());
                                                     Thread.Sleep(500);
                                                 }
                                             });
        }
        
        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}