﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.Text;
using System.Xml;
using Microsoft.ServiceBus;
using System.ServiceModel.Web;

namespace ServiceBusHost
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceBusEnvironment.SystemConnectivity.Mode = ConnectivityMode.AutoDetect;

            using (ServiceHost serviceHost = new WebServiceHost(typeof(ContosoService)))
            {
                try
                {
                    // Set service bus endpoint to DiscoveryType.Public 
                    foreach (var endpoint in serviceHost.Description.Endpoints)
                    {
                        if (endpoint.Binding.Name == "WebHttpRelayBinding")
                        {
                            endpoint.Behaviors.Add(new ServiceRegistrySettings()
                            {
                                DiscoveryMode = DiscoveryType.Public
                            });
                        }
                    }

                    // Open the ServiceHost to start listening for messages.
                    serviceHost.Open(TimeSpan.FromSeconds(30));

                    // The service can now be accessed.
                    Console.WriteLine("The service is ready.");
                    foreach (var endpoint in serviceHost.Description.Endpoints)
                    {
                        Console.WriteLine(" - " + endpoint.Address.Uri);
                    }
                    Console.WriteLine("Press <ENTER> to terminate service.");
                    Console.ReadLine();

                    // Close the ServiceHost.
                    serviceHost.Close();
                }
                catch (TimeoutException timeProblem)
                {
                    Console.WriteLine(timeProblem.Message);
                    Console.ReadLine();
                }
                catch (CommunicationException commProblem)
                {
                    Console.WriteLine(commProblem.Message);
                    Console.ReadLine();
                }
            }
        }
    }
}
