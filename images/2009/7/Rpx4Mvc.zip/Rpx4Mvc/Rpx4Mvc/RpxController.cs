﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Net;
using System.IO;
using System.Web.Script.Serialization;

namespace Rpx4Mvc
{




    [HandleError]
    public abstract class RpxController : Controller
    {

    }
}
