﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace Rpx4Mvc.Web.Controllers
{
    [HandleError]
    public class AccountController : Controller
    {
        public ActionResult Login(string token)
        {
            if (string.IsNullOrEmpty(token)) {
                return View();
            } else {
                IRpxLogin rpxLogin = new RpxLogin("b2e418e8e2dbd8cce612b829a9234ed4a763b2c0");
                try
                {
                    RpxProfile profile = rpxLogin.GetProfile(token);

                    FormsAuthentication.SetAuthCookie(profile.DisplayName, false);
                }
                catch (RpxException)
                {
                    return RedirectToAction("Login");
                }

                return RedirectToAction("Index", "Home");
            }
        }

        [Authorize]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }
    }
}
