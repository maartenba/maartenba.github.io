﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using NuGet;

namespace NuGetRole.Web.Core
{
    public class PackageSynchronizer
    {
        public delegate void SynchronizationStartedHandler(object sender);
        public delegate void SynchronizationCompletedHandler(object sender);

        public event SynchronizationStartedHandler SynchronizationStarted;
        public event SynchronizationCompletedHandler SynchronizationCompleted;

        private readonly Uri _packageSource;
        private readonly string _rootPath;
        private readonly IPackageRepository _packageRepository;
        private readonly Dictionary<string, string> _packageFileHash = new Dictionary<string, string>();

        public PackageSynchronizer(Uri packageSource, string rootPath)
        {
            _packageSource = packageSource;
            _rootPath = rootPath;
            _packageRepository = new DataServicePackageRepository(_packageSource);

            this.SynchronizeOnce();
        }

        public void SynchronizeOnce()
        {
            var packages = _packageRepository.GetPackages()
                .Where(p => p.IsLatestVersion == true).ToList();

            var touchedFiles = new List<string>();

            // Deploy new content
            foreach (var package in packages)
            {
                var packageHash = package.GetHash();
                var packageFiles = package.GetFiles();
                foreach (var packageFile in packageFiles)
                {
                    // Keep filename
                    var packageFileName = packageFile.Path.Replace("content\\", "").Replace("lib\\", "bin\\");
       
                    // Mark file as touched
                    touchedFiles.Add(packageFileName);

                    // Do not overwrite content that has not been updated
                    if (!_packageFileHash.ContainsKey(packageFileName) || _packageFileHash[packageFileName] != packageHash)
                    {
                        _packageFileHash[packageFileName] = packageHash;

                        Deploy(packageFile.GetStream(), packageFileName);
                    }
                }

                // Remove obsolete content
                var obsoleteFiles = _packageFileHash.Keys.Except(touchedFiles).ToList();
                foreach (var obsoletePath in obsoleteFiles)
                {
                    _packageFileHash.Remove(obsoletePath);
                    Undeploy(obsoletePath);
                }
            }
        }

        private void Deploy(Stream fileStream, string fileName)
        {
            fileName = Path.Combine(_rootPath, fileName);
            var fileDirectory = Path.GetDirectoryName(fileName);
            if (!Directory.Exists(fileDirectory))
            {
                Directory.CreateDirectory(fileDirectory);
            }

            var writeStream = File.OpenWrite(fileName);
            fileStream.CopyTo(writeStream);
            writeStream.Close();
        }

        private void Undeploy(string fileName)
        {
            fileName = Path.Combine(_rootPath, fileName);
            if (File.Exists(fileName))
            {
               File.Delete(fileName);
            }
        }

        public void SynchronizeForever(TimeSpan interval)
        {
            var syncingThread = new Thread(
                    () =>
                    {
                        while (true)
                        {
                            Thread.Sleep(interval);
                            SynchronizeOnce();
                        }
                    });
            syncingThread.Start();
        }
    }
}