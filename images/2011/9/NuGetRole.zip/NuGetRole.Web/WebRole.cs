using System;
using System.IO;
using Microsoft.WindowsAzure.ServiceRuntime;
using NuGetRole.Web.Core;

namespace NuGetRole.Web
{
    public class WebRole : RoleEntryPoint
    {
        private bool _isSynchronizing;
        private PackageSynchronizer _packageSynchronizer = null;

        public override bool OnStart()
        {
            var localPath = Path.Combine(Environment.GetEnvironmentVariable("RdRoleRoot") + "\\approot");
            if (RoleEnvironment.IsEmulated)
            {
                localPath = Path.Combine(localPath, @"..\..\..\..\..\..\..\NuGetRole.Web\");
            }

            _packageSynchronizer = new PackageSynchronizer(
                new Uri(RoleEnvironment.GetConfigurationSettingValue("PackageSource")), localPath);

            _packageSynchronizer.SynchronizationStarted += sender => _isSynchronizing = true;
            _packageSynchronizer.SynchronizationCompleted += sender => _isSynchronizing = false;

            RoleEnvironment.StatusCheck += (sender, args) =>
                                           {
                                               if (_isSynchronizing)
                                               {
                                                   args.SetBusy();
                                               }
                                           };

            return base.OnStart();
        }

        public override void Run()
        {
            _packageSynchronizer.SynchronizeForever(TimeSpan.FromSeconds(30));

            base.Run();
        }
    }
}
