﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SignalR.Client;
using SignalR.Client.Hubs;

namespace DeckCast.Console
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var connection = new HubConnection("http://localhost:56285/");
            var presentationHub = connection.CreateProxy("DeckCast.Hubs.PresentationHub");
            dynamic presentation = presentationHub;

            connection.Start()
                .ContinueWith(task =>
                                  {
                                      if (task.IsFaulted)
                                      {
                                          System.Console.ForegroundColor = ConsoleColor.Red;
                                          System.Console.WriteLine("There was an error connecting to the DeckCast presentation hub.");
                                      }
                                  });

            string actionInput = RequestInput("Do you want to (p)resent or (v)iew a DeckCast?");
            string deckId = RequestInput("Enter the DeckId:");

            presentationHub.Invoke("Join", deckId).Wait();

            switch (actionInput.ToLowerInvariant())
            {
                case "p": Present(presentation, deckId); break;
                case "v": View(presentation, deckId); break;
            }

            connection.Stop();
        }

        private static void Present(dynamic presentation, string deckId)
        {
            while (true)
            {
                var slideId = RequestInput("Go to slide:");
                presentation.GotoSlide(slideId);
            }
        }

        private static void View(dynamic presentation, string deckId)
        {
            var presentationHub = presentation as IHubProxy;

            var getDeckContents = presentationHub.Invoke<dynamic>("GetDeckContents", deckId);
            getDeckContents.Wait();

            var deck = getDeckContents.Result;

            presentationHub.On<int>("showSlide", slideId =>
            {
                System.Console.Clear();
                System.Console.ForegroundColor = ConsoleColor.White;
                System.Console.WriteLine("");
                System.Console.WriteLine(deck.Slides[slideId].Title);
                System.Console.WriteLine("");

                if (deck.Slides[slideId].Bullets != null)
                {
                    foreach (var bullet in deck.Slides[slideId].Bullets)
                    {
                        System.Console.WriteLine(" * {0}", bullet);
                        System.Console.WriteLine("");
                    }
                }

                if (deck.Slides[slideId].Quote != null)
                {
                    System.Console.WriteLine(" \"{0}\"", deck.Slides[slideId].Quote);
                }
            });

            presentationHub.Invoke("GotoCurrentSlide").Wait();

            System.Console.ReadLine();
        }

        private static string RequestInput(string message)
        {
            System.Console.ForegroundColor = ConsoleColor.White;
            System.Console.WriteLine(message);
            return System.Console.ReadLine().TrimEnd();
        }
    }
}