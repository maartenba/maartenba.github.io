namespace DeckCast.Models
{
    public class TitleSlide : Slide
    {
    }
}