namespace DeckCast.Models
{
    public class SlideWithQuote : Slide
    {
        public string Quote { get; set; }
    }
}