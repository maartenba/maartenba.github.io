namespace DeckCast.Models
{
    public interface IDeckRepository
    {
        Deck GetDeck(string id);
    }
}