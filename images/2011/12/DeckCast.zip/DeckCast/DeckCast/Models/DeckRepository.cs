﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DeckCast.Models
{
    public class DeckRepository
        : IDeckRepository
    {
        public Deck GetDeck(string id)
        {
            return new Deck
            {
                DeckId = id,
                Title = "Sample DeckCast Deck",
                Author = "Maarten Balliauw",
                Description = "Sample DeckCast Deck",
                Slides = new List<Slide>()
                {
                    new TitleSlide { Id = "slide1", Title = "Sample title slide" },
                    new SlideWithBullets { Id = "slide2", Title = "Some bullets on a slide", Bullets = new List<string>() { "Some bullet number 1", "Some bullet number 2", "Some bullet number 3" }},
                    new SlideWithQuote() { Id = "slide3", Title = "Slide with a quote", Quote = "A developer is a machine that turns coffee into code." },
                    new SlideWithBullets { Id = "slide4", Title = "Some more bullets on a slide", Bullets = new List<string>() { "Some bullet number 1", "Some bullet number 2", "Some bullet number 3" }},
                    new TitleSlide { Id = "slide5", Title = "Thank you!" }
                }
            };
        }
    }
}