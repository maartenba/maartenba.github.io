﻿using System.Collections.Concurrent;
using DeckCast.Models;
using SignalR.Hubs;

namespace DeckCast.Hubs
{
    [HubName("presentation")]
    public class PresentationHub
        : Hub
    {
        static ConcurrentDictionary<string, int> DeckLocation { get; set; }

        static PresentationHub()
        {
            DeckLocation = new ConcurrentDictionary<string, int>();
        }

        public void Join(string deckId)
        {
            Caller.DeckId = deckId;

            AddToGroup(deckId);
        }

        public void GotoSlide(int slideId)
        {
            string deckId = Caller.DeckId;
            DeckLocation.AddOrUpdate(deckId, (k) => slideId, (k, v) => slideId);

            Clients[deckId].showSlide(slideId);
        }

        public void GotoCurrentSlide()
        {
            int slideId = 0;
            DeckLocation.TryGetValue(Caller.DeckId, out slideId);
            Caller.showSlide(slideId);
        }

        public Deck GetDeckContents(string id)
        {
            var deckRepository = new DeckRepository();
            return deckRepository.GetDeck(id);
        }
    }
}