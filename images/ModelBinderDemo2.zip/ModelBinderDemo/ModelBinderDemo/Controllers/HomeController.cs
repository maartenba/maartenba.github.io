﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using ModelBinderDemo.Models;
using ModelBinderDemo.Util;
using Microsoft.Web.Mvc;

namespace ModelBinderDemo.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        [AcceptVerbs("GET")]
        public ActionResult Index()
        {
            Person person = new Person { 
                Id = 1, 
                Name = "Maarten", 
                Email = "maarten@maartenballiauw.be" 
            };

            ViewData["Person"] = Serializer.Serialize(person);

            return View("Index", person);
        }

        [AcceptVerbs("POST")]
        public ActionResult Index(Person person, FormCollection form)
        {
            if (string.IsNullOrEmpty(person.Name))
            {
                ViewData.ModelState.AddModelError("Name", person.Name, "Plese enter a name.");
            }

            if (string.IsNullOrEmpty(person.Email))
            {
                ViewData.ModelState.AddModelError("Name", person.Name, "Plese enter a name.");
            }

            return View("Index", person);
        }
    }
}
