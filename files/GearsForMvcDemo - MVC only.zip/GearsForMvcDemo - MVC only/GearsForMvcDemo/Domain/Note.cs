﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;

namespace GearsForMvcDemo.Domain
{
    public partial class Note : IDataErrorInfo
    {
        #region IDataErrorInfo Members

        public string Error
        {
            get { return ""; }
        }

        public string this[string columnName]
        {
            get {
                switch (columnName.ToUpperInvariant())
                {
                    case "TITLE":
                        if (string.IsNullOrEmpty(Title))
                            return "Title should be provided!";
                        break;

                    case "BODY":
                        if (string.IsNullOrEmpty(Body))
                            return "Title should be provided!";
                        break;
                }

                return "";
            }
        }

        #endregion
    }
}
