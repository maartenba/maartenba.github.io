﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GearsForMvcDemo.Data;
using GearsForMvcDemo.Domain;

namespace GearsForMvcDemo.Repository
{
    public class NoteRepository : INoteRepository
    {
        #region Private fields

        DemoDataClassesDataContext context = null;

        #endregion

        #region Constructor

        public NoteRepository()
        {
            // TODO: Refactor for dependency injection
            context = new DemoDataClassesDataContext();
        }

        #endregion

        #region INoteRepository Members

        public Note RetrieveById(int id, string ownerName)
        {
            return context.Notes.FirstOrDefault(n => n.Id == id && n.Owner.UserName == ownerName);
        }

        public List<Note> RetrieveByOwner(string ownerName)
        {
            return context.Notes.Where(n => n.Owner.UserName == ownerName).ToList();
        }

        public int Save(Note note, string ownerName)
        {
            note.Owner = context.Users.FirstOrDefault(u => u.UserName == ownerName);
            note.NoteTimeStamp = DateTime.Now.Ticks;

            if (note.Id > 0)
            {
                context.Refresh(System.Data.Linq.RefreshMode.KeepCurrentValues, note);
                context.SubmitChanges();
            }
            else
            {
                context.Notes.InsertOnSubmit(note);
                context.SubmitChanges();
            }

            return note.Id;
        }

        public void Delete(Note note)
        {
            context.Notes.DeleteOnSubmit(note);
            context.SubmitChanges();
        }

        #endregion
    }
}
