﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using GearsForMvcDemo.Domain;

namespace GearsForMvcDemo.Repository
{
    public interface INoteRepository
    {
        Note RetrieveById(int id, string ownerName);
        List<Note> RetrieveByOwner(string ownerName);
        int Save(Note note, string ownerName);
        void Delete(Note note);
    }
}
