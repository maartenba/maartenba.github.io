using System;

public class PartitionResolver : System.Web.IPartitionResolver
{

    #region Private members

    private String[] partitions;

    #endregion

    #region IPartitionResolver Members

    public void Initialize()
    {
        // Create an array containing
        // all partition connection strings
        //
        // Note that this could also be an array
        // of SQL server connection strings!
        partitions = new String[] {       
            "tcpip=127.0.0.1:42424",    
            "tcpip=localhost:42424"
        };
    }

    public string ResolvePartition(object key)
    {
        // Accept incoming session identifier
        // which looks similar like "2ywbtzez3eqxut45ukyzq3qp"
        string sessionId = key as string;

        // Create your own manner to divide session id's
        // across available partitions or simply use this one!
        int partitionID = Math.Abs(sessionId.GetHashCode()) % partitions.Length;
        return partitions[partitionID];
    }

    #endregion
}
