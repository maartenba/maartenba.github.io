<?php
/**
 * LuceneIndexDOCX - Create index
 *
 * @author Maarten Balliauw http://blog.maartenballiauw.be
 */

/** Configuration */
require_once 'config.inc.php';

/** Zend_Search_Lucene */  
require_once 'Zend/Search/Lucene.php';

/** DocX indexer */
require_once 'docxindexer.php';

// Index
$index = null;

// Verify if the index exists. If not, create it.
if (is_dir($configuration['lucene_index']) == 1) {
	$index = Zend_Search_Lucene::open($configuration['lucene_index']);  
} else {
	$index = Zend_Search_Lucene::create($configuration['lucene_index']); 
}

// Files to index
if ($handle = opendir($configuration['document_root'])) {
	// Remove old indexed files
	echo 'Remove old indexes...' . "\r\n";
	for ($i = 0; $i < $index->maxDoc(); $i++) {
		$index->delete($i);
	}
	
	// Add new indexed files
    while (false !== ($fileToIndex = readdir($handle))) {
    	// Skip folders / non-docx files
    	if ($fileToIndex == '.' || $fileToIndex == '..' || is_dir($fileToIndex) || strpos($fileToIndex, '.docx') === false) {
    		continue; 
    	}
        
		// Index file
		echo 'Indexing ' . $fileToIndex . '...' . "\r\n";
		
		// Create new indexed document
		$luceneDocument = new Zend_Search_Lucene_Document();
		
		// Store filename in index
		$luceneDocument->addField(Zend_Search_Lucene_Field::Text('url', $configuration['document_root'] . '/' . $fileToIndex));
		
		// Store contents in index
		$luceneDocument->addField(Zend_Search_Lucene_Field::UnStored('contents', DocXIndexer::readDocXContents($configuration['document_root'] . '/' . $fileToIndex)));
		
		// Store document properties
		$documentProperties = DocXIndexer::readCoreProperties($configuration['document_root'] . '/' . $fileToIndex);
		foreach ($documentProperties as $key => $value) {
			$luceneDocument->addField(Zend_Search_Lucene_Field::UnIndexed($key, $value));
		}
	
		// Store document in index
		$index->addDocument($luceneDocument);
    }
    closedir($handle); 
}

// Optimize the lucene index  
$index->optimize();

// Some statistics...
echo 'Index size: ' . $index->count() . "\r\n";
echo 'Document count: ' . $index->numDocs() . "\r\n";

// Commit
$index->commit();
