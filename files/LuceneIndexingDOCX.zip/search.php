<?php
/**
 * LuceneIndexDOCX - Search
 *
 * @author Maarten Balliauw http://blog.maartenballiauw.be
 */

/** Configuration */
require_once 'config.inc.php';

/** Zend_Search_Lucene */  
require_once 'Zend/Search/Lucene.php';

// Index
$index = null;

// Verify if the index exists. If not, error!
if (is_dir($configuration['lucene_index']) == 1) {
	$index = Zend_Search_Lucene::open($configuration['lucene_index']);  
} else {
	throw new Exception('Please create index first (using indexer.php)');
}

// Search query
$searchFor = 'Code Access Security';

// Search in index
echo sprintf('Searching for: %s', $searchFor) . "\r\n";
$hits = $index->find( $searchFor );

echo sprintf('Found %s result(s).', count($hits)) . "\r\n";
echo '--------------------------------------------------------' . "\r\n";

foreach ($hits as $hit) {
	echo sprintf('Score: %s', $hit->score) . "\r\n";
	echo sprintf('Title: %s', $hit->title) . "\r\n";
	echo sprintf('Creator: %s', $hit->creator) . "\r\n";
	echo sprintf('File: %s', $hit->url) . "\r\n";
	echo '--------------------------------------------------------' . "\r\n";
}