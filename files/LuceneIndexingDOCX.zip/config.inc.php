<?php
/** Configuration */
$configuration = array(
	'lucene_index' => './lucene_index',
	'document_root' => './documents'
);