<?php
/**
 * DocX indexer
 *
 * @author Maarten Balliauw - http://blog.maartenballiauw.be
 */
class DocXIndexer {
	/**
	 * Read DocX contents
	 *
	 * @param string $fileName
	 * @return File contents as a concatenated string
	 */
	public static function readDocXContents($fileName = '') {
		// Returnvalue
		$returnValue = array();
	
		// Schemas
		$relationshipSchema	= 'http://schemas.openxmlformats.org/package/2006/relationships';
		$officeDocumentSchema 	= 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument';
		$wordprocessingMLSchema = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
		
		// Documentholders
		$relations 		= null;
		
		// Open file
		$package = new ZipArchive();
		$package->open($fileName);
		
		// Read relations and search for officeDocument
		$relations = simplexml_load_string($package->getFromName("_rels/.rels"));
		foreach ($relations->Relationship as $rel) {
			if ($rel["Type"] == $officeDocumentSchema) {
				// Found office document! Now read in contents...
				$contents = simplexml_load_string(
					$package->getFromName(dirname($rel["Target"]) . "/" . basename($rel["Target"]))
				);
				
				$contents->registerXPathNamespace("w", $wordprocessingMLSchema);
				$paragraphs = $contents->xpath('//w:body/w:p');
				
				foreach($paragraphs as $paragraph) {
					$runs = $paragraph->xpath('//w:r/w:t');
					foreach ($runs as $run) {
						$returnValue[] = (string)$run;
					}
				}
				
				break;
			}
		}
		
		// Close file
		$package->close();
		
		// Return
		return implode(' ', $returnValue);
	}

	/**
	 * Read DocX core properties
	 *
	 * @param string $fileName
	 * @return array Array of key/value pairs
	 */
	public static function readCoreProperties($fileName = '') {
		// Returnvalue
		$returnValue = array();
	
		// Schemas
		$corePropertiesSchema	= 'http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties';
		$dublinCoreSchema 		= 'http://purl.org/dc/elements/1.1/';
		$dublinCoreTermsSchema	= 'http://purl.org/dc/terms/';
   
		// Documentholders
		$relations 				= null;
		
		// Open file
		$package = new ZipArchive();
		$package->open($fileName);
		
		// Read relations and search for officeDocument
		$relations = simplexml_load_string($package->getFromName("_rels/.rels"));
		foreach ($relations->Relationship as $rel) {
			if ($rel["Type"] == $corePropertiesSchema) {
				// Found core properties! Now read in contents...
				$contents = simplexml_load_string(
					$package->getFromName(dirname($rel["Target"]) . "/" . basename($rel["Target"]))
				);

				foreach ($contents->children($dublinCoreSchema) as $child) {
					$returnValue[$child->getName()] = (string)$child;
				}
				foreach ($contents->children($corePropertiesSchema) as $child) {
					$returnValue[$child->getName()] = (string)$child;
				}
				foreach ($contents->children($dublinCoreTermsSchema) as $child) {
					$returnValue[$child->getName()] = (string)$child;
				}
				
				break;
			}
		}
		
		// Close file
		$package->close();

		// Return
		return $returnValue;
	}
}