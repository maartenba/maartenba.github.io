﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using LinqModelBinderExample.Domain;
using LinqModelBinderExample.Data;

namespace LinqModelBinderExample.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            List<Person> persons = null;
            using (ApplicationDataContext context = new ApplicationDataContext())
            {
                persons = context.Persons.ToList();
            }

            return View("Index", persons);
        }

        public ActionResult PersonDetails(Person id)
        {
            if (id == null)
                return RedirectToAction("Index");

            return View(id);
        }
    }
}
