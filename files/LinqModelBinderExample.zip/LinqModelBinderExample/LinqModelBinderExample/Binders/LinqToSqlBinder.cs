﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LinqModelBinderExample.Domain;
using System.Data.Linq;
using System.Globalization;
using System.Data.Linq.Mapping;
using System.Text;
using System.Collections;
using System.Reflection;

namespace LinqModelBinderExample.Binders
{
    public class LinqToSqlBinder<T> : DefaultModelBinder
        where T : DataContext, new()
    {
        private class TableDefinition
        {
            public TableDefinition()
            {
                ColumnNames = new List<string>();
            }

            public string TableName;
            public string PrimaryKeyFieldName;
            public List<string> ColumnNames { get; set; }
        }

        public override ModelBinderResult BindModel(ModelBindingContext bindingContext)
        {
            using (T context = new T())
            {
                // Check if bindingContext.ModelType can be delivered from T
                MetaTable metaTable = context.Mapping.GetTable(bindingContext.ModelType);
                if (metaTable == null)
                {
                    return base.BindModel(bindingContext);
                }

                // Get the object ID that is being passed in.
                ValueProviderResult valueProviderResult = bindingContext.ValueProvider.GetValue(bindingContext.ModelName);
                if (valueProviderResult == null)
                {
                    return base.BindModel(bindingContext);
                }
                string objectId = valueProviderResult.AttemptedValue;

                // Build table definition
                TableDefinition tableDefinition = new TableDefinition();
                tableDefinition.TableName = metaTable.TableName;

                foreach (MetaDataMember dm in metaTable.RowType.DataMembers)
                {
                    if (dm.DbType != null)
                    {
                        tableDefinition.ColumnNames.Add(dm.MappedName);
                    }
                    if (dm.IsPrimaryKey)
                    {
                        tableDefinition.PrimaryKeyFieldName = dm.MappedName;
                    }
                }

                // Build query
                StringBuilder queryBuffer = new StringBuilder();
                queryBuffer.Append("SELECT ")
                                .Append(string.Join(", ", tableDefinition.ColumnNames.ToArray()))
                           .Append(" FROM ")
                                .Append(tableDefinition.TableName)
                           .Append(" WHERE ")
                                .Append(tableDefinition.PrimaryKeyFieldName)
                                .Append(" = \'").Append(objectId).Append("\'");

                // Execute query
                IEnumerable resultData = context.ExecuteQuery(bindingContext.ModelType,
                    queryBuffer.ToString());

                foreach (object result in resultData)
                {
                    return new ModelBinderResult(result);
                }
            }

            return base.BindModel(bindingContext);
        }

        public static void Register(IDictionary<Type, IModelBinder> bindersDictionary)
        {
            using (T context = new T())
            {
                foreach (var table in context.Mapping.GetTables())
                {
                    ModelBinders.Binders.Add(table.RowType.Type, new LinqToSqlBinder<T>());
                }
            }
        }
    }
}
