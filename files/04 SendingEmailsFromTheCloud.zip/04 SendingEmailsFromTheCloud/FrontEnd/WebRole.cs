using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading;
using System.Web.Script.Serialization;
using FrontEnd.Models;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.Diagnostics;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.StorageClient;
using SendGridMail;
using SendGridMail.Transport;

namespace FrontEnd
{
    public class WebRole : RoleEntryPoint
    {
        public override bool OnStart()
        {
            CloudStorageAccount.SetConfigurationSettingPublisher((configName, configSetter) =>
            {
                string value = "";
                if (RoleEnvironment.IsAvailable)
                {
                    value = RoleEnvironment.GetConfigurationSettingValue(configName);
                }
                else
                {
                    value = ConfigurationManager.AppSettings[configName];
                }

                configSetter(value);
            });

            return base.OnStart();
        }

        public override void Run()
        {
            // emailconfirmation queue
            var account = CloudStorageAccount.FromConfigurationSetting("StorageConnection");
            var queueClient = account.CreateCloudQueueClient();
            var queue = queueClient.GetQueueReference("emailconfirmation");
            queue.CreateIfNotExist();

            while (true)
            {
                var message = queue.GetMessage();
                if (message != null)
                {
                    // deserialize the model
                    var serializer = new JavaScriptSerializer();
                    var model = serializer.Deserialize<RegistrationModel>(message.AsString);

                    // create a new email object using SendGrid
                    var email = SendGrid.GenerateInstance();
                    email.From = new MailAddress("maarten@example.com", "Maarten");
                    email.AddTo(model.Email);
                    email.Subject = "Welcome to Maarten's Awesome Service!";
                    email.Html = string.Format("<html><p>Hello {0},</p><p>Welcome to Maarten's Awesome Service!</p><p>Best regards, <br />Maarten</p></html>", model.Name);

                    var transportInstance = REST.GetInstance(new NetworkCredential("username", "password"));
                    transportInstance.Deliver(email);

                    // mark the message as processed
                    queue.DeleteMessage(message);
                }
                else
                {
                    Thread.Sleep(TimeSpan.FromSeconds(30));
                }
            }
        }
    }
}
