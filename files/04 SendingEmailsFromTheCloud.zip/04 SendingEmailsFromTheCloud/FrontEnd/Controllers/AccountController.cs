﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using FrontEnd.Models;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;

namespace FrontEnd.Controllers
{
    public class AccountController : Controller
    {
        public ActionResult Index()
        {
            return RedirectToAction("Register");
        }

        public ActionResult Register()
        {
            var model = new RegistrationModel();

            return View(model);
        }

        [HttpPost, ActionName("Register")]
        public ActionResult Register_Post(RegistrationModel model)
        {
            if (ModelState.IsValid)
            {
                // ... store the user in the database ...

                // serialize the model
                var serializer = new JavaScriptSerializer();
                var modelAsString = serializer.Serialize(model);

                // emailconfirmation queue
                var account = CloudStorageAccount.FromConfigurationSetting("StorageConnection");
                var queueClient = account.CreateCloudQueueClient();
                var queue = queueClient.GetQueueReference("emailconfirmation");
                queue.CreateIfNotExist();

                queue.AddMessage(new CloudQueueMessage(modelAsString));

                return RedirectToAction("Thanks");
            }

            return View(model);
        }

        public ActionResult Thanks()
        {
            return View();
        }
    }
}