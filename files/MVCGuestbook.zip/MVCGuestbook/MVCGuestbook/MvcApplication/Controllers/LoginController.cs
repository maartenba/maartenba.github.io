﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace MvcApplication.Controllers
{
    public class LoginController : Controller
    {

        #region Properties

        private MembershipProvider membershipProvider;

        public MembershipProvider MembershipProviderInstance {
            get {
                return membershipProvider ?? Membership.Provider;
            } 
            set { membershipProvider = value; }
        }

        #endregion

        public void Index()
        {
            // Render index page
            RenderView("Index");
        }

        public void Authenticate()
        {
            // Get parameters
            string userName = "";
            if (null != Request.Form["username"])
            {
               userName = Request.Form["username"].Trim();
            }

            string password = "";
            if (null != Request.Form["password"])
            {
                password = Request.Form["password"].Trim();
            }

            // Authenticate
            if (MembershipProviderInstance.ValidateUser(userName, password))
            {
                // Set authentication cookie
                FormsAuthentication.SetAuthCookie(userName, false);

                // Return URL set?
                if (null != Request["returnUrl"] && !string.IsNullOrEmpty(Request["returnUrl"]))
                {
                    Response.Redirect(Server.UrlDecode(Request["returnUrl"]), true);
                }

                // Redirect to home
                RedirectToAction("Index", "Home");
            }
            else
            {
                // Set error...
                ViewData.Add("ErrorMessage", "Invalid credentials! Please verify your username and password.");
                
                // Render index page
                RenderView("Index");
            }
        }

        public void Logout()
        {
            // Clear authentication cookie
            FormsAuthentication.SignOut();

            // Redirect to home
            RedirectToAction("Index", "Home");
        }
    }
}
