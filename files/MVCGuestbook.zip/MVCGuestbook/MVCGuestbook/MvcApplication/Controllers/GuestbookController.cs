﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Linq;
using MvcApplication.Models.Data;
using MvcApplication.Models.ViewData;

namespace MvcApplication.Controllers
{
    public class GuestbookController : Controller
    {
        public void Show(int id)
        {
            GuestbookDataContext ctx = new GuestbookDataContext();

            GuestbookDetails viewData = new GuestbookDetails
            {
                Guestbook = ctx.Guestbooks.Single(g => g.Id == id)
            };

            RenderView("Show", viewData);
        }
    }
}