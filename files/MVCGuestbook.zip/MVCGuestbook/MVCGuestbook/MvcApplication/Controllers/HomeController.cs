﻿using System;
using System.Web;
using System.Web.Mvc;
using MvcApplication.Models.Data;
using MvcApplication.Models.ViewData;

namespace MvcApplication.Controllers
{
    public class HomeController : Controller
    {
        public void Index()
        {
            GuestbookDataContext ctx = new GuestbookDataContext();

            GuestbooksOverview viewData = new GuestbooksOverview
            {
                Guestbooks = ctx.GetGuestbooks()
            };

            RenderView("Index", viewData);
        }

        public void About()
        {
            RenderView("About");
        }
    }
}