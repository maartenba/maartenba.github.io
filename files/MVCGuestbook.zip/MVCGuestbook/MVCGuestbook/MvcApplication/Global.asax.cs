﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace MvcApplication
{
    public class GlobalApplication : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            RegisterRoutes(RouteTable.Routes);
        }

        public void RegisterRoutes(RouteCollection routes)
        {
            // Note: Change Url= to Url="[controller].mvc/[action]/[id]" to enable 
            //       automatic support on IIS6 

            routes.Add(new Route("Entry/{action}/{guestbookid}/{entryId}", new MvcRouteHandler())
            {
                Defaults = new RouteValueDictionary(new { controller = "Entry", action = "New", guestbookId = 0, entryId = 0 }),
            });

            routes.Add(new Route("Logout", new MvcRouteHandler())
            {
                Defaults = new RouteValueDictionary(new { controller = "Login", action = "Logout" }),
            });

            routes.Add(new Route("{controller}/{action}/{id}", new MvcRouteHandler())
            {
                Defaults = new RouteValueDictionary(new { action = "Index", id = "" }),
            });

            routes.Add(new Route("Default.aspx", new MvcRouteHandler())
            {
                Defaults = new RouteValueDictionary(new { controller = "Home", action = "Index", id = "" }),
            });
        }

    }
}