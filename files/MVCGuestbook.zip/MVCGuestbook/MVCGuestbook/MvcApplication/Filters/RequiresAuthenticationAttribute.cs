﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web.Mvc;

namespace MvcApplication.Filters
{
    /// <summary>
    /// See: http://blog.wekeroad.com/2008/03/12/aspnet-mvc-securing-your-controller-actions/
    /// Checks the User’s authentication using FormsAuthentication
    /// and redirects to the Login Url for the application on fail
    /// </summary>
    public class RequiresAuthenticationAttribute : ActionFilterAttribute
    {

        public override void OnActionExecuting(FilterExecutingContext filterContext)
        {
            // Redirect if not authenticated
            if (!filterContext.HttpContext.User.Identity.IsAuthenticated)
            {
                string redirectUrl = string.Format(
                    "{0}?returnUrl={1}",
                    FormsAuthentication.LoginUrl,
                    filterContext.HttpContext.Server.UrlEncode(filterContext.HttpContext.Request.Url.AbsolutePath)
                );
                filterContext.HttpContext.Response.Redirect(redirectUrl, true);
            }

        }
    }
}
