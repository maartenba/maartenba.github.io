﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Web;
using System.Web.Mvc;
using MvcApplication.Controllers;
using MvcApplicationTest.HelperClasses;
using Rhino.Mocks;
using System.Web.Routing;

namespace MvcApplicationTest.Controllers
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class LoginControllerTest : BaseTest
    {
        [TestMethod]
        public void TestRouteIndex()
        {
            MockRepository mocks = new MockRepository();
            HttpContextBase context;

            using (mocks.Record())
            {
                context = mocks.FakeHttpContext();
                context.Request.SetupRequestUrl("~/Login/Index");
            }

            using (mocks.Playback())
            {
                RouteData routeData = routes.GetRouteData(context);
                Assert.AreEqual("Login", routeData.Values["controller"]);
                Assert.AreEqual("Index", routeData.Values["action"]);
                Assert.AreEqual(typeof(MvcRouteHandler), routeData.RouteHandler.GetType());
            }
        }

        [TestMethod]
        public void TestRouteAuthenticate()
        {
            MockRepository mocks = new MockRepository();
            HttpContextBase context;

            using (mocks.Record())
            {
                context = mocks.FakeHttpContext();
                context.Request.SetupRequestUrl("~/Login/Authenticate");
            }

            using (mocks.Playback())
            {
                RouteData routeData = routes.GetRouteData(context);
                Assert.AreEqual("Login", routeData.Values["controller"]);
                Assert.AreEqual("Authenticate", routeData.Values["action"]);
                Assert.AreEqual(typeof(MvcRouteHandler), routeData.RouteHandler.GetType());
            }
        }

        [TestMethod]
        public void TestRouteLogout()
        {
            MockRepository mocks = new MockRepository();
            HttpContextBase context;

            using (mocks.Record())
            {
                context = mocks.FakeHttpContext();
                context.Request.SetupRequestUrl("~/Login/Logout");
            }

            using (mocks.Playback())
            {
                RouteData routeData = routes.GetRouteData(context);
                Assert.AreEqual("Login", routeData.Values["controller"]);
                Assert.AreEqual("Logout", routeData.Values["action"]);
                Assert.AreEqual(typeof(MvcRouteHandler), routeData.RouteHandler.GetType());
            }
        }

        [TestMethod]
        public void TestIndex()
        {
            LoginController controller = new LoginController();
            var fakeViewEngine = new FakeViewEngine();
            controller.ViewEngine = fakeViewEngine;

            MockRepository mocks = new MockRepository();
            using (mocks.Record())
            {
                mocks.SetFakeControllerContext(controller);
            }
            using (mocks.Playback())
            {
                controller.Index();
                Assert.AreEqual("Index", fakeViewEngine.ViewContext.ViewName);
            }
        }

        [TestMethod]
        public void TestInvalidCredentials()
        {
            LoginController controller = new LoginController();
            var fakeViewEngine = new FakeViewEngine();
            controller.ViewEngine = fakeViewEngine;

            MockRepository mocks = new MockRepository();
            using (mocks.Record())
            {
                mocks.SetFakeControllerContext(controller);
                controller.HttpContext.Request.SetupFormParameters();

                System.Web.Security.MembershipProvider membershipProvider = mocks.DynamicMock<System.Web.Security.MembershipProvider>();
                SetupResult.For(membershipProvider.ValidateUser("", "")).IgnoreArguments().Return(false);

                controller.MembershipProviderInstance = membershipProvider;
            }
            using (mocks.Playback())
            {
                controller.HttpContext.Request.Form.Add("Username", "");
                controller.HttpContext.Request.Form.Add("Password", "");

                controller.Authenticate();

                Assert.AreEqual("Index", fakeViewEngine.ViewContext.ViewName);
                Assert.IsNotNull(
                    ((IDictionary<string, object>)fakeViewEngine.ViewContext.ViewData)["ErrorMessage"]
                );
            }
        }

        [TestMethod]
        public void TestValidCredentials()
        {
            LoginController controller = new LoginController();
            var fakeViewEngine = new FakeViewEngine();
            controller.ViewEngine = fakeViewEngine;

            MockRepository mocks = new MockRepository();

            using (mocks.Record())
            {
                mocks.SetFakeControllerContext(controller);
                controller.HttpContext.Request.SetupFormParameters();

                System.Web.Security.MembershipProvider membershipProvider = mocks.DynamicMock<System.Web.Security.MembershipProvider>();
                SetupResult.For(membershipProvider.ValidateUser("", "")).IgnoreArguments().Return(true);

                controller.MembershipProviderInstance = membershipProvider;
            }
            using (mocks.Playback())
            {
                controller.HttpContext.Request.Form.Add("Username", "");
                controller.HttpContext.Request.Form.Add("Password", "");

                try
                {
                    controller.Authenticate();
                }
                catch (NullReferenceException) { } // TODO next MVC version - FormsAuthentication.SetAuthCookie throws NullReferenceException

                Assert.IsNull(fakeViewEngine.ViewContext, "Should have been redirected to /Home/Index");
            }
        }

        [TestMethod]
        public void TestLogout()
        {
            LoginController controller = new LoginController();
            var fakeViewEngine = new FakeViewEngine();
            controller.ViewEngine = fakeViewEngine;

            MockRepository mocks = new MockRepository();
            using (mocks.Record())
            {
                mocks.SetFakeControllerContext(controller);
            }
            using (mocks.Playback())
            {
                try {
                    controller.Logout();
                }
                catch (NullReferenceException) { } // TODO next MVC version - FormsAuthentication.SetAuthCookie throws NullReferenceException

                Assert.IsNull(fakeViewEngine.ViewContext, "Should have been redirected to /Home/Index");
            }
        }
    }
}