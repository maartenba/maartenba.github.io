﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Web;
using System.Web.Mvc;
using MvcApplication.Controllers;
using MvcApplicationTest.HelperClasses;
using Rhino.Mocks;
using System.Web.Routing;

namespace MvcApplicationTest.Controllers
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class HomeControllerTest : BaseTest
    {

        [TestMethod]
        public void TestRouteDefault()
        {
            MockRepository mocks = new MockRepository();
            HttpContextBase context;

            using (mocks.Record())
            {
                context = mocks.FakeHttpContext();
                context.Request.SetupRequestUrl("~/Default.aspx");
            }

            using (mocks.Playback())
            {
                RouteData routeData = routes.GetRouteData(context);
                Assert.AreEqual("Home", routeData.Values["controller"]);
                Assert.AreEqual("Index", routeData.Values["action"]);
                Assert.AreEqual(typeof(MvcRouteHandler), routeData.RouteHandler.GetType());
            }
        }

        [TestMethod]
        public void TestRouteIndex()
        {
            MockRepository mocks = new MockRepository();
            HttpContextBase context;

            using (mocks.Record())
            {
                context = mocks.FakeHttpContext();
                context.Request.SetupRequestUrl("~/Home/Index");
            }

            using (mocks.Playback())
            {
                RouteData routeData = routes.GetRouteData(context);
                Assert.AreEqual("Home", routeData.Values["controller"]);
                Assert.AreEqual("Index", routeData.Values["action"]);
                Assert.AreEqual(typeof(MvcRouteHandler), routeData.RouteHandler.GetType());
            }
        }

        [TestMethod]
        public void TestRouteAbout()
        {
            MockRepository mocks = new MockRepository();
            HttpContextBase context;

            using (mocks.Record())
            {
                context = mocks.FakeHttpContext();
                context.Request.SetupRequestUrl("~/Home/About");
            }

            using (mocks.Playback())
            {
                RouteData routeData = routes.GetRouteData(context);
                Assert.AreEqual("Home", routeData.Values["controller"]);
                Assert.AreEqual("About", routeData.Values["action"]);
                Assert.AreEqual(typeof(MvcRouteHandler), routeData.RouteHandler.GetType());
            }
        }

        [TestMethod]
        public void TestIndex()
        {
            HomeController controller = new HomeController();
            var fakeViewEngine = new FakeViewEngine();
            controller.ViewEngine = fakeViewEngine;

            MockRepository mocks = new MockRepository();
            using (mocks.Record())
            {
                mocks.SetFakeControllerContext(controller);
            }
            using (mocks.Playback())
            {
                controller.Index();
                Assert.AreEqual("Index", fakeViewEngine.ViewContext.ViewName);
            }
        }

        [TestMethod]
        public void TestAbout()
        {
            HomeController controller = new HomeController();
            var fakeViewEngine = new FakeViewEngine();
            controller.ViewEngine = fakeViewEngine;

            MockRepository mocks = new MockRepository();
            using (mocks.Record())
            {
                mocks.SetFakeControllerContext(controller);
            }
            using (mocks.Playback())
            {
                controller.About();
                Assert.AreEqual("About", fakeViewEngine.ViewContext.ViewName);
            }
        }
    }
}
