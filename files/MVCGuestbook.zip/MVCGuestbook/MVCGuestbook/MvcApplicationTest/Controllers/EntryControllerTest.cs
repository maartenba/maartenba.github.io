﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Web;
using System.Web.Mvc;
using MvcApplication.Controllers;
using MvcApplication.Models.ViewData;
using Rhino.Mocks;
using System.Web.Routing;
using MvcApplicationTest.HelperClasses;
using MvcApplication.Models.Data;

namespace MvcApplicationTest.Controllers
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class EntryControllerTest : BaseTest
    {
        [TestMethod]
        public void TestRouteNew()
        {
            MockRepository mocks = new MockRepository();
            HttpContextBase context;

            using (mocks.Record())
            {
                context = mocks.FakeHttpContext();
                context.Request.SetupRequestUrl("~/Entry/New/1");
            }

            using (mocks.Playback())
            {
                RouteData routeData = routes.GetRouteData(context);
                Assert.AreEqual("Entry", routeData.Values["controller"]);
                Assert.AreEqual("New", routeData.Values["action"]);
                Assert.AreEqual("1", routeData.Values["guestbookid"]);
                Assert.AreEqual(typeof(MvcRouteHandler), routeData.RouteHandler.GetType());
            }
        }

        [TestMethod]
        public void TestNew()
        {
            EntryController controller = new EntryController();
            var fakeViewEngine = new FakeViewEngine();
            controller.ViewEngine = fakeViewEngine;

            MockRepository mocks = new MockRepository();
            using (mocks.Record())
            {
                mocks.SetFakeControllerContext(controller);
            }
            using (mocks.Playback())
            {
                controller.New(1);

                Assert.AreEqual("New", fakeViewEngine.ViewContext.ViewName);
                Assert.AreEqual(1, ((CreateEntry)fakeViewEngine.ViewContext.ViewData).Guestbook.Id);
            }
        }

        [TestMethod]
        public void TestPreview()
        {
            EntryController controller = new EntryController();
            var fakeViewEngine = new FakeViewEngine();
            controller.ViewEngine = fakeViewEngine;

            MockRepository mocks = new MockRepository();
            using (mocks.Record())
            {
                mocks.SetFakeControllerContext(controller);
                controller.HttpContext.Request.SetupFormParameters();
            }
            using (mocks.Playback())
            {
                controller.HttpContext.Request.Form.Add("Entry.Author", "TestUser");
                controller.HttpContext.Request.Form.Add("Entry.Email", "test@test.com");
                controller.HttpContext.Request.Form.Add("Entry.Description", "This is a test");

                controller.Preview(1);
                Assert.AreEqual("New", fakeViewEngine.ViewContext.ViewName);
                Assert.AreEqual(1, ((CreateEntry)fakeViewEngine.ViewContext.ViewData).Guestbook.Id);
                Assert.AreEqual(1, ((CreateEntry)fakeViewEngine.ViewContext.ViewData).Entry.GuestbookId);
                Assert.AreEqual("TestUser", ((CreateEntry)fakeViewEngine.ViewContext.ViewData).Entry.Author);
                Assert.AreEqual("test@test.com", ((CreateEntry)fakeViewEngine.ViewContext.ViewData).Entry.Email);
                Assert.AreEqual("This is a test", ((CreateEntry)fakeViewEngine.ViewContext.ViewData).Entry.Description);
            }
        }

        [TestMethod]
        public void TestCreate()
        {
            EntryController controller = new EntryController();
            var fakeViewEngine = new FakeViewEngine();
            controller.ViewEngine = fakeViewEngine;

            MockRepository mocks = new MockRepository();
            using (mocks.Record())
            {
                mocks.SetFakeControllerContext(controller);
                controller.HttpContext.Request.SetupFormParameters();
            }
            using (mocks.Playback())
            {
                controller.HttpContext.Request.Form.Add("Entry.Author", "TestUser");
                controller.HttpContext.Request.Form.Add("Entry.Email", "test@test.com");
                controller.HttpContext.Request.Form.Add("Entry.Description", "This is a test");

                controller.Create(1);

                Assert.IsNull(fakeViewEngine.ViewContext, "Should have been redirected to /Guestbook/Show/1");
            }
        }

        [TestMethod]
        public void TestRemove()
        {
            EntryController controller = new EntryController();
            var fakeViewEngine = new FakeViewEngine();
            controller.ViewEngine = fakeViewEngine;

            MockRepository mocks = new MockRepository();
            using (mocks.Record())
            {
                mocks.SetFakeControllerContext(controller);
                controller.HttpContext.Request.SetupFormParameters();
            }
            using (mocks.Playback())
            {
                GuestbookDataContext context = new GuestbookDataContext();
                controller.Remove(context.Entries.First().GuestbookId, context.Entries.First().Id);

                Assert.IsNull(fakeViewEngine.ViewContext, "Should have been redirected to /Guestbook/Show/1");
            }
        }
    }
}
