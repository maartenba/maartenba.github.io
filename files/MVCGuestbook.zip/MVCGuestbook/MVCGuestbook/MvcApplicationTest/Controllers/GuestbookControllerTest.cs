﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Web;
using System.Web.Mvc;
using MvcApplication.Controllers;
using MvcApplication.Models.ViewData;
using Rhino.Mocks;
using MvcApplicationTest.HelperClasses;
using System.Web.Routing;

namespace MvcApplicationTest.Controllers
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class GuestbookControllerTest : BaseTest
    {
        [TestMethod]
        public void TestRouteShow()
        {
            MockRepository mocks = new MockRepository();
            HttpContextBase context;

            using (mocks.Record())
            {
                context = mocks.FakeHttpContext();
                context.Request.SetupRequestUrl("~/Guestbook/Show/1");
            }

            using (mocks.Playback())
            {
                RouteData routeData = routes.GetRouteData(context);
                Assert.AreEqual("Guestbook", routeData.Values["controller"]);
                Assert.AreEqual("Show", routeData.Values["action"]);
                Assert.AreEqual("1", routeData.Values["id"]);
                Assert.AreEqual(typeof(MvcRouteHandler), routeData.RouteHandler.GetType());
            }
        }

        [TestMethod]
        public void TestShow()
        {
            GuestbookController controller = new GuestbookController();
            var fakeViewEngine = new FakeViewEngine();
            controller.ViewEngine = fakeViewEngine;

            MockRepository mocks = new MockRepository();
            using (mocks.Record())
            {
                mocks.SetFakeControllerContext(controller);
            }
            using (mocks.Playback())
            {
                controller.Show(1);
                Assert.AreEqual("Show", fakeViewEngine.ViewContext.ViewName);
                Assert.AreEqual(1, ((GuestbookDetails)fakeViewEngine.ViewContext.ViewData).Guestbook.Id);
            }
        }
    }
}
