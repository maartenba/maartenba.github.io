﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Web;
using System.Web.Mvc;
using MvcApplication.Controllers;
using MvcApplication.Models.ViewData;
using MvcApplicationTest.HelperClasses;
using System.Web.Routing;

namespace MvcApplicationTest.Controllers
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class GuestbookControllerTest : BaseTest
    {
        [TestMethod]
        public void TestRouteShow()
        {
            HttpContextBase context = MvcMockHelpers.FakeHttpContext();
            context.Request.SetupRequestUrl("~/Guestbook/Show/1");

            RouteData routeData = routes.GetRouteData(context);
            Assert.AreEqual("Guestbook", routeData.Values["controller"]);
            Assert.AreEqual("Show", routeData.Values["action"]);
            Assert.AreEqual("1", routeData.Values["id"]);
            Assert.AreEqual(typeof(MvcRouteHandler), routeData.RouteHandler.GetType());
        }

        [TestMethod]
        public void TestShow()
        {
            GuestbookController controller = new GuestbookController();

            var result = controller.Show(1) as ViewResult;

            Assert.IsNotNull(result);
            Assert.AreEqual(result.ViewName, "Show");
            Assert.AreEqual(((GuestbookDetails)result.ViewData.Model).Guestbook.Id, 1);
        }
    }
}
