<?php
/** Error reporting */
error_reporting(E_ALL);

/** Include path **/
set_include_path(get_include_path() . PATH_SEPARATOR . '.');

/** Zend_Http_Client */
require_once 'Zend/Http/Client.php';

/** Zend_Azure_Storage_Blob */
require_once 'Zend/Azure/Storage/Blob.php';

// Do some test stuff... (on local storage, Windows Azure SDK)
$storage = new Zend_Azure_Storage_Blob();
var_dump( $storage->createContainer('azuretest') ); 
var_dump( $storage->getContainerAcl('azuretest') );
var_dump( $storage->setContainerAcl('azuretest', Zend_Azure_Storage_Blob::ACL_PUBLIC) ); 
var_dump( $storage->getContainerAcl('azuretest') );
var_dump( $storage->setContainerAcl('azuretest', Zend_Azure_Storage_Blob::ACL_PRIVATE) ); 
var_dump( $storage->getContainerAcl('azuretest') );
var_dump( $storage->listContainers() );
var_dump( $storage->putBlob('azuretest', 'images/WindowsAzure.gif', './WindowsAzure.gif') );
var_dump( $storage->listBlobs('azuretest', '/', 'images/') ); 
var_dump( $storage->getBlob('azuretest', 'images/WindowsAzure.gif', './WindowsAzure-received.gif') ); 
var_dump( $storage->deleteBlob('azuretest', 'images/WindowsAzure.gif') );
var_dump( $storage->deleteContainer('azuretest') );*/