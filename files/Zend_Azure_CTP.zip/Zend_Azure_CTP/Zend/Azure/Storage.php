
<?php
/**
 * Zend Framework
 *
 * LICENSE
 *
 * This source file is subject to the new BSD license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://framework.zend.com/license/new-bsd
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@zend.com so we can send you a copy immediately.
 *
 * @category   Zend
 * @package    Zend_Azure
 * @subpackage Storage
 * @copyright  Copyright (c) 2005-2009 Zend Technologies USA Inc. (http://www.zend.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 * @version    $Id: SharedKeyAuthentication.php 11747 2008-10-08 18:33:58Z norm2782 $
 */


/** Zend_Azure_SharedKeyCredentials */
require_once 'Zend/Azure/SharedKeyCredentials.php';

/** Zend_Http_Client */
require_once 'Zend/Http/Client.php';

/** Zend_Rest_Client_Result */
require_once 'Zend/Rest/Client/Result.php';


/**
 * @category   Zend
 * @package    Zend_Azure
 * @copyright  Copyright (c) 2005-2009 Zend Technologies USA Inc. (http://www.zend.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 */
class Zend_Azure_Storage
{
	/**
	 * Development storage URLS
	 */
	const URL_DEV_BLOB = "127.0.0.1:10000";
	const URL_DEV_TABLE = "127.0.0.1:10002";
	
	/**
	 * Live storage URLS
	 */
	const URL_CLOUD_BLOB = "blob.core.windows.net";
	const URL_CLOUD_TABLE = "table.core.windows.net";
	
	/**
	 * Storage host name
	 *
	 * @var string
	 */
	protected $_host = '';
	
	/**
	 * Account name for Windows Azure
	 *
	 * @var string
	 */
	protected $_accountName = '';
	
	/**
	 * Account key for Windows Azure
	 *
	 * @var string
	 */
	protected $_accountKey = '';
	
	/**
	 * Use path-style URI's
	 *
	 * @var boolean
	 */
	protected $_usePathStyleUri = false;
	
	/**
	 * Zend_Azure_SharedKeyCredentials instance
	 *
	 * @var Zend_Azure_SharedKeyCredentials
	 */
	protected $_credentials = null;
	
	/**
	 * Creates a new Zend_Azure_Storage instance
	 *
	 * @param string $host Storage host name
	 * @param string $accountName Account name for Windows Azure
	 * @param string $accountKey Account key for Windows Azure
	 * @param boolean $usePathStyleUri Use path-style URI's
	 */
	public function __construct($host = self::URL_DEV_BLOB, $accountName = Zend_Azure_SharedKeyCredentials::DEVSTORE_ACCOUNT, $accountKey = Zend_Azure_SharedKeyCredentials::DEVSTORE_KEY, $usePathStyleUri = false)
	{
		$this->_host = $host;
		$this->_accountName = $accountName;
		$this->_accountKey = $accountKey;
		$this->_usePathStyleUri = $usePathStyleUri;
		
		if (!$this->_usePathStyleUri && strpos($this->_host, ':1000') !== false) // Local storage
			$this->_usePathStyleUri = true;
		
		$this->_credentials = new Zend_Azure_SharedKeyCredentials($this->_accountName, $this->_accountKey, $this->_usePathStyleUri);
	}
	
	/**
	 * Get base URL for creating requests
	 *
	 * @return string
	 */
	public function getBaseUrl()
	{
		if ($this->_usePathStyleUri)
			return 'http://' . $this->_host . '/' . $this->_accountName;
		else
			return 'http://' . $this->_accountName . '.' . $this->_host;
	}
	
	/**
	 * Create Zend_Http_Client client
	 *
	 * @param string $path Path
	 * @param string $queryString Query string
	 * @return Zend_Http_Client
	 */
	protected function createClient($path = '/', $queryString = '')
	{
		if (strpos($path, '/') !== 1) 
			$path = '/' . $path;
		
		return new Zend_Http_Client($this->getBaseUrl() . $path . ($queryString !== '' ? '/' . $queryString : ''));
	}
	
	/**
	 * Parse result from Zend_Http_Client
	 *
	 * @param Zend_Http_Response $response Response from HTTP call
	 * @return Zend_Rest_Client_Result
	 * @throws Zend_Azure_Exception
	 */
	protected function parseResponse(Zend_Http_Response $response = null)
	{
		if (is_null($response))
			throw new Zend_Azure_Exception('Response should not be null.');
		
		return new Zend_Rest_Client_Result($response->getBody());
	}
}
