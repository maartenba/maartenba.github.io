<?php
/**
 * Zend Framework
 *
 * LICENSE
 *
 * This source file is subject to the new BSD license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://framework.zend.com/license/new-bsd
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@zend.com so we can send you a copy immediately.
 *
 * @category   Zend
 * @package    Zend_Azure
 * @subpackage Storage
 * @copyright  Copyright (c) 2005-2009 Zend Technologies USA Inc. (http://www.zend.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 * @version    $Id: SharedKeyAuthentication.php 11747 2008-10-08 18:33:58Z norm2782 $
 */


/** Zend_Azure_SharedKeyCredentials */
require_once 'Zend/Azure/SharedKeyCredentials.php';

/** Zend_Http_Client */
require_once 'Zend/Http/Client.php';

/** Zend_Azure_Storage */
require_once 'Zend/Azure/Storage.php';

/** Zend_Azure_Exception */
require_once 'Zend/Azure/Exception.php';


/**
 * @category   Zend
 * @package    Zend_Azure
 * @copyright  Copyright (c) 2005-2009 Zend Technologies USA Inc. (http://www.zend.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 */
class Zend_Azure_Storage_Blob extends Zend_Azure_Storage
{
	/**
	 * ACL - Private access
	 */
	const ACL_PRIVATE = false;
	
	/**
	 * ACL - Public access
	 */
	const ACL_PUBLIC = true;
	
	/**
	 * Creates a new Zend_Azure_Storage_Blob instance
	 *
	 * @param string $host Storage host name
	 * @param string $accountName Account name for Windows Azure
	 * @param string $accountKey Account key for Windows Azure
	 * @param boolean $usePathStyleUri Use path-style URI's
	 */
	public function __construct($host = self::URL_DEV_BLOB, $accountName = Zend_Azure_SharedKeyCredentials::DEVSTORE_ACCOUNT, $accountKey = Zend_Azure_SharedKeyCredentials::DEVSTORE_KEY, $usePathStyleUri = false)
	{
		parent::__construct($host, $accountName, $accountKey, $usePathStyleUri);
	}
	
	/**
	 * Create container
	 *
	 * @param string $containerName Container name
	 * @return object Container properties
	 * @throws Zend_Azure_Exception
	 */
	public function createContainer($containerName = '')
	{
		if ($containerName === '')
			throw new Zend_Azure_Exception('Container name is not specified.');
			
		// Perform request
		$httpClient = $this->createClient($containerName);
		$this->_credentials->signRequest($httpClient, Zend_Http_Client::PUT);
		$response = $httpClient->request(Zend_Http_Client::PUT);
		
		if ($response->isSuccessful())
		{
			return (object)array(
				'Name' => $containerName,
				'Etag' => $response->getHeader('Etag'),
				'LastModified' => $response->getHeader('Last-modified')
			);
		}
		else
		{
			throw new Zend_Azure_Exception($this->parseResponse($response)->Message);
		}
	}
	
	/**
	 * Get container ACL
	 *
	 * @param string $containerName Container name
	 * @return bool Acl, to be compared with Zend_Azure_Storage_Blob::ACL_*
	 * @throws Zend_Azure_Exception
	 */
	public function getContainerAcl($containerName = '')
	{
		if ($containerName === '')
			throw new Zend_Azure_Exception('Container name is not specified.');

		// Perform request
		$httpClient = $this->createClient($containerName, '?comp=acl');
		$this->_credentials->signRequest($httpClient, Zend_Http_Client::GET);
		$response = $httpClient->request(Zend_Http_Client::GET);

		if ($response->isSuccessful())
			return $response->getHeader('x-ms-prop-publicaccess') == 'True';
		else
			throw new Zend_Azure_Exception($this->parseResponse($response)->Message);
	}
	
	/**
	 * Set container ACL
	 *
	 * @param string $containerName Container name
	 * @param bool $acl Zend_Azure_Storage_Blob::ACL_*
	 * @throws Zend_Azure_Exception
	 */
	public function setContainerAcl($containerName = '', $acl = self::ACL_PRIVATE)
	{
		if ($containerName === '')
			throw new Zend_Azure_Exception('Container name is not specified.');

		// Perform request
		$httpClient = $this->createClient($containerName, '?comp=acl');
		$httpClient->setHeaders('x-ms-prop-publicaccess', $acl);
		$this->_credentials->signRequest(
			$httpClient,
			Zend_Http_Client::PUT,
			'',
			array('x-ms-prop-publicaccess' => $acl)
		);
		$response = $httpClient->request(Zend_Http_Client::PUT);

		if (!$response->isSuccessful())
			throw new Zend_Azure_Exception($this->parseResponse($response)->Message);
	}
	
	/**
	 * Delete container
	 *
	 * @param string $containerName Container name
	 * @throws Zend_Azure_Exception
	 */
	public function deleteContainer($containerName = '')
	{
		if ($containerName === '')
			throw new Zend_Azure_Exception('Container name is not specified.');
			
		// Perform request
		$httpClient = $this->createClient($containerName);
		$this->_credentials->signRequest($httpClient, Zend_Http_Client::DELETE);
		$response = $httpClient->request(Zend_Http_Client::DELETE);
		
		if (!$response->isSuccessful())
			throw new Zend_Azure_Exception($this->parseResponse($response)->Message);
	}
	
	/**
	 * List containers
	 *
	 * @return array
	 * @throws Zend_Azure_Exception
	 */
	public function listContainers()
	{
		// Perform request
		$httpClient = $this->createClient('', '?comp=list');
		$this->_credentials->signRequest($httpClient, Zend_Http_Client::GET);
		$response = $httpClient->request(Zend_Http_Client::GET);
		
		if ($response->isSuccessful())
		{
			$xmlContainers = $this->parseResponse($response)->Containers->Container;
			
			$containers = array();
			if (!is_null($xmlContainers))
			{
				for ($i = 0; $i < count($xmlContainers); $i++)
				{
					$containers[] = (object)array(
						'Name' => (string)$xmlContainers[$i]->Name,
						'Etag' => (string)$xmlContainers[$i]->Etag,
						'LastModified' => (string)$xmlContainers[$i]->LastModified
					);
				}
			}
			
			return $containers;
		}
		else 
		{
			throw new Zend_Azure_Exception($this->parseResponse($response)->Message);
		}
	}
	
	/**
	 * Put blob
	 *
	 * @param string $containerName Container name
	 * @param string $blobName Blob name
	 * @param string $localFileName Local file name to be uploaded
	 * @return object Partial blob properties
	 * @throws Zend_Azure_Exception
	 */
	public function putBlob($containerName = '', $blobName = '', $localFileName = '')
	{
		if ($containerName === '')
			throw new Zend_Azure_Exception('Container name is not specified.');
		if ($blobName === '')
			throw new Zend_Azure_Exception('Blob name is not specified.');
		if ($localFileName === '')
			throw new Zend_Azure_Exception('Local file name is not specified.');
			
		// File contents
		if (filesize($localFileName) >= 64 * 1024 * 1024)
			throw new Zend_Azure_Exception('File is too large. Maximum file size is 64MB.');
			
		$fileContents = file_get_contents($localFileName);
		
		// Perform request
		$httpClient = $this->createClient($containerName . '/' . $blobName);
		$this->_credentials->signRequest($httpClient, Zend_Http_Client::PUT);
		$httpClient->setRawData($fileContents);
		$response = $httpClient->request(Zend_Http_Client::PUT);

		if ($response->isSuccessful())
		{
			return (object)array(
				'Container' => $containerName,
				'Name' => $blobName,
				'Etag' => $response->getHeader('Etag'),
				'LastModified' => $response->getHeader('Last-modified'),
				'Url' => '',
				'Size' => '',
				'ContentType' => '',
				'ContentEncoding' => '',
				'ContentLanguage' => '',
				'IsPrefix' => false
			);
		}
		else
		{
			throw new Zend_Azure_Exception($this->parseResponse($response)->Message);
		}
	}
	
	/**
	 * Get blob
	 *
	 * @param string $containerName Container name
	 * @param string $blobName Blob name
	 * @param string $localFileName Local file name to store downloaded blob
	 * @throws Zend_Azure_Exception
	 */
	public function getBlob($containerName = '', $blobName = '', $localFileName = '')
	{
		if ($containerName === '')
			throw new Zend_Azure_Exception('Container name is not specified.');
		if ($blobName === '')
			throw new Zend_Azure_Exception('Blob name is not specified.');
		if ($localFileName === '')
			throw new Zend_Azure_Exception('Local file name is not specified.');
			
		// Perform request
		$httpClient = $this->createClient($containerName . '/' . $blobName);
		$this->_credentials->signRequest($httpClient, Zend_Http_Client::GET);
		$response = $httpClient->request(Zend_Http_Client::GET);

		if ($response->isSuccessful())
			file_put_contents($localFileName, $response->getBody());
		else
			throw new Zend_Azure_Exception($this->parseResponse($response)->Message);
	}
	
	/**
	 * Delete blob
	 *
	 * @param string $containerName Container name
	 * @param string $blobName Blob name
	 * @throws Zend_Azure_Exception
	 */
	public function deleteBlob($containerName = '', $blobName = '')
	{
		if ($containerName === '')
			throw new Zend_Azure_Exception('Container name is not specified.');
		if ($blobName === '')
			throw new Zend_Azure_Exception('Blob name is not specified.');
			
		// Perform request
		$httpClient = $this->createClient($containerName . '/' . $blobName);
		$this->_credentials->signRequest($httpClient, Zend_Http_Client::DELETE);
		$response = $httpClient->request(Zend_Http_Client::DELETE);

		if (!$response->isSuccessful())
			throw new Zend_Azure_Exception($this->parseResponse($response)->Message);
	}
	
	/**
	 * List blobs
	 *
	 * @param string $containerName Container name
	 * @param string $delimiter Delimiter, i.e. '/', for specifying folder hierarchy
	 * @param string $prefix Prefix, i.e. 'images/', for specifying folder
	 * @return array
	 * @throws Zend_Azure_Exception
	 */
	public function listBlobs($containerName = '', $delimiter = '', $prefix = '')
	{
		if ($containerName === '')
			throw new Zend_Azure_Exception('Container name is not specified.');
			
		// Perform request
		$query = '?comp=list';
		if ($delimiter !== '')
			$query .= '&delimiter=' . $delimiter;

		if ($prefix !== '')
			$query .= '&prefix=' . $prefix;

		$httpClient = $this->createClient($containerName, $query);
		$this->_credentials->signRequest($httpClient, Zend_Http_Client::GET);
		$response = $httpClient->request(Zend_Http_Client::GET);

		if ($response->isSuccessful())
		{
			// Blobs
			$xmlBlobs = $this->parseResponse($response)->Blobs->Blob;
			
			$blobs = array();
			if (!is_null($xmlBlobs))
			{
				for ($i = 0; $i < count($xmlBlobs); $i++)
				{
					$blobs[] = (object)array(
						'Container' => $containerName,
						'Name' => (string)$xmlBlobs[$i]->Name,
						'Etag' => (string)$xmlBlobs[$i]->Etag,
						'LastModified' => (string)$xmlBlobs[$i]->LastModified,
						'Url' => (string)$xmlBlobs[$i]->Url,
						'Size' => (string)$xmlBlobs[$i]->Size,
						'ContentType' => (string)$xmlBlobs[$i]->ContentType,
						'ContentEncoding' => (string)$xmlBlobs[$i]->ContentEncoding,
						'ContentLanguage' => (string)$xmlBlobs[$i]->ContentLanguage,
						'IsPrefix' => false
					);
				}
			}
			
			// Blob prefixes (folders)
			$xmlBlobs = $this->parseResponse($response)->Blobs->BlobPrefix;
			
			if (!is_null($xmlBlobs))
			{
				for ($i = 0; $i < count($xmlBlobs); $i++)
				{
					$blobs[] = (object)array(
						'Container' => $containerName,
						'Name' => (string)$xmlBlobs[$i]->Name,
						'IsPrefix' => true
					);
				}
			}
			
			return $blobs;
		}
		else 
		{
			throw new Zend_Azure_Exception($this->parseResponse($response)->Message);
		}
	}
}
