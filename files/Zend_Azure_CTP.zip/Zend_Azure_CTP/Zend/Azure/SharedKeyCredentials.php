<?php
/**
 * Zend Framework
 *
 * LICENSE
 *
 * This source file is subject to the new BSD license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://framework.zend.com/license/new-bsd
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@zend.com so we can send you a copy immediately.
 *
 * @category   Zend
 * @package    Zend_Azure
 * @copyright  Copyright (c) 2005-2009 Zend Technologies USA Inc. (http://www.zend.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 * @version    $Id: SharedKeyAuthentication.php 11747 2008-10-08 18:33:58Z norm2782 $
 */


/** Zend_Http_Client */
require_once 'Zend/Http/Client.php';

/** Zend_Uri */
require_once 'Zend/Uri.php';


/**
 * @category   Zend
 * @package    Zend_Azure
 * @copyright  Copyright (c) 2005-2009 Zend Technologies USA Inc. (http://www.zend.com)
 * @license    http://framework.zend.com/license/new-bsd     New BSD License
 */
class Zend_Azure_SharedKeyCredentials
{
	/**
	 * Development storage account and key
	 */
	const DEVSTORE_ACCOUNT = "devstoreaccount1";
	const DEVSTORE_KEY = "Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==";
	
	/**
	 * HTTP header prefixes
	 */
	const PREFIX_PROPERTIES = "x-ms-prop-";
	const PREFIX_METADATA = "x-ms-meta-";
	const PREFIX_STORAGE_HEADER = "x-ms-";

	/**
	 * Account name for Windows Azure
	 *
	 * @var string
	 */
	protected $_accountName = '';
	
	/**
	 * Account key for Windows Azure
	 *
	 * @var string
	 */
	protected $_accountKey = '';
	
	/**
	 * Use path-style URI's
	 *
	 * @var boolean
	 */
	protected $_usePathStyleUri = false;
	
	/**
	 * Creates a new Zend_Azure_SharedKeyCredentials instance
	 *
	 * @param string $accountName Account name for Windows Azure
	 * @param string $accountKey Account key for Windows Azure
	 * @param boolean $usePathStyleUri Use path-style URI's
	 */
	public function __construct($accountName = self::DEVSTORE_ACCOUNT, $accountKey = self::DEVSTORE_KEY, $usePathStyleUri = false)
	{
		$this->_accountName = $accountName;
		$this->_accountKey = base64_decode($accountKey);
		$this->_usePathStyleUri = $usePathStyleUri;
	}
	
	/**
	 * Sign request with credentials
	 *
	 * @param Zend_Http_Client $requestClient Zend_Http_Client used to make a request to Windows Azure
	 * @param string $httpVerb HTTP verb the request will use
	 * @param string $path Path for the request
	 * @param array $headers x-ms headers to add
	 * @param boolean $forTableStorage Is the request for table storage?
	 */
	public function signRequest(Zend_Http_Client $requestClient, $httpVerb = 'GET', $path = '', $headers = null, $forTableStorage = false)
	{
		// TODO: Use $forTableStorage
		// http://github.com/sriramk/winazurestorage/blob/214010a2f8931bac9c96dfeb337d56fe084ca63b/winazurestorage.py
		
		// Determine path
		if ($path === '')
			$path = $requestClient->getUri()->getPath();
		if ($this->_usePathStyleUri)
			$path = substr($path, strpos($path, '/'));

		// Determine query
		$query = $requestClient->getUri()->getQuery();
		if (strlen($query) > 0 && strpos($query, '?') !== 1)
			$query = '?' . $query;	

		if (strpos($query, '&') !== false)
			$query = substr($query, 0, strpos($query, '&'));

		// Build canonicalized headers
		$canonicalizedHeaders = array();
		if (!is_null($headers))
		{
			foreach ($headers as $header => $value) {
				if (is_bool($value))
					$value = $value === true ? 'True' : 'False';

				$requestClient->setHeaders($header, $value);
				$canonicalizedHeaders[] = $header . ':' . $value;
			}
		}
		
		// Build canonicalized resource string
		$canonicalizedResource = '/' . $this->_accountName . $path . $query;
		
		// Request date
		$requestDate = gmdate('D, d M Y H:i:s', time()) . ' GMT'; // RFC 1123
		
		// Create string to sign   
		$stringToSign = array();
		$stringToSign[] = strtoupper($httpVerb); 	// VERB
    	$stringToSign[] = "";						// Content-MD5
    	$stringToSign[] = "";						// Content-Type
    	$stringToSign[] = "";
    	$stringToSign[] = self::PREFIX_STORAGE_HEADER . 'date:' . $requestDate; // Date
    	
    	if (count($canonicalizedHeaders) > 0)
    		$stringToSign[] = implode("\n", $canonicalizedHeaders); // Canonicalized headers
    		
    	$stringToSign[] = $canonicalizedResource;		 						// Canonicalized resource
    	$stringToSign = implode("\n", $stringToSign);
    	$signString = base64_encode(hash_hmac('sha256', $stringToSign, $this->_accountKey, true));

    	// Sign request
    	$requestClient->setHeaders(self::PREFIX_STORAGE_HEADER . 'date', $requestDate);
    	$requestClient->setHeaders('Authorization', 'SharedKey ' . $this->_accountName . ':' . $signString);
	}
}
