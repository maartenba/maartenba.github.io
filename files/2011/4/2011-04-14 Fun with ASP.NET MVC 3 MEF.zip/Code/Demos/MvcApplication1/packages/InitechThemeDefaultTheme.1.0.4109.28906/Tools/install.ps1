param($installPath, $toolsPath, $package, $project)

[System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[Windows.Forms.MessageBox]::Show("If you can go ahead and change your _ViewStart.cshtml to use _InitechLayout? That'd be great. Oh, and, you should ask yourself, for every decision you make, Is This Good For The Company?", "Initech Guidance", [Windows.Forms.MessageBoxButtons]::OK, [Windows.Forms.MessageBoxIcon]::Warning)