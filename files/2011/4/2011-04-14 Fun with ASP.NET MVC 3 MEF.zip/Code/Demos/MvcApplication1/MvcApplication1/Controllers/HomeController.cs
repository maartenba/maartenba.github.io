﻿using System.Web.Mvc;
using Initech.Components.Domain.TpsReports;

namespace MvcApplication1.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View(new TpsReportCoverSheet());
        }

        [HttpPost]
        public ActionResult Index(TpsReportCoverSheet model)
        {
            if (ModelState.IsValid)
            {
                return View("TpsReportCoverSheet", model);
            }

            return View(model);
        }
    }
}
