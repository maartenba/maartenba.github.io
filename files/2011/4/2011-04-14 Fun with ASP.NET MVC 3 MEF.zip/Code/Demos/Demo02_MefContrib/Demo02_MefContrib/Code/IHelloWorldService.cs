﻿
namespace Demo02_MefContrib.Code
{
    public interface IHelloWorldService
    {
        string Hello();
    }
}