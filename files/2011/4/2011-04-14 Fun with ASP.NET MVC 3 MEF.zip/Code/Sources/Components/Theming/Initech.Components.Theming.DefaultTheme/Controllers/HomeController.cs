﻿using System.Web.Mvc;

namespace Initech.Components.Theming.DefaultTheme.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Message = "Welcome to Initech!";

            return View();
        }
    }
}
