﻿using System.Web.Mvc;
using Initech.Components.Domain.TpsReports;

namespace Initech.Applications.TpsReports.CoverGenerator.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View(new TpsReportCoverSheet());
        }

        [HttpPost]
        public ActionResult Index(TpsReportCoverSheet model)
        {
            if (ModelState.IsValid)
            {
                // Generate the report
                return View("TpsReportCoverSheet", model);
            }

            return View(model);
        }

    }
}
