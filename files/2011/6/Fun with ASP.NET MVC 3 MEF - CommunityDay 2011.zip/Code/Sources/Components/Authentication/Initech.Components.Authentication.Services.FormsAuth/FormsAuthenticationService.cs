﻿using System;
using System.ComponentModel.Composition;
using System.Web.Security;
using Initech.Components.Authentication.Contracts.Services;

namespace Initech.Components.Authentication.Services.FormsAuth
{
    [Export(typeof(IFormsAuthenticationService))]
    public class FormsAuthenticationService : IFormsAuthenticationService
    {
        public void SignIn(string userName, bool createPersistentCookie)
        {
            if (String.IsNullOrEmpty(userName)) throw new ArgumentException("Value cannot be null or empty.", "userName");

            FormsAuthentication.SetAuthCookie(userName, createPersistentCookie);
        }

        public void SignOut()
        {
            FormsAuthentication.SignOut();
        }
    }
}
