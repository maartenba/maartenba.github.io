﻿using System.Web.Mvc;

namespace Demo01_MVC_DependencyResolver.Controllers
{
    public class HomeController : Controller
    {
        public string MessageText { get; set; }

        public ActionResult Index()
        {
            ViewBag.Message = MessageText;

            return View();
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
