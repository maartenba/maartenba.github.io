﻿using System.ComponentModel.Composition;
using System.Web.Mvc;
using Demo02_MefContrib.Code;

namespace Demo02_MefContrib.Controllers
{
    public class HomeController : Controller
    {
        private IHelloWorldService service;

        [ImportingConstructor]
        public HomeController(IHelloWorldService helloWorldService)
        {
            this.service = helloWorldService;
        }

        public ActionResult Index()
        {
            ViewBag.Message = this.service.Hello();

            return View();
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
