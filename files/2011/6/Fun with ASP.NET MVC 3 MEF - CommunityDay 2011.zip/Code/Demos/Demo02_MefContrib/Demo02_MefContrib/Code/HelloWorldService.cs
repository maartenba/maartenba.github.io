﻿using System.ComponentModel.Composition;

namespace Demo02_MefContrib.Code
{
    [Export(typeof(IHelloWorldService))]
    public class HelloWorldService
        : IHelloWorldService
    {
        public string Hello()
        {
            return "Hello from HelloWorldService!";
        }
    }
}