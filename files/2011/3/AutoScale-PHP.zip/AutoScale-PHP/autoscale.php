<?php
// Set include path
$path = array('./library/', get_include_path());
set_include_path(implode(PATH_SEPARATOR, $path));

// Microsoft_WindowsAzure_Management_Client
require_once 'Microsoft/WindowsAzure/Management/Client.php';

// Some commercial info :-)
echo "AutoScale - (c) 2011 Maarten Balliauw\r\n";
echo "\r\n";

// Quick-and-dirty argument check
if (count($argv) != 7)
{
    echo "Usage:\r\n";
    echo "  AutoScale <certificatefile> <subscriptionid> <servicename> <rolename> <slot> <instancecount>\r\n";
    echo "\r\n";
    echo "Example:\r\n";
    echo "  AutoScale mycert.pem 39f53bb4-752f-4b2c-a873-5ed94df029e2 bing Bing.Web production 20\r\n";
    exit;
}

// Save arguments to variables
$certificateFile = $argv[1];
$subscriptionId = $argv[2];
$serviceName = $argv[3];
$roleName = $argv[4];
$slot = $argv[5];
$instanceCount = $argv[6];

// Do the magic
$managementClient = new Microsoft_WindowsAzure_Management_Client($subscriptionId, $certificateFile, '');

echo "Uploading new configuration...\r\n";

$managementClient->setInstanceCountBySlot($serviceName, $slot, $roleName, $instanceCount);

echo "Finished.\r\n";