using System.Web.Http;

namespace WebApiSubdomainRouting.Controllers
{
    public class UsersController
        : ApiController
    {
        public string Get()
        {
            var routeData = this.Request.GetRouteData().Values;
            if (routeData.ContainsKey("tenant"))
            {
                return "UsersController, called by tenant " + routeData["tenant"];
            }
            return "UsersController";
        }
    }
}