﻿using System;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Xml.Linq;
using Microsoft.Samples.WindowsAzure.ServiceManagement;

namespace AutoScale
{
    class Program
    {
        private const string ServiceEndpoint = "https://management.core.windows.net";

        private static Binding WebHttpBinding()
        {
            var binding = new WebHttpBinding(WebHttpSecurityMode.Transport);
            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Certificate;
            binding.ReaderQuotas.MaxStringContentLength = 67108864;

            return binding;
        }

        static void Main(string[] args)
        {
            // Some commercial info :-)
            Console.WriteLine("AutoScale - (c) 2011 Maarten Balliauw");
            Console.WriteLine("");

            // Quick-and-dirty argument check
            if (args.Length != 6)
            {
                Console.WriteLine("Usage:");
                Console.WriteLine("  AutoScale.exe <certificatefile> <subscriptionid> <servicename> <rolename> <slot> <instancecount>");
                Console.WriteLine("");
                Console.WriteLine("Example:");
                Console.WriteLine("  AutoScale.exe mycert.cer 39f53bb4-752f-4b2c-a873-5ed94df029e2 bing Bing.Web production 20");
                return;
            }

            // Save arguments to variables
            var certificateFile = args[0];
            var subscriptionId = args[1];
            var serviceName = args[2];
            var roleName = args[3];
            var slot = args[4];
            var instanceCount = args[5];

            // Do the magic
            var managementClient = Microsoft.Samples.WindowsAzure.ServiceManagement.ServiceManagementHelper.CreateServiceManagementChannel(
                WebHttpBinding(), new Uri(ServiceEndpoint), new X509Certificate2(certificateFile));

            Console.WriteLine("Retrieving current configuration...");

            var deployment = managementClient.GetDeploymentBySlot(subscriptionId, serviceName, slot);
            string configurationXml = ServiceManagementHelper.DecodeFromBase64String(deployment.Configuration);

            Console.WriteLine("Updating configuration value...");

            var serviceConfiguration = XDocument.Parse(configurationXml);

            serviceConfiguration
                    .Descendants()
                    .Single(d => d.Name.LocalName == "Role" && d.Attributes().Single(a => a.Name.LocalName == "name").Value == roleName)
                    .Elements()
                    .Single(e => e.Name.LocalName == "Instances")
                    .Attributes()
                    .Single(a => a.Name.LocalName == "count").Value = instanceCount;

            var changeConfigurationInput = new ChangeConfigurationInput();
            changeConfigurationInput.Configuration = ServiceManagementHelper.EncodeToBase64String(serviceConfiguration.ToString(SaveOptions.DisableFormatting));

            Console.WriteLine("Uploading new configuration...");

            managementClient.ChangeConfigurationBySlot(subscriptionId, serviceName, slot, changeConfigurationInput);

            Console.WriteLine("Finished.");
        }
    }
}
