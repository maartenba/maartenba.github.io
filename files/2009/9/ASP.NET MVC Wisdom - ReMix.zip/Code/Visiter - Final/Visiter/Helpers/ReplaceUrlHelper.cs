﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text.RegularExpressions;

namespace Visiter.Helpers
{
    public static class ReplaceUrlHelper
    {
        static Regex expression =
            new Regex(@"(http:\/\/([\w.]+\/?)\S*)", 
                RegexOptions.IgnoreCase | RegexOptions.Compiled);

        public static string ReplaceUrls(this HtmlHelper helper, string value)
        {
            return expression.Replace(value,
                "<a href=\"${0}\" target=\"_blank\">${0}</a>");
        }
    }
}
