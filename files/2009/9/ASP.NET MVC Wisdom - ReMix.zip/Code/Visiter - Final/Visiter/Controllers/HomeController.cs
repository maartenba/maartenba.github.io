﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Visiter.Models;
using Visiter.Data;

namespace Visiter.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        ITweetRepository repository = null;

        public HomeController() : this(new EfTweetRepository())
        {

        }

        public HomeController(ITweetRepository repository)
        {
            this.repository = repository;
        }

        public ActionResult Index()
        {
            List<Tweet> tweets =
                repository.GetFrontpageTweets()
                .Take(100).ToList();

            return View(tweets);
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
