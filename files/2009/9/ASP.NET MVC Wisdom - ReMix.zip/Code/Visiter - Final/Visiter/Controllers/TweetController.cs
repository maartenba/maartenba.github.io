using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using Visiter.Models;
using Visiter.Data;

namespace Visiter.Controllers
{
    public class TweetController : Controller
    {
        ITweetRepository repository = null;

        public TweetController() : this(new EfTweetRepository())
        {

        }

        public TweetController(ITweetRepository repository)
        {
            this.repository = repository;
        }

        [Authorize]
        public ActionResult Index()
        {
            List<Tweet> tweets =
                repository.GetPrivateTimeLine(User.Identity.Name)
                .Take(100).ToList();

            return View(tweets);
        }

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Tweet tweet)
        {
            User user = repository.GetUser(User.Identity.Name);
            tweet.User = user;
            tweet.PublishDate = DateTime.Now;

            if (ModelState.IsValid)
            {
                repository.Add(tweet);
                repository.Save();
                return RedirectToAction("Index");
            }

            List<Tweet> tweets =
                repository.GetPrivateTimeLine(User.Identity.Name).ToList();

            ViewData["Message"] = tweet.Message;
            return View("Index", tweets);
        }

        public ActionResult ByUser(string userName)
        {
            if (string.IsNullOrEmpty(userName))
                return RedirectToAction("Index");

            User otherUser = repository.GetUser(userName);
            User currentUser = repository.GetUser(User.Identity.Name);

            List<Tweet> tweets =
                repository.GetTweetsBy(userName).ToList();

            ViewData["UserName"] = userName;
            ViewData["IsFollowing"] = otherUser.FollowedBy.Contains(currentUser);

            return View(tweets);
        }

        [Authorize]
        public ActionResult Follow(string userName)
        {
            if (string.IsNullOrEmpty(userName))
                return RedirectToAction("Index");

            repository.Follow(
                User.Identity.Name, userName);
            repository.Save();

            return RedirectToAction("ByUser", new { userName = userName });
        }
    }
}
