﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Visiter.Code;

namespace Visiter.Data
{
    [MetadataType(typeof(TweetMetadata))]
    public partial class Tweet { }

    internal class TweetMetadata
    {
        [ShouldContainUrl(ErrorMessage = "Message should contain a URL.")]
        [StringLength(140, ErrorMessage = "Message must not exceed 140 characters.")]
        public string Message { get; set; }
    }
}
