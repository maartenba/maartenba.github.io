﻿using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;
using Visiter.Data;
using System.Linq;

namespace Visiter.Models
{
    public interface ITweetRepository
    {
        User GetUser(string userName);
        Tweet GetTweet(Guid id);
        IQueryable<Tweet> GetFrontpageTweets();
        IQueryable<Tweet> GetTweetsBy(string userName);
        IQueryable<Tweet> GetPrivateTimeLine(string userName);
        void Add(Tweet tweet);
        void Delete(Tweet tweet);
        void Follow(string userName, string userToFollow);
        void Save();
    }
}
