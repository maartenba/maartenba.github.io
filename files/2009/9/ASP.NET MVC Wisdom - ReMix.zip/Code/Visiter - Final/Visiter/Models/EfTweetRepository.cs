﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Visiter.Data;

namespace Visiter.Models
{
    public class EfTweetRepository : ITweetRepository
    {
        VisiterEntities db = new VisiterEntities();

        #region ITweetRepository Members

        public Visiter.Data.User GetUser(string userName)
        {
            return db.Users.Include("Following")
                .FirstOrDefault(u => u.UserName == userName);
        }

        public Visiter.Data.Tweet GetTweet(Guid id)
        {
            return db.Tweets.Include("User")
                .FirstOrDefault(t => t.TweetId == id);
        }

        public IQueryable<Visiter.Data.Tweet> GetFrontpageTweets()
        {
            return db.Tweets.Include("User")
                .OrderByDescending(t => t.PublishDate)
                .Take(100);
        }

        public IQueryable<Visiter.Data.Tweet> GetTweetsBy(string userName)
        {
            return db.Tweets.Include("User")
                .Where(t => t.User.UserName == userName)
                .OrderByDescending(t => t.PublishDate);
        }

        public IQueryable<Visiter.Data.Tweet> GetPrivateTimeLine(string userName)
        {
            User user = GetUser(userName);

            List<Tweet> tweets = GetTweetsBy(userName).ToList();
            foreach (User following in user.Following)
            {
                tweets.AddRange(GetTweetsBy(following.UserName).Take(50).ToList());
            }

            return tweets.AsQueryable().OrderByDescending(t => t.PublishDate);
        }

        public void Add(Visiter.Data.Tweet tweet)
        {
            tweet.TweetId = Guid.NewGuid();
            db.AddToTweets(tweet);
        }

        public void Delete(Visiter.Data.Tweet tweet)
        {
            db.DeleteObject(tweet);
        }

        public void Follow(string userName, string userToFollow)
        {
            User user1 = GetUser(userName);
            User user2 = GetUser(userToFollow);

            if (!user1.Following.Contains(user2))
                user1.Following.Add(user2);
            else
                user1.Following.Remove(user2);
        }

        public void Save()
        {
            db.SaveChanges();
        }

        #endregion
    }
}