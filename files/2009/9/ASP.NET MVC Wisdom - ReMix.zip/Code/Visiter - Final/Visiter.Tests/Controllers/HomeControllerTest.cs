﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Visiter;
using Visiter.Controllers;
using Visiter.Data;
using Visiter.Models;
using Visiter.Tests.Mocks;

namespace Visiter.Tests.Controllers
{
    [TestClass]
    public class HomeControllerTest
    {
        [TestMethod]
        public void Index()
        {
            // Arrange
            ITweetRepository fakeRepo = new FakeRepo();
            HomeController controller = new HomeController(fakeRepo);

            // Act
            ViewResult result = controller.Index() as ViewResult;

            // Assert
            List<Tweet> model = (List<Tweet>)result.ViewData.Model;
            Assert.AreEqual(fakeRepo.GetFrontpageTweets().Count(), model.Count);
        }

        [TestMethod]
        public void About()
        {
            // Arrange
            HomeController controller = new HomeController();

            // Act
            ViewResult result = controller.About() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
        }
    }
}
