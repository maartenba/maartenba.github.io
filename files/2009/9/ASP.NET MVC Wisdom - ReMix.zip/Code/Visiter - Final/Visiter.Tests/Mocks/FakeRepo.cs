﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Visiter.Models;
using Visiter.Data;

namespace Visiter.Tests.Mocks
{
    public class FakeRepo : ITweetRepository
    {
        List<Tweet> tweets = new List<Tweet>();

        public FakeRepo()
        {
            tweets.Add(new Tweet());
        }

        #region ITweetRepository Members

        public Visiter.Data.User GetUser(string userName)
        {
            throw new NotImplementedException();
        }

        public Visiter.Data.Tweet GetTweet(Guid id)
        {
            throw new NotImplementedException();
        }

        public IQueryable<Visiter.Data.Tweet> GetFrontpageTweets()
        {
            return tweets.AsQueryable();
        }

        public IQueryable<Visiter.Data.Tweet> GetTweetsBy(string userName)
        {
            throw new NotImplementedException();
        }

        public IQueryable<Visiter.Data.Tweet> GetPrivateTimeLine(string userName)
        {
            throw new NotImplementedException();
        }

        public void Add(Visiter.Data.Tweet tweet)
        {
            throw new NotImplementedException();
        }

        public void Delete(Visiter.Data.Tweet tweet)
        {
            throw new NotImplementedException();
        }

        public void Follow(string userName, string userToFollow)
        {
            throw new NotImplementedException();
        }

        public void Save()
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
