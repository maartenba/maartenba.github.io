﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using MvcViewInTheCloud.Code;
using Microsoft.Samples.ServiceHosting.StorageClient;

namespace MvcViewInTheCloud
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public class MvcApplication : System.Web.HttpApplication
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                "Default",                                              // Route name
                "{controller}/{action}/{id}",                           // URL with parameters
                new { controller = "Home", action = "Index", id = "" }  // Parameter defaults
            );

        }

        protected void Application_Start()
        {
            RegisterRoutes(RouteTable.Routes);

            // Register the virtual path provider with ASP.NET
            System.Web.Hosting.HostingEnvironment.RegisterVirtualPathProvider(new BlobStorageVirtualPathProvider(
                new StorageAccountInfo(
                    new Uri("http://blob.core.windows.net"),
                    false,
                    "your_storage_account_name_here",
                    "your_storage_account_key_here"),
                    "your_container_name_here"));
        }
    }
}