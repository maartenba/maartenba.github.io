﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using Microsoft.Samples.ServiceHosting.StorageClient;
using System.IO;

namespace MvcViewInTheCloud.Code
{
    public class BlobStorageVirtualPathProvider : VirtualPathProvider
    {
        protected readonly StorageAccountInfo accountInfo;
        protected readonly BlobContainer container;

        public BlobContainer BlobContainer
        {
            get { return container; }
        }

        public BlobStorageVirtualPathProvider(StorageAccountInfo storageAccountInfo, string containerName)
        {
            accountInfo = storageAccountInfo;
            BlobStorage blobStorage = BlobStorage.Create(accountInfo);
            container = blobStorage.GetBlobContainer(containerName);
        }

        public override bool FileExists(string virtualPath)
        {
            // Check if the file exists on blob storage
            string cleanVirtualPath = virtualPath.Replace("~", "").Substring(1);
            if (container.DoesBlobExist(cleanVirtualPath))
            {
                return true;
            }
            else
            {
                return Previous.FileExists(virtualPath);
            }
        } 

        public override VirtualFile GetFile(string virtualPath)
        {
            // Check if the file exists on blob storage
            string cleanVirtualPath = virtualPath.Replace("~", "").Substring(1);
            if (container.DoesBlobExist(cleanVirtualPath))
            {
                return new BlobStorageVirtualFile(virtualPath, this);
            }
            else
            {
                return Previous.GetFile(virtualPath);
            }
        }
    }

    public class BlobStorageVirtualFile : VirtualFile
    {
        protected readonly BlobStorageVirtualPathProvider parent;

        public BlobStorageVirtualFile(string virtualPath, BlobStorageVirtualPathProvider parentProvider) : base(virtualPath)
        {
            parent = parentProvider;
        }

        public override System.IO.Stream Open()
        {
            string cleanVirtualPath = this.VirtualPath.Replace("~", "").Substring(1);
            BlobContents contents = new BlobContents(new MemoryStream());
            parent.BlobContainer.GetBlob(cleanVirtualPath, contents, true);
            contents.AsStream.Seek(0, SeekOrigin.Begin);
            return contents.AsStream;
        }
    }

    public override System.Web.Caching.CacheDependency GetCacheDependency(string virtualPath, System.Collections.IEnumerable virtualPathDependencies, DateTime utcStart)
    {
        return null;
    }
}
