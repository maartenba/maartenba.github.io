﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace Bartender
{
    public class Order : INotifyPropertyChanged
    {
        private int pID;
        public int ID
        {
            get
            {
                return this.pID;
            }
            set
            {
                this.pID = value;
                NotifyPropertyChanged("ID");
            }
        }

        private string pName;
        public string Name
        {
            get
            {
                return this.pName;
            }
            set
            {
                this.pName = value;
                NotifyPropertyChanged("Name");
            }
        }

        private string pImageURL;
        public string ImageURL
        {
            get
            {
                return this.pImageURL;
            }
            set
            {
                this.pImageURL = value;
                NotifyPropertyChanged("ImageURL");
            }
        }

        private int pVotes;
        public int Votes
        {
            get
            {
                return this.pVotes;
            }
            set
            {
                this.pVotes = value;
                NotifyPropertyChanged("Votes");
                
                if (Visual != null)
                    AnimateElement(Visual);

            }
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }


        private Rectangle pVisual;
        public Rectangle Visual
        {
            get
            {
                return this.pVisual;
            }
            set
            {
                this.pVisual = value;
                NotifyPropertyChanged("Visual");
            }
        }

        #endregion


        private void AnimateElement(Rectangle objectToBeAnimated)
        {

            Storyboard sb = new Storyboard();

            DoubleAnimationUsingKeyFrames animOpacity = new DoubleAnimationUsingKeyFrames();
            //animOpacity.KeyFrames.Add(getSplineDoubleKeyFrame(0, 0));
            animOpacity.KeyFrames.Add(getSplineDoubleKeyFrame(0.2, 1));
            animOpacity.KeyFrames.Add(getSplineDoubleKeyFrame(0.8, 0));

            Storyboard.SetTarget(animOpacity, objectToBeAnimated);
            Storyboard.SetTargetProperty(animOpacity, new PropertyPath("(Opacity)"));

            sb.Children.Add(animOpacity);

            sb.Begin();

        }
        

        /// <summary>
        /// Create SplineDoubleKeyFrame, based on seconds for duration and value to animate to
        /// </summary>
        /// <param name="seconds"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        private static SplineDoubleKeyFrame getSplineDoubleKeyFrame(double seconds, double value)
        {
            return new SplineDoubleKeyFrame()
            {
                KeyTime = KeyTime.FromTimeSpan(TimeSpan.FromSeconds(seconds))
               ,
                Value = value
            };
        }

    }
}
