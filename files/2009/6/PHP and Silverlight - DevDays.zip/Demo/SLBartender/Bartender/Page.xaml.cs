﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using SilverlightContrib.Tweener;

namespace Bartender
{
    public partial class Page : UserControl
    {

        

        public Page()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(Page_Loaded);

        }

        void Page_Loaded(object sender, RoutedEventArgs e)
        {
            AnimateIn();
        }

        private void AnimateIn()
        {

             Storyboard sbIn = new Storyboard();

            DoubleAnimationUsingKeyFrames animTop = Tween.CreateAnimation(TransitionType.EaseOutBounce, -1250, 0, TimeSpan.FromMilliseconds(2000));

            Storyboard.SetTarget(animTop, grdWelcomeMessage);
            Storyboard.SetTargetProperty(animTop, new PropertyPath("(UIElement.RenderTransform).(TransformGroup.Children)[3].(TranslateTransform.Y)"));

            sbIn.Children.Add(animTop);

            sbIn.Begin();

            

        }

        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {
            LayoutRoot.Children.Clear();
            LayoutRoot.Children.Add(new MainStage());
        }

   
    }
}
