﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using SilverlightContrib.Tweener;
using System.Json;
using System.Windows.Threading;


namespace Bartender
{
    public partial class MainStage : UserControl
    {
        public ObservableCollection<Notification> Notifications { get; set; }
        public ObservableCollection<Order> Orders { get; set; }
        public DispatcherTimer timer { get; set; }

        public MainStage()
        {
            InitializeComponent();

            InitializeData();

            this.Loaded += new RoutedEventHandler(MainStage_Loaded);

        }

        private void InitializeData()
        {

            Notifications = new ObservableCollection<Notification>();
            Orders = new ObservableCollection<Order>();

            // create a few notifications

            Notifications.Add(new Notification() { NotificationText = "Bartender initialized" });
            
            lstNotifications.ItemsSource = Notifications;
            lstOrders.ItemsSource = Orders;

        }

       

        private void FetchOrders()
        {
            // call service, JSON

            Uri serviceUri = new Uri("http://www.demotime.net/BarTender/Service/Json.php?m=retrieveall", UriKind.Absolute);
            WebClient downloader = new WebClient();
            downloader.OpenReadCompleted += new OpenReadCompletedEventHandler(downloader_OpenReadCompleted);
            downloader.OpenReadAsync(serviceUri);
        }

        void downloader_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            // get result, put into list

            if (e.Error == null)
            {

                JsonArray jsonArray = (JsonArray)JsonArray.Load(e.Result);

                var query = from order in jsonArray
                            select new Order()
                            {
                                ID = Int32.Parse(order["Id"]),
                                ImageURL = order["ImageUrl"],
                                Name = order["Name"],
                                Votes = Int32.Parse(order["Votes"])
                            };

                foreach (var item in query)
                {
                    if (item.Votes > 0)
                        Orders.Add(item);
                }

                // start timer for refetch

                timer = new DispatcherTimer();
                timer.Interval = new TimeSpan(0, 0, 5);
                timer.Tick += new EventHandler(timer_Tick);
                timer.Start();
            }
            else
            {
                MessageBox.Show("Error on data fetch");
            }
        }

        void timer_Tick(object sender, EventArgs e)
        {
            RefetchOrders();
        }


        private void RefetchOrders()
        {
            // call service, JSON, add datetimeticks to avoid the cached result being used

            Uri serviceUri = new Uri("http://www.demotime.net/BarTender/Service/Json.php?m=retrieveall&avoidcache=" + DateTime.Now.Ticks.ToString(), UriKind.Absolute);
            WebClient downloader = new WebClient();
            downloader.OpenReadCompleted += new OpenReadCompletedEventHandler(downloader_OpenRefetchReadCompleted);
            downloader.OpenReadAsync(serviceUri);


        }

        void downloader_OpenRefetchReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            // get result, put into list

            JsonArray jsonArray = (JsonArray)JsonArray.Load(e.Result);

            var query = from order in jsonArray
                        select new Order()
                        {
                            ID = Int32.Parse(order["Id"]),
                            ImageURL = order["ImageUrl"],
                            Name = order["Name"],
                            Votes = Int32.Parse(order["Votes"])
                        };

            foreach (var item in query)
            {
                // order already in list?

                Order currentOrder = Orders.FirstOrDefault(o => o.ID == item.ID);

                if (currentOrder != null)
                {
                    // replace the number of votes in the collection
                    if (currentOrder.Votes != item.Votes)
                    {
                        // add notification
                        AddNotification(item.Name, item.Votes - currentOrder.Votes);
                        // replace votes
                        currentOrder.Votes = item.Votes;
                    }
                }
                else
                {
                    // insert
                    if (item.Votes > 0)
                    {
                        Orders.Add(item);
                        AddNotification(item.Name, item.Votes - currentOrder.Votes);
                    }
                }
            }
        }
 

        void MainStage_Loaded(object sender, RoutedEventArgs e)
        {
            AnimateIn();
        }

        private void AnimateIn()
        {

            // animate left side
            Storyboard sbLeft = new Storyboard();

            DoubleAnimationUsingKeyFrames animLeft = Tween.CreateAnimation(TransitionType.EaseOutBounce, -300, 0, TimeSpan.FromMilliseconds(1250));
            Storyboard.SetTarget(animLeft, grid1);
            Storyboard.SetTargetProperty(animLeft, new PropertyPath("(UIElement.RenderTransform).(TransformGroup.Children)[3].(TranslateTransform.X)"));
            sbLeft.Children.Add(animLeft);

            sbLeft.Begin();

            // animate right side
            Storyboard sbRight = new Storyboard();

            DoubleAnimationUsingKeyFrames animRight = Tween.CreateAnimation(TransitionType.EaseOutBounce, 1000, 0, TimeSpan.FromMilliseconds(1250));
            Storyboard.SetTarget(animRight, border);
            Storyboard.SetTargetProperty(animRight, new PropertyPath("(UIElement.RenderTransform).(TransformGroup.Children)[3].(TranslateTransform.X)"));
            sbRight.Children.Add(animRight);

            sbRight.Begin();

            // fetch orders once we 're animated in
            EventHandler handler = null;
            handler = (send, arg) =>
                {
                    sbRight.Completed -= handler;
                    FetchOrders();
                };
            sbRight.Completed += handler;


        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            // add order

            // find in list (assume true for now), add order
            Order order = Orders.FirstOrDefault(p => p.ID == 1);
            order.Votes++;

            AddNotification(order.Name, 1);

        }

        private void AddNotification(string name, int count)
        {
            Notification notifNew = new Notification() { NotificationText = count.ToString() + " " + name + " ordered" };
            Notifications.Insert(0, notifNew);

            popNotification.DataContext = notifNew;

            EventHandler handler = null;
            handler = (send, arg) =>
            {
                sbOpenPopup.Completed -= handler;
                popNotification.IsOpen = false;
                popNotification.DataContext = null;
            };
            sbOpenPopup.Completed += handler;
            sbOpenPopup.Begin();

            popNotification.IsOpen = true;
        }


      



        private void Rectangle_Loaded(object sender, RoutedEventArgs e)
        {

            // get the visual element to animate when an item has been added.
            if (Orders.FirstOrDefault(p => p == ((Rectangle)sender).DataContext) != null)
            {
                Orders.FirstOrDefault(p => p == ((Rectangle)sender).DataContext).Visual = (Rectangle)sender;
            }
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            // stretch
            FrameworkElement t = sender as FrameworkElement;
            ContentPresenter p = VisualTreeHelper.GetParent(t) as ContentPresenter;
            p.HorizontalAlignment = HorizontalAlignment.Stretch;
        }

    }
}
