<?php
/** Setup application */
require_once '../Setup.php';

/** Zend_Db */
require_once 'Zend/Db.php';

/** Zend_Registry */
require_once 'Zend/Registry.php';

/** BarTender_Core_Beer */
require_once 'BarTender/Core/Beer.php';

/** BarTender_Core_BeerCollection */
require_once 'BarTender/Core/BeerCollection.php';

/** BarTender_Core_BeerRepository */
require_once 'BarTender/Core/BeerRepository.php';

// Setup database connection
$database = Zend_Db::factory($configuration->database);
Zend_Registry::set('database', $database);
	
// Setup BarTender_Core_BeerRepository
$beerRepository = new BarTender_Core_BeerRepository($database);
Zend_Registry::set('beerRepository', $beerRepository);

/** Zend_Controller_Front */
require_once 'Zend/Controller/Front.php';

/** Zend_Layout */
require_once 'Zend/Layout.php';

// Setup controller
$controller = Zend_Controller_Front::getInstance();
$controller->setControllerDirectory('Application/Controllers');
$controller->throwExceptions(true); // should be turned on in development time 

// Bootstrap layouts
Zend_Layout::startMvc(array(
    'layoutPath' => 'Application/Layouts',
    'layout' => 'Main'
	));

// run!
$controller->dispatch();
