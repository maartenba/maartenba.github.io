<?php

/**
 * IndexController - The default controller class
 * 
 * @author
 * @version 
 */

require_once 'Zend/Controller/Action.php';

/** Zend_Registry */
require_once 'Zend/Registry.php';

/** BarTender_Core_Beer */
require_once 'BarTender/Core/Beer.php';

/** BarTender_Core_BeerCollection */
require_once 'BarTender/Core/BeerCollection.php';

/** BarTender_Core_BeerRepository */
require_once 'BarTender/Core/BeerRepository.php';

class IndexController extends Zend_Controller_Action 
{
	/**
	 * The default action - show the home page
	 */
    public function indexAction() 
    {
    	$beerRepository = Zend_Registry::get('beerRepository');
    	
		$this->view->beers = $beerRepository->retrieveAll();
    }
    
	/**
	 * The vote action - vote for beer
	 */
    public function voteAction() 
    {
    	$id = $this->_getParam('id');
    	
    	$beerRepository = Zend_Registry::get('beerRepository');
    	$beerRepository->addVoteForId($id);
    	
    	$this->_helper->getHelper('Redirector')->gotoRoute(array(
    		'controller' => 'index',
    		'action' => 'voted',
    		'id' => $id
    	));
    }
    
	/**
	 * The voted action - voted for beer
	 */
    public function votedAction() 
    {
    	$id = $this->_getParam('id');
    	
    	$beerRepository = Zend_Registry::get('beerRepository');
    	
    	$this->view->beer = $beerRepository->retrieveById($id);
    }
}
