<?php
/** Error reporting */
error_reporting(E_ALL);

/** Include path **/
set_include_path(get_include_path() . PATH_SEPARATOR . '../../');

/** Zend_Config */
require_once 'Zend/Config.php';

// Create configuration data
$configuration = new Zend_Config(array(
    'database' => array(
        'adapter' => 'Pdo_Sqlite',
        'params'  => array(
            'dbname'   => '../Data/db.sqlite'
        )
    )
));