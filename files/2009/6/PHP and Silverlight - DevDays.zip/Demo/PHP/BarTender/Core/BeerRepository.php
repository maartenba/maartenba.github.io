<?php
/** Zend_Db */
require_once 'Zend/Db.php';

/** Zend_Db_Adapter_Abstract */
require_once 'Zend/Db/Adapter/Abstract.php';

/** Zend_Db_Table */
require_once 'Zend/Db/Table.php';

/** BarTender_Core_BeerTable */
require_once 'BarTender/Core/BeerTable.php';

/** BarTender_Core_Beer */
require_once 'BarTender/Core/Beer.php';

/** BarTender_Core_BeerCollection */
require_once 'BarTender/Core/BeerCollection.php';

/**
 * BarTender_Core_BeerRepository
 */
class BarTender_Core_BeerRepository {
	/**
	 * Database adapter
	 * 
	 * @var Zend_Db_Adapter_Abstract
	 */
	private $_db;
	
	/**
	 * Beer table
	 * 
	 * @var BarTender_Core_Beer
	 */
	private $_beerTable;
	
	/**
	 * Create a new BeerRepository
	 * 
	 * @param Zend_Db_Adapter_Abstract $databaseAdapter Database adapter
	 */
	public function __construct(Zend_Db_Adapter_Abstract $databaseAdapter)
	{
		$this->_db = $databaseAdapter;
		$this->_beerTable = new BarTender_Core_BeerTable(array(
			'db' => $this->_db
		));
	}
	
	/**
	 * Retrieve all
	 * 
	 * @return BarTender_Core_BeerCollection
	 */
	public function retrieveAll()
	{
		return $this->_beerTable->fetchAll();
	}
	
	/**
	 * Retrieve by id
	 * 
	 * @param int $id 
	 * @return BarTender_Core_Beer
	 */
	public function retrieveById($id = 0)
	{
		return $this->_beerTable->fetchRow(
			$this->_beerTable->select()->where('Id = ?', $id)
		);
	}
	
	/**
	 * Add vote for BarTender_Core_Beer
	 *
	 * @param int $id
	 * @return boolean
	 */
	public function addVoteForId($id = 0)
	{
		$data = array(
			'Votes' => new Zend_Db_Expr('Votes + 1')
		);
		
		$where = $this->_beerTable->getAdapter()->quoteInto('Id = ?', $id);
		
		$this->_beerTable->update($data, $where);
		
		return true;
	}
}
