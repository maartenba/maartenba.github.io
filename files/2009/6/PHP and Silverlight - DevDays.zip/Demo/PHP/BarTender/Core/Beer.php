<?php
/** Zend_Db_Table_Row_Abstract */
require_once 'Zend/Db/Table/Row/Abstract.php';

/**
 * BarTender_Core_Beer
 */
class BarTender_Core_Beer extends Zend_Db_Table_Row_Abstract {
	/**
	 * Beer id
	 * 
	 * @var int
	 */
    public $Id;
    
    /**
     * Beer name
     * 
     * @var string
     */
    public $Name;
    
    /**
     * Beer image url
     * 
     * @var string
     */
    public $ImageUrl;
    
    /**
     * Votes for beer
     * 
     * @var int
     */
    public $Votes;
    
    /**
     * BarTender_Core_Beer Constructor
     *
     * @param  array $config OPTIONAL Array of user-specified config options.
     * @throws Zend_Db_Table_Row_Exception
     */
    public function __construct(array $config = array())
    {
    	parent::__construct($config);
    	
    	$this->Id 			= $this->_data['Id'];
    	$this->Name 		= $this->_data['Name'];
    	$this->ImageUrl 	= $this->_data['ImageUrl'];
    	$this->Votes 		= $this->_data['Votes'];
    }
}
