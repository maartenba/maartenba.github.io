<?php
/** Zend_Db_Table_Rowset_Abstract */
require_once 'Zend/Db/Table/Rowset/Abstract.php';

/** BarTender_Core_Beer */
require_once 'BarTender/Core/Beer.php';

/**
 * BarTender_Core_BeerCollection
 */
class BarTender_Core_BeerCollection extends Zend_Db_Table_Rowset_Abstract {
	
}
