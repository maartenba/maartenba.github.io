<?php
/** Zend_Db_Table */
require_once 'Zend/Db/Table.php';

/** BarTender_Core_Beer */
require_once 'BarTender/Core/Beer.php';

/** BarTender_Core_BeerCollection */
require_once 'BarTender/Core/BeerCollection.php';

/**
 * BarTender_Core_BeerTable
 */
class BarTender_Core_BeerTable extends Zend_Db_Table {
    protected $_name = 'beer'; // table name
    protected $_primary = 'Id';
    protected $_rowClass = 'BarTender_Core_Beer';
    protected $_rowsetClass = 'BarTender_Core_BeerCollection';
}
