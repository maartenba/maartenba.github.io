<?php
/** Set time limit */
set_time_limit(0);

/** Setup application */
require_once '../Setup.php';

/** Zend_Db */
require_once 'Zend/Db.php';

/** Zend_Db_Table */
require_once 'Zend/Db/Table.php';

// Setup database connection
$db = Zend_Db::factory($configuration->database);

// Maximum beer ID
$maxBeerId = 12;

// Go order!
for ($i = 0; $i < 100; $i++)
{
    $beerId = rand(1, $maxBeerId);
    $db->query("UPDATE beer SET Votes = Votes + 1 WHERE Id = $beerId;");
    echo 'Ordered ' . $beerId . '<br />';
    sleep( rand(1, 10) );
}

// Done!
echo 'Done.';
