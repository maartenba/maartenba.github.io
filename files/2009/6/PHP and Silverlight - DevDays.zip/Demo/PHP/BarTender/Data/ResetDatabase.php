<?php
/** Setup application */
require_once '../Setup.php';

/** Zend_Db */
require_once 'Zend/Db.php';

/** Zend_Db_Table */
require_once 'Zend/Db/Table.php';

// Delete database file
@unlink('../Data/db.sqlite');

// Setup database connection
$db = Zend_Db::factory($configuration->database);

// Create tables
$createTables = '
	CREATE TABLE beer (
		Id        		INTEGER NOT NULL PRIMARY KEY,
		Name			VARCHAR(100),
		ImageUrl		VARCHAR(200),
		Votes			INTEGER
	);
';
$db->query($createTables);

// Add sample data
$db->query("INSERT INTO beer (Id, Name, ImageUrl, Votes) values (1, 	'Bud', 					'http://www.demotime.net/BarTender/Web/Images/1.jpg', 0);");
$db->query("INSERT INTO beer (Id, Name, ImageUrl, Votes) values (2, 	'Grolsch Premium', 		'http://www.demotime.net/BarTender/Web/Images/2.jpg', 0);");
$db->query("INSERT INTO beer (Id, Name, ImageUrl, Votes) values (3, 	'Jupiler', 				'http://www.demotime.net/BarTender/Web/Images/3.jpg', 0);");
$db->query("INSERT INTO beer (Id, Name, ImageUrl, Votes) values (4, 	'Stella Artois', 		'http://www.demotime.net/BarTender/Web/Images/4.jpg', 0);");
$db->query("INSERT INTO beer (Id, Name, ImageUrl, Votes) values (5, 	'Vedett Extra - Blond',	'http://www.demotime.net/BarTender/Web/Images/5.jpg', 0);");
$db->query("INSERT INTO beer (Id, Name, ImageUrl, Votes) values (6, 	'Lindemans Kriek', 		'http://www.demotime.net/BarTender/Web/Images/6.jpg', 0);");
$db->query("INSERT INTO beer (Id, Name, ImageUrl, Votes) values (7, 	'Belle-Vue Kriek', 		'http://www.demotime.net/BarTender/Web/Images/7.jpg', 0);");
$db->query("INSERT INTO beer (Id, Name, ImageUrl, Votes) values (8, 	'Chimay Blauw', 		'http://www.demotime.net/BarTender/Web/Images/8.jpg', 0);");
$db->query("INSERT INTO beer (Id, Name, ImageUrl, Votes) values (9, 	'Grimbergen - Blond', 	'http://www.demotime.net/BarTender/Web/Images/9.jpg', 0);");
$db->query("INSERT INTO beer (Id, Name, ImageUrl, Votes) values (10, 	'Westmalle Tripel',		'http://www.demotime.net/BarTender/Web/Images/10.jpg', 0);");
$db->query("INSERT INTO beer (Id, Name, ImageUrl, Votes) values (11, 	'Rochefort 8', 			'http://www.demotime.net/BarTender/Web/Images/11.jpg', 0);");
$db->query("INSERT INTO beer (Id, Name, ImageUrl, Votes) values (12, 	'Orval',	 			'http://www.demotime.net/BarTender/Web/Images/12.jpg', 0);");

// Done!
echo 'Database reset.';