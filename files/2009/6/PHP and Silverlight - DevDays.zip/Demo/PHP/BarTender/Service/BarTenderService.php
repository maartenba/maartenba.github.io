<?php 
/** Setup application */
require_once '../Setup.php';

/** Zend_Db */
require_once 'Zend/Db.php';

/** BarTender_Core_BeerRepository */
require_once 'BarTender/Core/BeerRepository.php';

/** Zend_Soap_Server */
require_once 'Zend/Soap/Server.php';

/** Zend_Soap_AutoDiscover */
require_once 'Zend/Soap/AutoDiscover.php';

/** Zend_Soap_Wsdl_Strategy_ArrayOfTypeComplex */
require_once "Zend/Soap/Wsdl/Strategy/ArrayOfTypeComplex.php";

// Setup service
if (isset($_GET['wsdl']) && isset($_GET['discovery'])) {
	// Set SOAP discovery strategy
	$strategy = new Zend_Soap_Wsdl_Strategy_ArrayOfTypeComplex();
	
	// Handle WSDL call
    $autodiscover = new Zend_Soap_AutoDiscover($strategy);
    $autodiscover->setClass('BarTender_Service_BarTenderService');
    $autodiscover->handle();
} else if (isset($_GET['wsdl'])) {
	header('Content-Type: text/xml');
	echo file_get_contents('endpoint.wsdl');
	die();
} else {
	// Setup database connection
	$database = Zend_Db::factory($configuration->database);
	
	// Setup BarTender_Core_BeerRepository
	$beerRepository = new BarTender_Core_BeerRepository($database);
	
	// Handle SOAP call
    $soap = new Zend_Soap_Server('endpoint.wsdl');
    $soap->setObject(new BarTender_Service_BarTenderService($beerRepository));
    $soap->handle();
}

/**
 * BarTender_Service_BarTenderService
 */
class BarTender_Service_BarTenderService
{
	/**
	 * BarTender_Core_BeerRepository
	 * 
	 * @var BarTender_Core_BeerRepository
	 */
	private $_beerRepository;
	
	/**
	 * BarTender_Service_BarTenderService constructor
	 * 
	 * @param BarTender_Core_BeerRepository $beerRepository
	 */
	public function __construct(BarTender_Core_BeerRepository $beerRepository)
	{
		$this->_beerRepository = $beerRepository;
	}
	
	/**
	 * Retrieve all
	 * 
	 * @return BarTender_Core_Beer[]
	 */
	public function RetrieveAll()
	{
		$allBeer = $this->_beerRepository->retrieveAll();
		$returnValue = array();
		foreach ($allBeer as $beer) {
			$returnValue[] = $beer;
		}
		return $returnValue;
	}
	
	/**
	 * Retrieve by id
	 * 
	 * @param int $id
	 * @return BarTender_Core_Beer
	 */
	public function RetrieveById($id = 0)
	{
		return $this->_beerRepository->retrieveById($id);
	}
	
	/**
	 * Add vote for BarTender_Core_Beer
	 *
	 * @param int $id
	 * @return boolean
	 */
	public function AddVoteForId($id = 0)
	{
		return $this->_beerRepository->addVoteForId($id);
	}
}