<?php 
/** Setup application */
require_once '../Setup.php';

/** Zend_Db */
require_once 'Zend/Db.php';

/** BarTender_Core_BeerRepository */
require_once 'BarTender/Core/BeerRepository.php';

/** Zend_Json */
require_once 'Zend/Json.php';

// Setup database connection
$database = Zend_Db::factory($configuration->database);
	
// Setup BarTender_Core_BeerRepository
$beerRepository = new BarTender_Core_BeerRepository($database);

// HTTP header
header('Content-Type: application/json');

// Determine action
if (isset($_GET['m']))
{
    switch (strtolower($_GET['m']))
    {
        case 'retrieveall':
            $allBeer = $beerRepository->retrieveAll();
            $returnValue = array();
            foreach ($allBeer as $beer) {
                $returnValue[] = $beer;
            }
            echo Zend_Json::encode($returnValue);
            break;

        case 'retrievebyid':
            echo Zend_Json::encode($beerRepository->retrieveById($_GET['id']));
            break;

        case 'addvoteforid':
            echo Zend_Json::encode($beerRepository->addVoteForId($_GET['id']));
            break;
    }
}