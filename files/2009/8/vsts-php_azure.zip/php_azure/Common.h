#pragma once
#include <string>
#include <windows.h>
void Initialize();
void LogCritical(LPCSTR message);
void LogError(LPCSTR message);
void LogWarning(LPCSTR message);
void LogInformation(LPCSTR message);
void LogVerbose(LPCSTR message);
std::string GetConfigurationSetting(LPCSTR message);
std::string GetLocalResourceRootPath(LPCSTR name);
long GetLocalResourceRootPathSize(LPCSTR name);