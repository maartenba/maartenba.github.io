#include "Common.h" 
#include <ServiceHosting.h> 

static void WriteToLog(LPCSTR log,LPCSTR msg) 
{ 
    HRESULT hr = RoleManagerWriteToLogA(log,msg); 
    if(FAILED(hr))  
    { 
        throw "Error writing to log."; 
    } 
} 
void Initialize() 
{ 
    HRESULT hr = RoleManagerInitialize(); 
    if(FAILED(hr)) 
    { 
        throw "Error in initalize"; 
    } 
} 
void LogCritical(LPCSTR message) 
{ 
    WriteToLog("Critical",message); 
} 
void LogError(LPCSTR message) 
{ 
    WriteToLog("Error",message); 
} 
void LogWarning(LPCSTR message) 
{ 
    WriteToLog("Warning",message); 
} 
void LogInformation(LPCSTR message) 
{ 
    WriteToLog("Information",message); 
} 
void LogVerbose(LPCSTR message) 
{ 
    WriteToLog("Verbose",message); 
} 

std::string GetConfigurationSetting(LPCSTR key)
{
    CHAR sbuf[512];  
    LPSTR buf = sbuf;
    size_t len = sizeof(sbuf);
    size_t required;
    HRESULT hr = RoleManagerGetConfigurationSetting(key,buf,len,&required);
    if(hr == ROLEMANAGER_E_INSUFFICIENT_BUFFER)
    {
        buf = new CHAR[required];
        hr = RoleManagerGetConfigurationSetting(key,buf,required,NULL);
    }
    if(FAILED(hr))
    {
        if(buf != sbuf)
        {
            delete buf;
        }
        throw  "Error reading configuration setting."; 
    }
    else 
    {
        std::string ret(buf);
        if(buf != sbuf)
        {
            delete buf;
        }
        return ret;
    }
}

std::string GetLocalResourceRootPath(LPCSTR name)
{
	LPLOCALRESOURCE resource = NULL;
	RoleManagerGetLocalResource(name, &resource);

    CHAR sbuf[512];  
    LPSTR buf = sbuf;
    size_t len = sizeof(sbuf);
    size_t required;
    HRESULT hr = LocalResourceGetRootPath(resource,buf,len,&required);
    if(hr == ROLEMANAGER_E_INSUFFICIENT_BUFFER)
    {
        buf = new CHAR[required];
        hr = LocalResourceGetRootPath(resource,buf,len,NULL);
    }
    if(FAILED(hr))
    {
        if(buf != sbuf)
        {
            delete buf;
        }
        throw  "Error reading local resource path setting."; 
    }
    else 
    {
        std::string ret(buf);
        if(buf != sbuf)
        {
            delete buf;
        }
        return ret;
    }
}

long GetLocalResourceRootPathSize(LPCSTR name)
{
	LPLOCALRESOURCE resource = NULL;
	RoleManagerGetLocalResource(name, &resource);

	ULONG size = 0;
    HRESULT hr = LocalResourceGetMaximumSizeInMegaBytes(resource, &size);
    if(FAILED(hr))
    {
        throw  "Error reading local resource path setting."; 
    }
    else 
    {
        return (long)size;
    }
}