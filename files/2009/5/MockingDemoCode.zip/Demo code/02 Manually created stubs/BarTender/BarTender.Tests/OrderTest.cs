﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BarTender.Tests
{
    /// <summary>
    /// BarTenderTests
    /// </summary>
    [TestClass]
    public class OrderTest
    {
        public OrderTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Order_2Duvel_2Duvel()
        {
            // Arrange
            var ws = new DummyWeatherService();
            var ks = new KitchenService();
            var nd = new NutDistributor();
            BarTender target = new BarTender(ws, ks, nd);

            // Act
            List<IConsumable> order = target.OrderBeer<Duvel>(2);

            // Assert
            Assert.AreEqual(2, order.Count);
            Assert.IsInstanceOfType(order[0], typeof(Duvel));
            Assert.IsFalse(ks.HasBeenCalled);
            Assert.IsFalse(nd.HasBeenCalled);
        }

        [TestMethod]
        public void Order_2DuvelInTheSun_2DuvelAndCheese()
        {
            // Arrange
            var ws = new SunnyWeatherService();
            var ks = new KitchenService();
            var nd = new NutDistributor();
            BarTender target = new BarTender(ws, ks, nd);

            // Act
            List<IConsumable> order = target.OrderBeer<Duvel>(2);

            // Assert
            Assert.AreEqual(3, order.Count);
            Assert.IsInstanceOfType(order[0], typeof(Duvel));
            Assert.IsInstanceOfType(order[2], typeof(Cheese));
            Assert.IsTrue(ks.HasBeenCalled);
            Assert.IsFalse(nd.HasBeenCalled);
        }

        [TestMethod]
        public void Order_2DuvelInTheRain_2DuvelAndNuts()
        {
            // Arrange
            var ws = new RainyWeatherService();
            var ks = new KitchenService();
            var nd = new NutDistributor();
            BarTender target = new BarTender(ws, ks, nd);

            // Act
            List<IConsumable> order = target.OrderBeer<Duvel>(2);

            // Assert
            Assert.AreEqual(3, order.Count);
            Assert.IsInstanceOfType(order[0], typeof(Duvel));
            Assert.IsInstanceOfType(order[2], typeof(Nuts));
            Assert.IsFalse(ks.HasBeenCalled);
            Assert.IsTrue(nd.HasBeenCalled);
        }

        class DummyWeatherService : IWeatherService
        {

            #region IWeatherService Members

            public string WhatsTheWeather()
            {
                return "";
            }

            #endregion
        }

        class SunnyWeatherService : IWeatherService
        {

            #region IWeatherService Members

            public string WhatsTheWeather()
            {
                return "sunny";
            }

            #endregion
        }

        class RainyWeatherService : IWeatherService
        {

            #region IWeatherService Members

            public string WhatsTheWeather()
            {
                return "rainy";
            }

            #endregion
        }

        class KitchenService : IKitchenService
        {
            public bool HasBeenCalled { get; set; }

            #region IKitchenService Members

            public void Order(IConsumable item)
            {
                HasBeenCalled = true;
            }

            #endregion
        }

        class NutDistributor : INutDistributor
        {
            public bool HasBeenCalled { get; set; }

            #region INutDistributor Members

            public void FillCup()
            {
                HasBeenCalled = true;
            }

            #endregion
        }
    }
}
