﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BarTender
{
    public class Cheese : ISnack
    {
        #region ISnack Members

        public string Eat()
        {
            return "mmmm";
        }

        #endregion

        #region IConsumable Members

        public string Consume()
        {
            return Eat();
        }

        #endregion
    }
}
