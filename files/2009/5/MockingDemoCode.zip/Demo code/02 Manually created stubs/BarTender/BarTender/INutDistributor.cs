﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BarTender
{
    public interface INutDistributor
    {
        void FillCup();
    }
}
