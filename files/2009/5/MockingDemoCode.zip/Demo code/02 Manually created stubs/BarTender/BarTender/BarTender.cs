﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BarTender
{
    public class BarTender
    {
        protected IWeatherService ws;
        protected IKitchenService ks;
        protected INutDistributor nd;

        public BarTender(IWeatherService w, IKitchenService k, INutDistributor n)
        {
            ws = w;
            ks = k;
            nd = n;
        }

        public List<IConsumable> OrderBeer<T>(int p)
            where T : IBeer, new()
        {
            List<IConsumable> order = new List<IConsumable>();

            for (int i = 0; i < p; i++)
            {
                order.Add(new T());
            }

            if (ws.WhatsTheWeather() == "sunny")
            {
                ks.Order(new Cheese());
                order.Add(new Cheese());
            }
            else if (ws.WhatsTheWeather() == "rainy")
            {
                nd.FillCup();
                order.Add(new Nuts());
            }

            return order;
        }
    }
}
