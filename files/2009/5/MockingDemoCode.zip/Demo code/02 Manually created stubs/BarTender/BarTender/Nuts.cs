﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BarTender
{
    public class Nuts : ISnack
    {
        #region ISnack Members

        public string Eat()
        {
            return "good";
        }

        #endregion

        #region IConsumable Members

        public string Consume()
        {
            return Eat();
        }

        #endregion
    }
}
