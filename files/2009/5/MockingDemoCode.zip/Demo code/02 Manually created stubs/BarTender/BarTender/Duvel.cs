﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BarTender
{
    public class Duvel : IBeer
    {
        #region IBeer Members

        public string Drink()
        {
            return "More!";
        }

        #endregion

        #region IConsumable Members

        public string Consume()
        {
            return Drink();
        }

        #endregion
    }
}
