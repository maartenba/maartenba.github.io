﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace BarTender.Tests
{
    /// <summary>
    /// BarTenderTests
    /// </summary>
    [TestClass]
    public class OrderTest
    {
        public OrderTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Order_2Duvel_2Duvel()
        {
            // Arrange
            var ws = new Mock<IWeatherService>();
            var ks = new Mock<IKitchenService>();
            var nd = new Mock<INutDistributor>();
            BarTender target = new BarTender(ws.Object, ks.Object, nd.Object);

            // Act
            List<IConsumable> order = target.OrderBeer<Duvel>(2);

            // Assert
            Assert.AreEqual(2, order.Count);
            Assert.IsInstanceOfType(order[0], typeof(Duvel));
            ks.Verify(s => s.Order(It.IsAny<IConsumable>()), Times.Never());
            nd.Verify(s => s.FillCup(), Times.Never());
        }

        [TestMethod]
        public void Order_2DuvelInTheSun_2DuvelAndCheese()
        {
            // Arrange
            var ws = new Mock<IWeatherService>();
            ws.Setup(s => s.WhatsTheWeather()).Returns("sunny");

            var ks = new Mock<IKitchenService>();
            var nd = new Mock<INutDistributor>();
            BarTender target = new BarTender(ws.Object, ks.Object, nd.Object);

            // Act
            List<IConsumable> order = target.OrderBeer<Duvel>(2);

            // Assert
            Assert.AreEqual(3, order.Count);
            Assert.IsInstanceOfType(order[0], typeof(Duvel));
            Assert.IsInstanceOfType(order[2], typeof(Cheese));
            ks.Verify(s => s.Order(It.IsAny<IConsumable>()), Times.Exactly(1));
            nd.Verify(s => s.FillCup(), Times.Never());
        }

        [TestMethod]
        public void Order_2DuvelInTheRain_2DuvelAndNuts()
        {
            // Arrange
            var ws = new Mock<IWeatherService>();
            ws.Setup(s => s.WhatsTheWeather()).Returns("rainy");

            var ks = new Mock<IKitchenService>();
            var nd = new Mock<INutDistributor>();
            BarTender target = new BarTender(ws.Object, ks.Object, nd.Object);

            // Act
            List<IConsumable> order = target.OrderBeer<Duvel>(2);

            // Assert
            Assert.AreEqual(3, order.Count);
            Assert.IsInstanceOfType(order[0], typeof(Duvel));
            Assert.IsInstanceOfType(order[2], typeof(Nuts));
            ks.Verify(s => s.Order(It.IsAny<IConsumable>()), Times.Never());
            nd.Verify(s => s.FillCup(), Times.Exactly(1));
        }
    }
}
