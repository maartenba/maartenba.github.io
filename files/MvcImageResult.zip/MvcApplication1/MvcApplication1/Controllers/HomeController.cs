﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using System.Drawing;
using System.Drawing.Imaging;
using MvcApplication1.Code;

namespace MvcApplication1.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewData["Title"] = "Home Page";
            ViewData["Message"] = "Welcome to ASP.NET MVC!";

            return RenderView();
        }

        public ActionResult About()
        {
            ViewData["Title"] = "About Page";

            return RenderView();
        }

        public ActionResult DisplayTime()
        {
            Bitmap bmp = new Bitmap(200, 50);
            Graphics g = Graphics.FromImage(bmp);

            g.FillRectangle(Brushes.White, 0, 0, 200, 50);
            g.DrawString(DateTime.Now.ToShortTimeString(), new Font("Arial", 32), Brushes.Red, new PointF(0, 0));

            return new ImageResult { Image = bmp, ImageFormat = ImageFormat.Jpeg };
        }
    }
}
