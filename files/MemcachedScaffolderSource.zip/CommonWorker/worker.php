<?php
while(true) {
  // Your worker role code goes in here.
  //
  // Note that whenever the control loop ends or breaks,
  // the worker role instance will automatically restart.
}