<?php
/**
 * 2007HealthCareSamplePHP
 *
 * Simplified version of http://msdn2.microsoft.com/en-us/library/bb879915.aspx
 *
 * @author Maarten Balliauw http://blog.maartenballiauw.be
 */
?>
<html>
	<head>
		<title>Using Office Open XML Formats to Support Electronic Health Records Portability and Health Industry Standards - PHP Example</title>
		
		<link rel="stylesheet" type="text/css" href="styles.css" />
	</head>
	
	<body>
		<h1>Using Office Open XML Formats to Support Electronic Health Records Portability and Health Industry Standards - PHP Example</h1>
				
		<fieldset>
			<legend>Download patient registration form</legend>
			<p>Use the following form to register a patient in the Health Records database:<br />
				<a href="PatientRegistrationForm.docx">Patient registration form</a><br />
				<a href="FilledIn.docx">Patient registration form (pre-filled with fake data)</a>
			</p>
		</fieldset>
		
		<br />
		
		<fieldset>
			<legend>Upload patient registration form</legend>
			<p>Use the form below to upload a patient registration form that has been filled out:</p>
			<form enctype="multipart/form-data" action="register_patient.php" method="POST">
			    Select file to upload: <input name="patient_form" type="file" />
			    <input type="submit" value="Upload file" />
			</form>
		</fieldset>
	</body>
</html>