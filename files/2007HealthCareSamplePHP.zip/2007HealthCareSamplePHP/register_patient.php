<?php
/**
 * 2007HealthCareSamplePHP
 *
 * Simplified version of http://msdn2.microsoft.com/en-us/library/bb879915.aspx
 *
 * @author Maarten Balliauw http://blog.maartenballiauw.be
 */


// First of all, accept the file upload
$fileName = './temp_' . basename($_FILES['patient_form']['name']);
if (!move_uploaded_file($_FILES['patient_form']['tmp_name'], $fileName)) {
	die('An error has occurred during the file upload.');
}

// Schemas
$relationshipSchema		= 'http://schemas.openxmlformats.org/package/2006/relationships';
$officeDocumentSchema 	= 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument';
$customXmlSchema 		= 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXml';

// Documentholders
$relations 				= null;
$documentRelations		= null;
$patientData 			= null;

// Open file
$package = new ZipArchive();
$package->open($fileName);

// Read relations and search for officeDocument
$relations = simplexml_load_string($package->getFromName("_rels/.rels"));
foreach ($relations->Relationship as $rel) {
	if ($rel["Type"] == $officeDocumentSchema) {
		// Found office document, now find office document relations
		$documentRelations = simplexml_load_string($package->getFromName(
			dirname($rel["Target"]) . "/_rels/" . basename($rel["Target"]) . ".rels")
		);
		$documentRelations->registerXPathNamespace("rel", $relationshipSchema);
		
		break;
	}
}

// Read document relations and search for customXml
if (!is_null($documentRelations)) {
	foreach ($documentRelations->Relationship as $rel) {
		if ($rel["Type"] == $customXmlSchema) {
			// Found customXml! Let's read it into patientData
			$patientData = simplexml_load_string($package->getFromName(
				str_replace('../', '', $rel["Target"]))
			);
			
			break;
		}
	}
}

// Close file
$package->close();

// Delete the temporary file
@unlink($fileName);

// Patient data found?
if (is_null($patientData)) {
	die('No patient data found in document.');
} else {
	// Load template, replace variables
	$template = file_get_contents('register_patient_template.tpl');
	
	// Replace variables
	$template = str_replace('{Patient.BirthDate}', 				date('Y-m-d', strtotime($patientData->Patient->BirthDate)),	$template);
	$template = str_replace('{Patient.Sex}', 					$patientData->Patient->Sex, 								$template);
	$template = str_replace('{Patient.Name.Last}', 				$patientData->Patient->Name->Last, 							$template);
	$template = str_replace('{Patient.Name.First}', 			$patientData->Patient->Name->First, 						$template);
	$template = str_replace('{Patient.Name.Middle}', 			$patientData->Patient->Name->Middle, 						$template);
	$template = str_replace('{Patient.Name.Prefix}', 			$patientData->Patient->Name->Prefix, 						$template);
	$template = str_replace('{Patient.Address.StreetAddress}', 	$patientData->Patient->Address->StreetAddress, 				$template);
	$template = str_replace('{Patient.Address.City}', 			$patientData->Patient->Address->City, 						$template);
	$template = str_replace('{Patient.Address.State}', 			$patientData->Patient->Address->State, 						$template);
	$template = str_replace('{Patient.Address.PostalCode}', 	$patientData->Patient->Address->PostalCode, 				$template);
	$template = str_replace('{Patient.Contact.HomePhone}', 		$patientData->Patient->Contact->HomePhone, 					$template);
	
	// Show template
	echo $template;
}