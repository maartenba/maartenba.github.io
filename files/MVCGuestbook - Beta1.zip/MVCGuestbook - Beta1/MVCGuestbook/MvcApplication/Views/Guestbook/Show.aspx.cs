﻿using System;
using System.Web;
using System.Web.Mvc;
using MvcApplication.Models.ViewData;
using MvcApplication.Models.Data;

namespace MvcApplication.Views.Guestbook
{
    public partial class Show : ViewPage<GuestbookDetails>
    {
    }
}
