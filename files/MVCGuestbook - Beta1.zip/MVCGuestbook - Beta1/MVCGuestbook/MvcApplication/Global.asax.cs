﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace MvcApplication
{
    public class GlobalApplication : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            RegisterRoutes(RouteTable.Routes);
        }

        public void RegisterRoutes(RouteCollection routes)
        {
            // Note: Change Url= to Url="[controller].mvc/[action]/[id]" to enable 
            //       automatic support on IIS6 
            routes.MapRoute("Entry-New",
                            "Entry/{action}/{guestbookid}/{entryId}",
                            new { controller = "Entry", action = "New", guestbookId = 0, entryId = 0 }
            );

            routes.MapRoute("Login-Logout",
                            "Logout",
                            new { controller = "Login", action = "Logout" }
            );

            routes.MapRoute("Default route",                                        // Route name
                            "{controller}/{action}/{id}",                           // URL with parameters
                            new { controller ="Home", action = "Index", id = "" },  // Parameter defaults
                            new { controller = @"[^\.]*" }                          // Parameter constraints
            );

            routes.MapRoute("Default document",
                            "Default.aspx",
                            new { controller = "Home", action = "Index", id = "" }
            );
        }

    }
}