﻿using MvcApplication.Models.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.VisualStudio.TestTools.UnitTesting.Web;
using System;

namespace MvcApplicationTest
{
    
    
    /// <summary>
    ///This is a test class for EntryTest and is intended
    ///to contain all EntryTest Unit Tests
    ///</summary>
    [TestClass()]
    public class EntryTest
    {
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for Entry Constructor
        ///</summary>
        [TestMethod()]
        public void EntryConstructorTest()
        {
            Entry target = new Entry();
            Assert.IsNotNull(target);
        }

        /// <summary>
        ///A test for Author
        ///</summary>
        [TestMethod()]
        public void AuthorTest()
        {
            Entry target = new Entry();
            string expected = "Maarten";
            string actual;
            target.Author = expected;
            actual = target.Author;
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for Description
        ///</summary>
        [TestMethod()]
        public void DescriptionTest()
        {
            Entry target = new Entry();
            string expected = "Maarten";
            string actual;
            target.Description = expected;
            actual = target.Description;
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for Email
        ///</summary>
        [TestMethod()]
        public void EmailTest()
        {
            Entry target = new Entry();
            string expected = "Maarten";
            string actual;
            target.Email = expected;
            actual = target.Email;
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for GuestbookId
        ///</summary>
        [TestMethod()]
        public void GuestbookIdTest()
        {
            Entry target = new Entry();
            int expected = 123;
            int actual;
            target.GuestbookId = expected;
            actual = target.GuestbookId;
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for Id
        ///</summary>
        [TestMethod()]
        public void IdTest()
        {
            Entry target = new Entry();
            int expected = 5;
            int actual;
            target.Id = expected;
            actual = target.Id;
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for PostedDate
        ///</summary>
        [TestMethod()]
        public void PostedDateTest()
        {
            Entry target = new Entry();
            DateTime expected = DateTime.Now;
            DateTime actual;
            target.PostedDate = expected;
            actual = target.PostedDate;
            Assert.AreEqual(expected, actual);
        }
    }
}
