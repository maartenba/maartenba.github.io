﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Linq;

#endregion

namespace log4net.Azure.Extensions
{
    internal static class IEnumerablePagingExtensions
    {
        public static int GetPageCount<T>(this IEnumerable<T> subject, int pageSize)
        {
            return Convert.ToInt32(
                Math.Ceiling((double)
                    subject.Count() / pageSize));
        }

        public static IEnumerable<T> GetPage<T>(this IEnumerable<T> subject, int pageSize, int pageNumber)
        {
            return subject
                .Skip(pageSize * pageNumber)
                .Take(pageSize)
                .AsEnumerable();
        }
    }
}
