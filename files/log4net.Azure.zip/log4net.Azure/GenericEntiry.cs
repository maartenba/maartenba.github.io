﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Data.Services.Common;
using System.Text;

#endregion

namespace log4net.Azure
{
    // From Azure Storage Explorer, http://azurestorageexplorer.codeplex.com/

    [DataServiceKey(new[] { "PartitionKey", "RowKey" })]
    public class GenericTableStorageEntity
    {
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public Dictionary<string, object> Properties { get; set; }

        public object this[string key]
        {
            get
            {
                return this.Properties[key];
            }
            set
            {
                this.Properties[key] = value;
            }
        }

        private string DisplayCharsAsBytes(char[] chars)
        {
            var builder = new StringBuilder();
            for (var i = 0; i < chars.Length; i++)
            {
                builder.Append(string.Format("{0:X4}", Convert.ToInt64(char.GetNumericValue(chars[i]))) + " ");
            }
            return builder.ToString();
        }

        public override string ToString()
        {
            var builder = new StringBuilder();
            var num = 0;
            if (this.Properties != null)
            {
                foreach (KeyValuePair<string, object> pair in this.Properties)
                {
                    string str;
                    if (num > 0)
                    {
                        builder.Append("|");
                    }
                    if (pair.Value == null)
                    {
                        str = string.Empty;
                    }
                    else
                    {
                        str = pair.Value.ToString();
                    }
                    builder.Append(pair.Key + "=" + str);
                    num++;
                }
            }
            return builder.ToString();
        }

        public string ToXml()
        {
            var builder = new StringBuilder();
            builder.AppendLine("<entity>");
            builder.AppendLine("<PartitionKey>" + this.PartitionKey + "</PartitionKey>");
            builder.AppendLine("<RowKey>" + this.RowKey + "</RowKey>");
            if (this.Properties != null)
            {
                foreach (KeyValuePair<string, object> pair in this.Properties)
                {
                    string str;
                    if (pair.Value == null)
                    {
                        str = string.Empty;
                    }
                    else
                    {
                        str = pair.Value.ToString();
                    }
                    builder.AppendLine("<" + pair.Key + ">" + str + "</" + pair.Key + ">");
                }
            }
            builder.AppendLine("</entity>");
            return builder.ToString();
        }

        public string ToXmlBinaryValues()
        {
            var builder = new StringBuilder();
            builder.AppendLine("<entity>");
            builder.AppendLine("<PartitionKey>" + this.PartitionKey + "</PartitionKey>");
            builder.AppendLine("<RowKey>" + this.RowKey + "</RowKey>");
            if (this.Properties != null)
            {
                foreach (KeyValuePair<string, object> pair in this.Properties)
                {
                    string str;
                    if (pair.Value == null)
                    {
                        str = string.Empty;
                    }
                    else
                    {
                        str = pair.Value.ToString();
                    }
                    str = this.DisplayCharsAsBytes(str.ToCharArray());
                    builder.AppendLine("<" + pair.Key + ">" + str + "</" + pair.Key + ">");
                }
            }
            builder.AppendLine("</entity>");
            return builder.ToString();
        }
    }
}
