﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Data.Services.Client;
using System.IO;
using log4net.Appender;
using log4net.Azure.Extensions;
using log4net.Core;
using log4net.Layout;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;

#endregion

namespace log4net.Azure
{
    public class TableStorageAppender
        : BufferingAppenderSkeleton
    {
        public string ConnectionString { get; set; }
        public string TableName { get; set; }
        public string PartitionKey { get; set; }
        public List<TableStorageAppenderProperty> Properties { get; protected set; }

        public TableStorageAppender()
        {
            Properties = new List<TableStorageAppenderProperty>();
        }

        public void AddProperty(TableStorageAppenderProperty property)
        {
            Properties.Add(property);
        }

        private CloudTableClient cloudTableClient;
        protected CloudTableClient CloudTableClient {
            get
            {
                if (cloudTableClient == null)
                {
                    CloudStorageAccount account = null;
                    if (!CloudStorageAccount.TryParse(this.ConnectionString, out account))
                    {
                        ErrorHandler.Error("Could not parse Table Storage connection string.");
                    }
                    else
                    {
                        cloudTableClient = account.CreateCloudTableClient();
                        cloudTableClient.CreateTableIfNotExist(this.TableName);
                    }
                }
                return cloudTableClient;
            }
        }

        protected override void SendBuffer(LoggingEvent[] events)
        {
            var context = CloudTableClient.GetDataServiceContext();

            var pageCount = events.GetPageCount(100);
            for (var i = 0; i < pageCount; i++)
            {
                foreach (LoggingEvent e in events.GetPage(100, i))
                {
                    var entity = new GenericTableStorageEntity();
                    entity.PartitionKey = this.PartitionKey;
                    entity.RowKey = Guid.NewGuid().ToString();

                    foreach (TableStorageAppenderProperty property in Properties)
                    {
                        entity[property.PropertyName] = property.FormatValue(e);
                    }

                    context.AddObject(this.TableName, entity);
                }

                try
                {
                    context.SaveChangesWithRetries(SaveChangesOptions.Batch);
                }
                catch (Exception ex)
                {
                    ErrorHandler.Error("Could not save changes to Table Storage.", ex);
                }
            }
        }
    }

    public class TableStorageAppenderProperty
    {
        public string PropertyName { get; set; }
        public ILayout Layout { get; set; }

        public string FormatValue(LoggingEvent loggingEvent)
        {
            var eventWriter = new StringWriter(System.Globalization.CultureInfo.InvariantCulture);
            Layout.Format(eventWriter, loggingEvent);
            return eventWriter.ToString();
        }
    }
}
