﻿#region Using directives

using System;
using log4net.Config;

#endregion

namespace log4net.Azure.Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            XmlConfigurator.Configure(new System.IO.FileInfo(".\\log4net.xml"));

            var log = LogManager.GetLogger("Test");

            // Add some messages
            for (var i = 0; i < 25; i++)
            {
                log.Warn("Message logged " + i);
            }

            Console.ReadLine();
        }
    }
}
