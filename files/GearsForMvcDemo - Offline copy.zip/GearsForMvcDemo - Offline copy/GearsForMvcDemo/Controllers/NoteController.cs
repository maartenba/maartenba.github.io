using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using GearsForMvcDemo.Repository;
using GearsForMvcDemo.Domain;

namespace GearsForMvcDemo.Controllers
{
    [Authorize]
    public class NoteController : Controller
    {
        #region Private fields

        INoteRepository noteRepository = null;

        #endregion

        #region Constructor

        public NoteController()
        {
            // TODO: Refactor for dependency injection
            noteRepository = new NoteRepository();
        }

        #endregion

        #region Action methods 

        //
        // GET: /Note/

        public ActionResult Index()
        {
            return RedirectToAction("List");
        }

        //
        // GET: /Note/List

        public ActionResult List()
        {
            return View(
                noteRepository.RetrieveByOwner(User.Identity.Name)
            );
        }

        //
        // GET: /Note/Details/5

        public ActionResult Details(int id)
        {
            return View(
                noteRepository.RetrieveById(id, User.Identity.Name)
            );
        }

        //
        // GET: /Note/Create

        public ActionResult Create()
        {
            return View(
                new Note()
            );
        } 

        //
        // POST: /Note/Create

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Create(FormCollection collection)
        {
            Note note = new Note();

            try
            {
                UpdateModel(
                    note, 
                    new string[] { "Title", "Body" },
                    collection.ToValueProvider()
                );

                noteRepository.Save(note, User.Identity.Name);

                return RedirectToAction("List");
            }
            catch
            {
                return View(note);
            }
        }

        //
        // GET: /Note/Edit/5
 
        public ActionResult Edit(int id)
        {
            return View(
               noteRepository.RetrieveById(id, User.Identity.Name)
           );
        }

        //
        // POST: /Note/Edit/5

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Edit(int id, FormCollection collection)
        {
            Note note = noteRepository.RetrieveById(id, User.Identity.Name);

            try
            {
                UpdateModel(
                    note,
                    new string[] { "Title", "Body" },
                    collection.ToValueProvider()
                );

                noteRepository.Save(note, User.Identity.Name);

                return RedirectToAction("List");
            }
            catch
            {
                return View(note);
            }
        }

        #endregion
    }
}
