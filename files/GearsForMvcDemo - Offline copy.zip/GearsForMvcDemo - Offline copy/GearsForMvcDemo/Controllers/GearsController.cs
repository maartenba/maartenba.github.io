using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using System.IO;
using GearsForMvcDemo.Repository;
using GearsForMvcDemo.Domain;

namespace GearsForMvcDemo.Controllers
{
    public class GearsController : Controller
    {
        #region Private fields

        INoteRepository noteRepository = null;

        #endregion

        #region Constructor

        public GearsController()
        {
            // TODO: Refactor for dependency injection
            noteRepository = new NoteRepository();
        }

        #endregion

        #region Action methods

        public ActionResult Index()
        {
            // Generate list of URL's
            List<object> urls = new List<object>();

            // Content root
            string contentRoot = Server.MapPath("~/");

            // Static content
            string[] staticContentPaths = new string[] {
                "~/Content",
                "~/Scripts"
            };
            foreach (string staticContentPath in staticContentPaths)
            {
                List<string> pathsToAdd =
                    TraversePath(Server.MapPath(staticContentPath));
                foreach (string path in pathsToAdd)
                {
                    urls.Add(
                        new
                        {
                            url = "/" + path.Replace(contentRoot, "")
                                            .Replace("\\", "/")
                        }
                    );
                }
            }

            // Dynamic content (path to user's notes)
            // TODO: Remove static paths and use route dictionary instead
            List<Note> notes = noteRepository.RetrieveByOwner(User.Identity.Name);
            foreach (Note note in notes)
            {
                urls.Add(
                    new
                    {
                        url = string.Format("/Note/Details/{0}", note.Id)
                    }
                );
            }
            urls.Add(new { url = "/" });
            urls.Add(new { url = "/Home" });
            urls.Add(new { url = "/Home/Index" });
            urls.Add(new { url = "/Home/About" });
            urls.Add(new { url = "/Note/List" });
            urls.Add(new { url = "/Note", redirect = "/Note/List" });

            // Create manifest
            return Json(new
            {
                betaManifestVersion = 1,
                version = "GearsForMvcDemo_0_1_0_" + DateTime.Now.Second.ToString(),
                entries = urls
            });
        }

        public JsonResult IsOnline()
        {
            return Json(true);
        }

        #endregion

        #region Helper methods

        protected List<string> TraversePath(string path)
        {
            // Returnvalue
            List<string> returnValue = new List<string>();

            // Iterate through each folder
            foreach (string folder in Directory.GetDirectories(path))
            {
                returnValue.AddRange(TraversePath(folder));
            }

            // Iterate through the files in this folder
            foreach (string file in Directory.GetFiles(path))
            {
                returnValue.Add(file);
            }

            // Return
            return returnValue;
        }

        #endregion
    }
}
