// Name of the local store
var STORE_NAME = "gearsformvcdemo";

// Manifest name
var MANIFEST_FILENAME = "/manifest.json";

// Local server instance
var localServer;

// Store instance
var store;

// Bootstrapper (page load)
$(function() {
    // Check for Google Gears. If it is not present,
    // remove the "Go offline" link.
    if (!window.google || !google.gears) {
        // Google Gears not present...
        $("#goOffline").hide();
    } else {
        // Initialize Google Gears
        if (google.gears.factory.hasPermission)
            initGears();

        // Offline cache available?
        if (!google.gears.factory.hasPermission || (store != null && !store.currentVersion)) {
            // Wire up Google Gears
            $("#goOffline").click(function(e) {
                // Create store
                initGears();
                createStore();

                // Prevent default behaviour
                e.preventDefault();
            });
        } else {
            // Check if we are online...
            checkOnline(function(isOnline) {
                if (isOnline) {
                    // Refresh data!
                    updateStore();
                } else {
                    // Make sure "Edit" and "Create" are disabled
                    $("a").each(function(index, item) {
                        if ($(item).text() == "Edit" || $(item).text() == "Create New") {
                            $(item).attr('disabled', true);
                            $(item).click(function(e) {
                                e.preventDefault();
                            });
                        }
                    });
                }
            });

            // Provide "Clear cache" function
            $("#goOffline").text("Clear offline cache...").click(function(e) {
                // Remove store
                removeStore();
                window.location.reload();

                // Prevent default behaviour
                e.preventDefault();
            });
        }
    }
});

// Called on page load to initialize local server and store
function initGears() {
    if (window.google && google.gears) {
        localServer = google.gears.factory.create("beta.localserver");
        store = localServer.createManagedStore(STORE_NAME);
    }
}

// Create the resource store
function createStore() {
    if (window.google && google.gears) {
        store.manifestUrl = MANIFEST_FILENAME;
        store.checkForUpdate();

        var timerId = window.setInterval(function() {
            // When the currentVersion property has a value, all of the resources
            // listed in the manifest file for that version are captured. There is
            // an open bug to surface this state change as an event.
            if (store.currentVersion) {
                window.clearInterval(timerId);
                alert("Application is now available offline. (Manifest version " + store.currentVersion + ")");
                window.location.reload();
            } else if (store.updateStatus == 3) {
                alert("Error: " + store.lastErrorMessage);
                window.clearInterval(timerId);
            }
        }, 500);
    }
}

// Update the resource store
function updateStore() {
    if (window.google && google.gears) {
        store.manifestUrl = MANIFEST_FILENAME;
        store.checkForUpdate();
    }
}

// Remove the resource store.
function removeStore() {
    if (window.google && google.gears) {
        localServer.removeManagedStore(STORE_NAME);
    }
}

// Check if we are online...
function checkOnline(callback) {
    // Check if we are online using an AJAX call!
    $.ajax({
        'cache': false,
        'success': callback,
        'dataType': 'json',
        'error': function(XMLHttpRequest, textStatus, errorThrown) {
            if (textStatus == 'error' || textStatus == 'timeout')
                callback(false);
        },
        'url': '/Gears/IsOnline',
        'timeout': 200
    });
}