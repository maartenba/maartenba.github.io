################################################################
# Script (C) Maarten Balliauw - http://blog.maartenballiauw.be #
################################################################


# Load settings
.\settings.ps1

# Load required CmdLets and assemblies
$env:Path = $env:Path + "; c:\Program Files\Windows Azure SDK\v1.2\bin\"
Add-PSSnapin AzureManagementToolsSnapIn
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.Web.Administration")

# Modify IIS ARR
$mgr = new-object Microsoft.Web.Administration.ServerManager
$conf = $mgr.GetApplicationHostConfiguration()
$section = $conf.GetSection("webFarms")
$webFarms = $section.GetCollection()
$webFarm = $webFarms[$webFarmIndex]
$servers = $webFarm.GetCollection()
$server = $servers[0]
$server.SetAttributeValue("address", $localUrl)
$server.ChildElements["applicationRequestRouting"].SetAttributeValue("httpPort", $localPort)
$mgr.CommitChanges()

# Undeploy application in Windows Azure (production)
if ($deployProduction -eq 1) {
  Set-DeploymentStatus -Status "Suspended"  -SubscriptionId $subscriptionId -certificate $certificate -ServiceName $serviceName -Slot $slot
  Start-Sleep -s 120
  Remove-Deployment -SubscriptionId $subscriptionId -certificate $certificate -ServiceName $serviceName -Slot $slot
}

# Undeploy application in Windows Azure (dev fabric)
if ($deployDevFabric -eq 1) {
  csrun /devfabric:shutdown
}


