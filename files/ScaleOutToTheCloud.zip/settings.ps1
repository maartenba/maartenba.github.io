################################################################
# Script (C) Maarten Balliauw - http://blog.maartenballiauw.be #
################################################################

# Settings (prod)
$global:wwwroot = "C:\inetpub\web.local\"
$global:deployProduction = 1
$global:deployDevFabric = 0
$global:webFarmIndex = 0
$global:localUrl = "web.local"
$global:localPort = 80
$global:azureUrl = "scaleout-prod.cloudapp.net"
$global:azurePort = 80
$global:azureDeployedSite = "http://" + $azureUrl + ":" + $azurePort
$global:numberOfInstances = 1
$global:subscriptionId = ""
$global:certificate = "c:\users\mblrq67\desktop\cert.cer"
$global:serviceName = "scaleout-prod"
$global:storageServiceName = "mystorageplayground"
$global:slot = "Production"
$global:label = Date