################################################################
# Script (C) Maarten Balliauw - http://blog.maartenballiauw.be #
################################################################


# Load settings
& .\settings.ps1

# Load required CmdLets and assemblies
$env:Path = $env:Path + "; c:\Program Files\Windows Azure SDK\v1.2\bin\"
Add-PSSnapin AzureManagementToolsSnapIn
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.Web.Administration")

# Build a list of files to deploy
del FilesToDeploy.txt

$filesToDeploy = Get-ChildItem $wwwroot -recurse | where {$_.extension -match "\..*"}
foreach ($fileToDeploy in $filesToDeploy) {
  $inputPath = $fileToDeploy.FullName
  $outputPath = $fileToDeploy.FullName.Replace($wwwroot,"")
  $inputPath + ";" + $outputPath | Out-File FilesToDeploy.txt -Append
}

# Package the website for Windows Azure (production)
if ($deployProduction -eq 1) {
  cspack ServiceDefinition.csdef /roleFiles:"WebRole;FilesToDeploy.txt" /out:"ScaleOutService.cspkg" /generateConfigurationFile:ServiceConfiguration.cscfg

  # Set instance count
  (Get-Content ServiceConfiguration.cscfg) | 
  Foreach-Object {$_.Replace("count=""1""","count=""" + $numberOfInstances + """")} | 
  Set-Content ServiceConfiguration.cscfg

  # Run! (may take up to 15 minutes!)
  New-Deployment -SubscriptionId $subscriptionId -certificate $certificate -ServiceName $serviceName -Slot $slot -StorageServiceName $storageServiceName -Package "ScaleOutService.cspkg" -Configuration "ServiceConfiguration.cscfg" -label $label
  $deployment = Get-Deployment -SubscriptionId $subscriptionId -certificate $certificate -ServiceName $serviceName -Slot $slot
  do {
    Start-Sleep -s 10
    $deployment = Get-Deployment -SubscriptionId $subscriptionId -certificate $certificate -ServiceName $serviceName -Slot $slot
  } while ($deployment.Status -ne "Suspended")

  Set-DeploymentStatus -Status "Running"  -SubscriptionId $subscriptionId -certificate $certificate -ServiceName $serviceName -Slot $slot
  $wc = new-object system.net.webclient
  $html = ""
  do {
    Start-Sleep -s 60
    trap [Exception] {
      continue
    }
    $html = $wc.DownloadString($azureDeployedSite)
  } while (!$html.ToLower().Contains("<html"))
}

# Package & run the website for Windows Azure (dev fabric)
if ($deployDevFabric -eq 1) {
  trap [Exception] {
    del -Recurse ScaleOutService
    continue
  }
  cspack ServiceDefinition.csdef /roleFiles:"WebRole;FilesToDeploy.txt" /copyOnly /out:ScaleOutService /generateConfigurationFile:ServiceConfiguration.cscfg

  # Set instance count
  (Get-Content ServiceConfiguration.cscfg) | 
  Foreach-Object {$_.Replace("count=""1""","count=""" + $numberOfInstances + """")} | 
  Set-Content ServiceConfiguration.cscfg

  # Run!
  csrun ScaleOutService ServiceConfiguration.cscfg /launchBrowser
}


# Modify IIS ARR
$mgr = new-object Microsoft.Web.Administration.ServerManager
$conf = $mgr.GetApplicationHostConfiguration()
$section = $conf.GetSection("webFarms")
$webFarms = $section.GetCollection()
$webFarm = $webFarms[$webFarmIndex]
$servers = $webFarm.GetCollection()
$server = $servers[0]
$server.SetAttributeValue("address", $azureUrl)
$server.ChildElements["applicationRequestRouting"].SetAttributeValue("httpPort", $azurePort)
$mgr.CommitChanges()
