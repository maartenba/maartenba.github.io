﻿namespace LatestTwitter.Models
{
    public class TweetModel
    {
        public string Username { get; set; }

        public string Message { get; set; }

        public string Avatar { get; set; }

        public string Timestamp { get; set; }
    }
}