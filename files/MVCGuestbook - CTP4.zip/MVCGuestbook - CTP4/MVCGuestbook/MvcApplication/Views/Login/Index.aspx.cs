﻿using System;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication.Views.Login
{
    public partial class Index : ViewPage
    {
    }
}
