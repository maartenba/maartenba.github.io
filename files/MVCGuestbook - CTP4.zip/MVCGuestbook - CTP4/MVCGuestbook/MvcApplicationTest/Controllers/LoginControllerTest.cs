﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Web;
using System.Web.Mvc;
using MvcApplication.Controllers;
using MvcApplicationTest.HelperClasses;
using System.Web.Routing;
using Moq;

namespace MvcApplicationTest.Controllers
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class LoginControllerTest : BaseTest
    {
        [TestMethod]
        public void TestRouteIndex()
        {
            HttpContextBase context = MvcMockHelpers.FakeHttpContext();
            context.Request.SetupRequestUrl("~/Login/Index");

            RouteData routeData = routes.GetRouteData(context);
            Assert.AreEqual("Login", routeData.Values["controller"]);
            Assert.AreEqual("Index", routeData.Values["action"]);
            Assert.AreEqual(typeof(MvcRouteHandler), routeData.RouteHandler.GetType());
        }

        [TestMethod]
        public void TestRouteAuthenticate()
        {
            HttpContextBase context = MvcMockHelpers.FakeHttpContext();
            context.Request.SetupRequestUrl("~/Login/Authenticate");

            RouteData routeData = routes.GetRouteData(context);
            Assert.AreEqual("Login", routeData.Values["controller"]);
            Assert.AreEqual("Authenticate", routeData.Values["action"]);
            Assert.AreEqual(typeof(MvcRouteHandler), routeData.RouteHandler.GetType());
        }

        [TestMethod]
        public void TestRouteLogout()
        {
            HttpContextBase context = MvcMockHelpers.FakeHttpContext();
            context.Request.SetupRequestUrl("~/Login/Logout");

            RouteData routeData = routes.GetRouteData(context);
            Assert.AreEqual("Login", routeData.Values["controller"]);
            Assert.AreEqual("Logout", routeData.Values["action"]);
            Assert.AreEqual(typeof(MvcRouteHandler), routeData.RouteHandler.GetType());
        }

        [TestMethod]
        public void TestIndex()
        {
            LoginController controller = new LoginController();

            var result = controller.Index() as ViewResult;

            Assert.IsNotNull(result);
            Assert.AreEqual(result.ViewName, "Index");
        }

        [TestMethod]
        public void TestInvalidCredentials()
        {
            LoginController controller = new LoginController();

            var mock = new Mock<System.Web.Security.MembershipProvider>();
            mock.Expect(m => m.ValidateUser("", "")).Returns(false);
            controller.MembershipProviderInstance = mock.Object;

            var result = controller.Authenticate("", "") as ViewResult;

            Assert.IsNotNull(result);
            Assert.AreEqual(result.ViewName, "Index");
            Assert.AreEqual(controller.ViewData["ErrorMessage"], "Invalid credentials! Please verify your username and password.");
        }

        [TestMethod]
        public void TestValidCredentials()
        {
            LoginController controller = new LoginController();

            controller.SetFakeControllerContext();
            controller.Request.SetFakeRequestData("returnUrl", null);

            var mock = new Mock<System.Web.Security.MembershipProvider>();
            mock.Expect(m => m.ValidateUser("", "")).Returns(true);
            controller.MembershipProviderInstance = mock.Object;

            var result = controller.Authenticate("", "") as RedirectResult;

            Assert.IsNull(result);
        }

        [TestMethod]
        public void TestLogout()
        {
            LoginController controller = new LoginController();

            var result = controller.Logout() as RedirectResult;

            Assert.IsNull(result);
        }
    }
}