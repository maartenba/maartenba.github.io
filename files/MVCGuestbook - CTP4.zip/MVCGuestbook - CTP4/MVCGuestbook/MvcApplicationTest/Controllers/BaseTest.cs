﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Routing;
using MvcApplication;
using System.Transactions;

namespace MvcApplicationTest.Controllers
{
    /// <summary>
    /// Test MVC application
    /// </summary>
    public abstract class BaseTest
    {
        protected RouteCollection routes = new RouteCollection();
        protected TransactionScope transactionScope;

        public BaseTest()
        {
            // Populate routes
            GlobalApplication application = new GlobalApplication();
            application.RegisterRoutes(routes);
        }

        [TestInitialize]
        public void SetupTest()
        {
            transactionScope = new TransactionScope();
        }

        [TestCleanup]
        public void TearDownTest()
        {
            // This is just for clarification...
            Transaction.Current.Rollback();
        }
    }
}
