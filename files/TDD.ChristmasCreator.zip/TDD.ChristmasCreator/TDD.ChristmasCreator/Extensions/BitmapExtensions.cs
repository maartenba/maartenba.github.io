﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
using ImageTools;
using ImageTools.IO.Png;
using System.IO;
using System.IO.IsolatedStorage;

namespace TDD.ChristmasCreator.Extensions
{
    public static class BitmapExtensions
    {
        public static string SaveToPNG(this WriteableBitmap bitmap)
        {
            if (bitmap != null)
            {
                string fileName = DateTime.Now.Ticks.ToString() + ".png";
                var byteArray = ImageHelpers._GetSaveBuffer(bitmap);
                var encoder = new PngEncoder();
                var img = bitmap.ToImage();

                using (IsolatedStorageFile iso = IsolatedStorageFile.GetUserStoreForApplication())
                {
                    if (iso.Quota < 100000000)
                        iso.IncreaseQuotaTo(100000000);

                    //if (iso.IncreaseQuotaTo(iso.Quota + 10))
                    //{
                        using (IsolatedStorageFileStream stream = new IsolatedStorageFileStream(fileName, FileMode.CreateNew, iso))
                        {
                            encoder.Encode(img, stream);
                            stream.Write(byteArray, 0, byteArray.Length);
                        }
                    //}
                }

                return fileName;
            }
            return string.Empty;
        }
    }

    public class ImageHelpers
    {
        public static byte[] _GetSaveBuffer(WriteableBitmap bitmap)
        {
            long matrixSize = bitmap.PixelWidth * bitmap.PixelHeight;

            long byteSize = matrixSize * 4 + 4;

            byte[] retVal = new byte[byteSize];

            long bufferPos = 0;

            retVal[bufferPos++] = (byte)((bitmap.PixelWidth / 256) & 0xff);
            retVal[bufferPos++] = (byte)((bitmap.PixelWidth % 256) & 0xff);
            retVal[bufferPos++] = (byte)((bitmap.PixelHeight / 256) & 0xff);
            retVal[bufferPos++] = (byte)((bitmap.PixelHeight % 256) & 0xff);

            for (int matrixPos = 0; matrixPos < matrixSize; matrixPos++)
            {
                retVal[bufferPos++] = (byte)((bitmap.Pixels[matrixPos] >> 24) & 0xff);
                retVal[bufferPos++] = (byte)((bitmap.Pixels[matrixPos] >> 16) & 0xff);
                retVal[bufferPos++] = (byte)((bitmap.Pixels[matrixPos] >> 8) & 0xff);
                retVal[bufferPos++] = (byte)((bitmap.Pixels[matrixPos]) & 0xff);
            }

            return retVal;
        }
    }
}
