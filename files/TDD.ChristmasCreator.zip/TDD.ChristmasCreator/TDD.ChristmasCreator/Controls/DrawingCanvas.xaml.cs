﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace TDD.ChristmasCreator.Controls
{
    public partial class DrawingCanvas : UserControl
    {
        public DrawingCanvas()
        {
            InitializeComponent();
        }

        private void LayoutRoot_Drop(object sender, DragEventArgs e)
        {

        }

        public void AddChild(UIElement element)
        {
            MainCanvas.Children.Add(element);
        }

        public void RemoveChild(UIElement element)
        {
            MainCanvas.Children.Remove(element);
        }
    }
}
