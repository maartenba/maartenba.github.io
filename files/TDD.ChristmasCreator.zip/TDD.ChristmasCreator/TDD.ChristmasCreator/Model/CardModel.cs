﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using TDD.ChristmasCreator.CardService;
using System.Windows.Media.Imaging;

namespace TDD.ChristmasCreator.Model
{
    public class CardModel
    {
        public string ReceiverName { get; set; }
        public string ReceiverEmail { get; set; }
        public string SenderName { get; set; }
        public string SenderEmail { get; set; }
        public DateTime SendDate { get; set; }
        public CardGreeting CardGreeting { get; set; }
        public CardColor CardBackgroundColor { get; set; }
        public string Text { get; set; }
        public string ImageFileName{ get; set; }
    }
}
