﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using System.Windows.Media.Imaging;
using System.Windows.Printing;
using System.IO;
using TDD.ChristmasCreator.Model;
using System.Windows.Markup;
using TDD.ChristmasCreator.Extensions;

namespace TDD.ChristmasCreator.Views
{
    public partial class CardCreator : Page
    {
        #region Private fields

        private CaptureSource _captureSource;
        private WriteableBitmap _backgroundImage;
        private PrintDocument _printDocument;
        private CardModel _cardModel;
        private ContextMenu _contextMenu;
        private bool _isDragging = false;
        private Point _mouseOffset;
        UIElement _selectedElementForRightClick;

        #endregion

        public CardCreator()
        {
            InitializeComponent();

            _cardModel = ((App)Application.Current).CardModel;
            

            WebcamComboBox.ItemsSource = CaptureDeviceConfiguration.GetAvailableVideoCaptureDevices();
            WebcamComboBox.SelectedIndex = 0;

            _printDocument = new PrintDocument();
            _printDocument.PrintPage += new EventHandler<PrintPageEventArgs>(_printDocument_PrintPage);

            _printDocument.EndPrint += (s, e) =>
            {
                MessageBox.Show("Printed successfully");
            };

            AddTddIcon();
            AddGreeting();
            AddText();
            BuildCustomMenu();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        #region Build up related

        private void AddText()
        {
            if (_cardModel != null)
            {
                string customText = _cardModel.Text;
                //customText = customText.Replace("<Section xml:space=\"preserve\" HasTrailingParagraphBreakOnPaste=\"False\" xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\">", string.Empty);
                //customText = "<TextBlock xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\">" + customText + "</TextBlock>";
                CustomRichTextBox.Xaml = customText;
            }
        }

        private void AddGreeting()
        {
            if (_cardModel != null)
            {
                string greeting = _cardModel.CardGreeting.GreetingText;
                TextBlock greetingTextBlock = new TextBlock();
                greetingTextBlock.Text = greeting;
                greetingTextBlock.FontSize = 16;
                greetingTextBlock.FontWeight = FontWeights.Black;
                greetingTextBlock.Foreground = new SolidColorBrush(Colors.Red);
                greetingTextBlock.SetValue(Canvas.LeftProperty, 200.0);
                greetingTextBlock.SetValue(Canvas.TopProperty, 150.0);
                greetingTextBlock.MouseLeftButtonDown += new MouseButtonEventHandler(UIElement_MouseLeftButtonDown);
                greetingTextBlock.MouseMove += new MouseEventHandler(UIElement_MouseMove);
                greetingTextBlock.MouseLeftButtonUp += new MouseButtonEventHandler(UIElement_MouseLeftButtonUp);
                ChristmasCardCanvas.AddChild(greetingTextBlock);
            }
        }

        private void AddTddIcon()
        {
            Image tddImage = new Image();
            tddImage.Source = new BitmapImage(new Uri("../Assets/tddicon.png", UriKind.Relative));
            tddImage.Width = 50;
            tddImage.Stretch = Stretch.Uniform;
            tddImage.SetValue(Canvas.LeftProperty, 550.0);
            tddImage.SetValue(Canvas.TopProperty, 350.0);
            ChristmasCardCanvas.AddChild(tddImage);
        }

        #endregion

        #region Print related

        void _printDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            e.PageVisual = PrintGrid;
            e.HasMorePages = false;
        }

        private void PrintPreviewButton_Click(object sender, RoutedEventArgs e)
        {
            _printDocument.Print("Card preview");
        }

        #endregion

        #region Right-click related

        private void BuildCustomMenu()
        {
            _contextMenu = new ContextMenu();
            MenuItem menuItem = new MenuItem();
            menuItem.Header = "Delete";
            menuItem.Click += new RoutedEventHandler(menuItem_Click);
            _contextMenu.Items.Add(menuItem);
        }

        void menuItem_Click(object sender, RoutedEventArgs e)
        {
            UIElement element = sender as UIElement;
            if (element != null)
            {
                ChristmasCardCanvas.RemoveChild(_selectedElementForRightClick);
            }
            _contextMenu.IsOpen = false;
        }

        void UIElement_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            _selectedElementForRightClick = sender as UIElement;
            _contextMenu.IsOpen = true;
            _contextMenu.HorizontalOffset = e.GetPosition(sender as UIElement).X;
            _contextMenu.HorizontalOffset = e.GetPosition(sender as UIElement).Y;
        }

        #endregion

        #region Open file dialog

        private void ImportImageButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Image Files (.jpg)|*.jpg";
            if (dialog.ShowDialog() == true)
            {
                using (StreamReader reader = dialog.File.OpenText())
                {
                    BitmapImage i = new BitmapImage();
                    i.SetSource(reader.BaseStream);
                    BackgroundImage.Source = i;
                }
            }
        }

        #endregion

        #region Toolbox

        private void AddChristmasTreeButton_Click(object sender, RoutedEventArgs e)
        {
            Image christmasTreeImage = new Image();
            christmasTreeImage.Source = new BitmapImage(new Uri("../Assets/christmastreeicon.png", UriKind.Relative));
            christmasTreeImage.Width = 75;
            christmasTreeImage.Stretch = Stretch.Uniform;
            christmasTreeImage.MouseLeftButtonDown += new MouseButtonEventHandler(UIElement_MouseLeftButtonDown);
            christmasTreeImage.MouseMove += new MouseEventHandler(UIElement_MouseMove);
            christmasTreeImage.MouseLeftButtonUp += new MouseButtonEventHandler(UIElement_MouseLeftButtonUp);
            christmasTreeImage.MouseRightButtonDown += (s, ev) =>
                                                        {
                                                            ev.Handled = true;
                                                        };
            christmasTreeImage.MouseRightButtonUp += new MouseButtonEventHandler(UIElement_MouseRightButtonUp);
            ChristmasCardCanvas.AddChild(christmasTreeImage);
        }



        private void AddSantaHatButton_Click(object sender, RoutedEventArgs e)
        {
            Image santaHatImage = new Image();
            santaHatImage.Source = new BitmapImage(new Uri("../Assets/santahat.png", UriKind.Relative));
            santaHatImage.Width = 75;
            santaHatImage.Stretch = Stretch.Uniform;
            santaHatImage.MouseLeftButtonDown += new MouseButtonEventHandler(UIElement_MouseLeftButtonDown);
            santaHatImage.MouseMove += new MouseEventHandler(UIElement_MouseMove);
            santaHatImage.MouseLeftButtonUp += new MouseButtonEventHandler(UIElement_MouseLeftButtonUp);
            santaHatImage.MouseRightButtonDown += (s, ev) =>
                                                {
                                                    ev.Handled = true;
                                                };
            santaHatImage.MouseRightButtonUp += new MouseButtonEventHandler(UIElement_MouseRightButtonUp);
            ChristmasCardCanvas.AddChild(santaHatImage);
        }

        #endregion

        #region Mouse movement related

        void UIElement_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            _isDragging = true;
            UIElement element = (UIElement)sender;

            _mouseOffset = e.GetPosition(element);

            element.CaptureMouse();
        }

        void UIElement_MouseMove(object sender, MouseEventArgs e)
        {
            if (_isDragging)
            {
                UIElement element = (UIElement)sender;

                Point point = e.GetPosition(ChristmasCardCanvas);

                element.SetValue(Canvas.TopProperty, point.Y - _mouseOffset.Y);
                element.SetValue(Canvas.LeftProperty, point.X - _mouseOffset.X);
            }
        }

        void UIElement_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (_isDragging)
            {
                UIElement element = (UIElement)sender;

                element.ReleaseMouseCapture();

                _isDragging = false;
            }
        }


        #endregion

        #region Webcam related

        private void OpenCameraPopupButton_Click(object sender, RoutedEventArgs e)
        {
            if (WebcamGrid.Visibility == System.Windows.Visibility.Collapsed)
            {
                WebcamGrid.Visibility = System.Windows.Visibility.Visible;
            }
        }

        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            if (WebcamComboBox.SelectedValue != null)
            {
                StartSelectedWebcam();
            }
        }

        private void StartSelectedWebcam()
        {
            //no access to the cam
            if (!CaptureDeviceConfiguration.AllowedDeviceAccess)
            {
                //request access now
                if (!CaptureDeviceConfiguration.RequestDeviceAccess())
                {
                    return;
                }
            }
            StartButton.IsEnabled = false;

            _captureSource = new CaptureSource();
            _captureSource.VideoCaptureDevice = WebcamComboBox.SelectedValue as VideoCaptureDevice;

            VideoBrush videoBrush = new VideoBrush();
            videoBrush.SetSource(_captureSource);
            WebcamRectangle.Fill = videoBrush;
            _captureSource.Start();
            TakePictureButton.IsEnabled = true;
        }

        private void TakePictureButton_Click(object sender, RoutedEventArgs e)
        {
            _captureSource.CaptureImageAsync();
            _captureSource.CaptureImageCompleted += new EventHandler<CaptureImageCompletedEventArgs>(captureSource_CaptureImageCompleted);
        }

        void captureSource_CaptureImageCompleted(object sender, CaptureImageCompletedEventArgs e)
        {
            _backgroundImage = e.Result;
            BackgroundImage.Source = _backgroundImage;
            WebcamGrid.Visibility = System.Windows.Visibility.Collapsed;
        }

        #endregion

        #region Drag and drop related

        private void ChristmasCardCanvas_Drop(object sender, DragEventArgs e)
        {
            IDataObject dataObject = e.Data;
            Point dropPoint = e.GetPosition(ChristmasCardCanvas);
            if (dataObject.GetDataPresent(DataFormats.FileDrop))
            {
                FileInfo[] files = (FileInfo[])dataObject.GetData(DataFormats.FileDrop);

                foreach (var file in files)
                {
                    if (file.Extension == ".jpg")
                    {
                        System.Windows.Media.Imaging.BitmapImage bitmapImage = new System.Windows.Media.Imaging.BitmapImage();
                        bitmapImage.SetSource(file.OpenRead());
                        BackgroundImage.Source = bitmapImage;
                    }
                }
            }
        }

        #endregion

        private void NextLink_Click(object sender, RoutedEventArgs e)
        {
            WriteableBitmap bitmap = new WriteableBitmap(PrintGrid, null);
            string fileName = bitmap.SaveToPNG();
            
            CardModel cardModel = ((App)Application.Current).CardModel;
            if (cardModel == null)
                cardModel = new CardModel();
            cardModel.ImageFileName = fileName;
        }
    }
}
