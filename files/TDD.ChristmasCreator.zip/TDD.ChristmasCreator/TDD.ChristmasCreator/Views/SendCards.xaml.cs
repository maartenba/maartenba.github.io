﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using TDD.ChristmasCreator.Model;
using TDD.ChristmasCreator.CardMailService;
using System.IO;
using System.IO.IsolatedStorage;
using System.Windows.Media.Imaging;

namespace TDD.ChristmasCreator.Views
{
    public partial class SendCards : Page
    {
        private CardModel _cardModel;

        public SendCards()
        {
            InitializeComponent();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void SendCardButton_Click(object sender, RoutedEventArgs e)
        {

            _cardModel = ((App)Application.Current).CardModel;

            CardToMail cardToMail = new CardToMail();
            cardToMail.ReceiverEmail = _cardModel.ReceiverEmail;
            cardToMail.ReceiverName = _cardModel.ReceiverName;
            cardToMail.SenderEmail = _cardModel.SenderEmail;
            cardToMail.SenderName = _cardModel.SenderName;
            cardToMail.Image = GetImageFromIsoStore(_cardModel.ImageFileName);


            CardMailService.CardMailServiceClient proxy = new CardMailService.CardMailServiceClient();
            proxy.SendMailWithImageCompleted += new EventHandler<CardMailService.SendMailWithImageCompletedEventArgs>(proxy_SendMailWithImageCompleted);
            proxy.SendMailWithImageAsync(cardToMail);
        }

        private byte[] GetImageFromIsoStore(string p)
        {
            byte[] bytes;
            try
            {
                using (IsolatedStorageFile iso = IsolatedStorageFile.GetUserStoreForApplication())
                {

                    using (IsolatedStorageFileStream stream = new IsolatedStorageFileStream(p, FileMode.Open, iso))
                    {
                        bytes = new byte[stream.Length];

                        stream.Read(bytes, 0, (int)stream.Length);
                    }
                }
                return bytes;
            }
            catch (Exception)
            {
                return null;
            }
        }

        void proxy_SendMailWithImageCompleted(object sender, CardMailService.SendMailWithImageCompletedEventArgs e)
        {
            ResultGrid.Visibility = System.Windows.Visibility.Visible;
            ResultImage.Source = new BitmapImage(new Uri(e.Result, UriKind.Absolute));
        }
    }
}
