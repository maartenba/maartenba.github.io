﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using TDD.ChristmasCreator.Model;

namespace TDD.ChristmasCreator.Views
{
    public partial class WizardStep1 : Page
    {
        private CardModel _cardModel;

        public WizardStep1()
        {
            InitializeComponent();
            _cardModel = new CardModel();
            _cardModel.ReceiverEmail = "gill.cleeren@ordina.be";
            _cardModel.ReceiverName = "Gill";
            _cardModel.SenderEmail = "maarten.balliauw@realdolmen.com";
            _cardModel.SenderName = "Maarten";
            _cardModel.SendDate = DateTime.Now;
            
            CardDetailGrid.DataContext = _cardModel;
            LoadData();
        }

        private void LoadData()
        {
            CardService.CardDataServiceClient proxy = new CardService.CardDataServiceClient();

            proxy.GetAllCardGreetingsCompleted += (s, e) =>
                {
                    CardGreetingComboBox.ItemsSource = e.Result;
                    if (e.Result.Count > 0)
                        CardGreetingComboBox.SelectedIndex = 0;
                };
            proxy.GetAllCardGreetingsAsync();

            proxy.GetAllCardColorsCompleted += (s, e) =>
                {
                    CardColorComboBox.ItemsSource = e.Result;
                    if (e.Result.Count > 0)
                        CardColorComboBox.SelectedIndex = 0;
                };
            proxy.GetAllCardColorsAsync();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void button1_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void StartLink_Click(object sender, RoutedEventArgs e)
        {

        }

        private void NextLink_Click(object sender, RoutedEventArgs e)
        {
            ((App)Application.Current).CardModel = _cardModel;
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            string temp = null;

            temp = _cardModel.ReceiverEmail;
            _cardModel.ReceiverEmail = _cardModel.SenderEmail;
            _cardModel.SenderEmail = temp;

            temp = _cardModel.ReceiverName;
            _cardModel.ReceiverName = _cardModel.SenderName;
            _cardModel.SenderName = temp;
        }

    }
}
