﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using System.Collections.ObjectModel;
using System.Runtime.InteropServices.Automation;

namespace TDD.ChristmasCreator.Views
{
    public partial class ExcelReporting : Page
    {
        private ObservableCollection<CardPerson> data;
        public ExcelReporting()
        {
            InitializeComponent();

            CreateSampleData();

            //check if we're running OOB and trusted first
            if (App.Current.IsRunningOutOfBrowser && Application.Current.HasElevatedPermissions)
            {
                ExportButton.IsEnabled = true;
                InstallButton.Visibility = Visibility.Collapsed;
            }
            else
            {
                if (App.Current.InstallState == InstallState.NotInstalled)
                {
                    ExportButton.IsEnabled = false;
                    InstallButton.Visibility = System.Windows.Visibility.Visible;
                }
                else
                {
                    //InstallTextBlock.Text = "Application is installed, you should run the installed version";
                    //InstallButton.Visibility = Visibility.Collapsed;
                    //MainGrid.Visibility = System.Windows.Visibility.Collapsed;
                }
            }
        }

        private void CreateSampleData()
        {
            data = new ObservableCollection<CardPerson>() 
            { 
                new CardPerson(){Name="Gill Cleeren", ReadCard=1}, 
                new CardPerson(){Name="Bill Clinton", ReadCard=1}, 
                new CardPerson(){Name="Bill Gates", ReadCard=1}, 
                new CardPerson(){Name="George W.Bush", ReadCard=0}, 
                new CardPerson(){Name="Barack Obama", ReadCard=0}, 
            };

            ExcelDataGrid.ItemsSource = data;
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void ExportButton_Click(object sender, RoutedEventArgs e)
        {
            // create an instance of excel
            dynamic excel = AutomationFactory.CreateObject("Excel.Application");

            excel.Visible = true;  // make it visible to the user.

            // add a workbook to the instance 
            dynamic workbook = excel.workbooks;
            workbook.Add();

            dynamic sheet = excel.ActiveSheet; // get the active sheet

            dynamic cell = null;

            int i = 1;

            // iterate through our data source and populate the excel spreadsheet
            foreach (dynamic item in ExcelDataGrid.ItemsSource)
            {

                cell = sheet.Cells[i, 1]; // row, column
                cell.Value = item.Name;
                cell.ColumnWidth = 25;

                cell = sheet.Cells[i, 2];
                cell.Value = item.ReadCard;
                i++;
            }
        }

        private void InstallButton_Click(object sender, RoutedEventArgs e)
        {
            //Application.Current.Install();
        }

    }

    public class CardPerson
    {
        public string Name { get; set; }
        public int ReadCard { get; set; }
    }
}
