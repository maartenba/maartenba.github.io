﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TDD.Scaling
{
    public interface IProvisioningProvider
    {
        int GetInstanceCount();
        void SetInstanceCount(int count);
    }
}
