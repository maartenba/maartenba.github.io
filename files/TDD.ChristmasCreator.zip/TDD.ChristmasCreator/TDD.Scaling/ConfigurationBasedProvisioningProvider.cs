﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace TDD.Scaling
{
    public abstract class ConfigurationBasedProvisioningProvider
        : IProvisioningProvider
    {
        public string RoleName { get; protected set; }

        protected abstract XDocument LoadConfiguration();
        protected abstract void SaveConfiguration(XDocument configuration);

        #region IProvisioningProvider Members

        public virtual int GetInstanceCount()
        {
            // Load configuration
            XDocument serviceConfiguration = this.LoadConfiguration();

            // Find number of instances
            return Convert.ToInt32(serviceConfiguration
                                .Descendants()
                                .Single(d => d.Name.LocalName == "Role" && d.Attributes().Single(a => a.Name.LocalName == "name").Value == this.RoleName)
                                .Elements()
                                .Single(e => e.Name.LocalName == "Instances")
                                .Attributes()
                                .Single(a => a.Name.LocalName == "count").Value);
        }

        public virtual void SetInstanceCount(int count)
        {
            // Load configuration
            XDocument serviceConfiguration = this.LoadConfiguration();

            // Update number of instances
            serviceConfiguration
                                .Descendants()
                                .Single(d => d.Name.LocalName == "Role" && d.Attributes().Single(a => a.Name.LocalName == "name").Value == this.RoleName)
                                .Elements()
                                .Single(e => e.Name.LocalName == "Instances")
                                .Attributes()
                                .Single(a => a.Name.LocalName == "count").Value = count.ToString();

            // Save document
            this.SaveConfiguration(serviceConfiguration);
        }

        #endregion
    }
}
