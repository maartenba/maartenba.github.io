﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.WindowsAzure.ServiceRuntime;
using System.Diagnostics;

namespace TDD.Scaling
{
    public class DummyProvisioningProvider
        : IProvisioningProvider
    {
        protected int InstanceCount = 0;

        public DummyProvisioningProvider()
        {
            InstanceCount = RoleEnvironment.CurrentRoleInstance.Role.Instances.Count;
        }

        #region IProvisioningProvider Members

        public int GetInstanceCount()
        {
            return InstanceCount;
        }

        public void SetInstanceCount(int count)
        {
            InstanceCount = count;
        }

        #endregion
    }
}
