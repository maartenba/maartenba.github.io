﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Xml.Linq;
using Microsoft.WindowsAzure.ServiceManagement;
using Microsoft.WindowsAzure.ServiceRuntime;

namespace TDD.Scaling
{
    public class AzureProvisioningProvider
        : ConfigurationBasedProvisioningProvider, IProvisioningProvider
    {
        public string SubscriptionId { get; set; }
        public string ServiceName { get; set; }
        public string DeploymentSlot { get; set; }

        protected IServiceManagement management = null;

        public AzureProvisioningProvider(
            string subscriptionId,
            string serviceName,
            string deploymentSlot,
            string roleName,
            X509Certificate2 managementCertificate)
        {
            this.SubscriptionId = subscriptionId;
            this.ServiceName = serviceName;
            this.DeploymentSlot = deploymentSlot;
            this.RoleName = roleName;

            this.management = ServiceManagementHelper.CreateServiceManagementChannel(
                new Uri("https://management.core.windows.net"),
                managementCertificate);
        }

        protected override XDocument LoadConfiguration()
        {
            Deployment deployment = management.GetDeploymentBySlot(
                this.SubscriptionId, this.ServiceName, this.DeploymentSlot);

            string configurationXml = ServiceManagementHelper.DecodeFromBase64String(deployment.Configuration);
            return XDocument.Parse(configurationXml, LoadOptions.PreserveWhitespace);
        }

        protected override void SaveConfiguration(XDocument configuration)
        {
            Deployment deployment = management.GetDeploymentBySlot(
                this.SubscriptionId, this.ServiceName, this.DeploymentSlot);

            string deploymentStatus = deployment.Status.ToLowerInvariant();
            if (deploymentStatus == "running")
            {

                ChangeConfigurationInput changeConfigurationInput = new ChangeConfigurationInput();
                changeConfigurationInput.Configuration = ServiceManagementHelper.EncodeToBase64String(configuration.ToString(SaveOptions.DisableFormatting));
                management.ChangeConfigurationBySlot(
                this.SubscriptionId, this.ServiceName, this.DeploymentSlot, changeConfigurationInput);
            }
        }
    }
}
