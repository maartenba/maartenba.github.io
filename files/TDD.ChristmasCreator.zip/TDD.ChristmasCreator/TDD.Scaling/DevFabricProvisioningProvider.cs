﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security;
using System.Text;
using System.Xml.Linq;
using Microsoft.WindowsAzure.ServiceRuntime;

namespace TDD.Scaling
{
    public class DevFabricProvisioningProvider
        : ConfigurationBasedProvisioningProvider, IProvisioningProvider
    {
        protected string UserName { get; set; }
        protected SecureString Password { get; set; }
        protected string Domain { get; set; }

        public DevFabricProvisioningProvider(string roleName, string userName, string password, string domain)
        {
            this.RoleName = roleName;
            this.UserName = userName;
            this.Password = new SecureString();
            foreach (var character in password.ToCharArray())
            {
                this.Password.AppendChar(character);
            }
            this.Domain = domain;
        }

        #region IProvisioningProvider Members

        public override void SetInstanceCount(int count)
        {
            // Verify current instance count
            if (GetInstanceCount() > count)
            {
                Trace.WriteLine("DevFabric does not support scaling down. Operation aborted.", "Warning");
                return;
            }

            // Set instance count
            base.SetInstanceCount(count);

            // Notify environment
            ProcessStartInfo processStartInfo = new ProcessStartInfo();
            string pathToCsRun = Environment.GetEnvironmentVariable("PATH").Split(new char[] { ';' }).Where(item => item.Contains("Windows Azure SDK")).LastOrDefault();
            if (pathToCsRun == null)
            {
                return;
            }
            else
            {
                pathToCsRun = pathToCsRun.Substring(0, pathToCsRun.ToLower().IndexOf("bin") + 3) + "\\csrun.exe";
            }

            processStartInfo.UseShellExecute = false;
            processStartInfo.UserName = this.UserName;
            processStartInfo.Password = this.Password;
            processStartInfo.Domain = this.Domain;
            processStartInfo.FileName = "cmd";
            processStartInfo.Arguments = "/c \"" + pathToCsRun + "\" /update:" + RoleEnvironment.DeploymentId.Replace("deployment(", "").Replace(")", "") + ";" + this.GetConfigurationPath();

            Process csrun = new Process();
            csrun.StartInfo = processStartInfo;
            csrun.Start();

            System.Threading.Thread.Sleep(30);
            RoleEnvironment.RequestRecycle();
        }

        #endregion

        private string GetConfigurationPath()
        {
            string configurationFileName = Path.Combine(
                Path.GetDirectoryName(Environment.GetEnvironmentVariable("RoleRoot")
                    .Substring(0, Environment.GetEnvironmentVariable("RoleRoot").IndexOf(".csx") + 4)),
                "ServiceConfiguration.cscfg");

            return configurationFileName;
        }

        protected override XDocument LoadConfiguration()
        {
            // Load configuration file
            string configurationFileName = GetConfigurationPath();

            XDocument serviceConfiguration = XDocument.Load(configurationFileName, LoadOptions.PreserveWhitespace);
            return serviceConfiguration;
        }

        protected override void SaveConfiguration(XDocument configuration)
        {
            // Save configuration file
            string configurationFileName = GetConfigurationPath();

            configuration.Save(configurationFileName);
        }
    }
}
