﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.Diagnostics;
using Microsoft.WindowsAzure.ServiceRuntime;
using TDD.Scaling;

namespace TDD.ChristmasCreator.Web
{

    public class WebRole : RoleEntryPoint
    {
        public override bool OnStart()
        {
            DiagnosticMonitor.Start("DiagnosticsConnectionString");

            // For information on handling configuration changes
            // see the MSDN topic at http://go.microsoft.com/fwlink/?LinkId=166357.
            RoleEnvironment.Changing += RoleEnvironmentChanging;

            CloudStorageAccount.SetConfigurationSettingPublisher((configName, configSetter) =>
            {
                configSetter(RoleEnvironment.GetConfigurationSettingValue(configName));
            });

            StartScalingThread();

            return base.OnStart();
        }

        private void RoleEnvironmentChanging(object sender, RoleEnvironmentChangingEventArgs e)
        {
            // Never restart...
            e.Cancel = false;
        }

        void StartScalingThread()
        {
            IProvisioningProvider provisioningProvider = GetProvisioningProvider();
            
            Thread scalingThread = new Thread(new ThreadStart(() =>
            {
                // Have some rest...
                Thread.Sleep(10000);

                // Start the work!
                while (true)
                { 
                    // Scaling rules
                    // - Normal amount of instances is 2
                    // - Scale to 4 instances during office hours (09:00 - 17:00)
                    // - Scale to 6 instances during evening      (20:00 - 23:00)

                    if (DateTime.Now.ToUniversalTime().Hour >= 8 && DateTime.Now.ToUniversalTime().Hour < 16)
                    {
                        if (provisioningProvider.GetInstanceCount() != 4)
                        {
                            provisioningProvider.SetInstanceCount(4);
                        }
                    }
                    else if (DateTime.Now.ToUniversalTime().Hour >= 19 && DateTime.Now.ToUniversalTime().Hour < 22)
                    {
                        if (provisioningProvider.GetInstanceCount() != 6)
                        {
                            provisioningProvider.SetInstanceCount(6);
                        }
                    }
                    else
                    {
                        if (provisioningProvider.GetInstanceCount() != 2)
                        {
                            provisioningProvider.SetInstanceCount(2);
                        }
                    }

                    // Wait a minute
                    Thread.Sleep(60000);
                }
            }));
            scalingThread.Start();
        }

        private IProvisioningProvider GetProvisioningProvider()
        {
            if (RoleEnvironment.IsAvailable
                && RoleEnvironment.CurrentRoleInstance.Id.ToLowerInvariant().StartsWith("deployment("))
            {
                return new DevFabricProvisioningProvider(RoleEnvironment.CurrentRoleInstance.Role.Name, "username", "password", "domain");
            }
            else if (RoleEnvironment.IsAvailable)
            {
                // we do not want to get billed for this demo...
                return new DummyProvisioningProvider();
            }

            return null;
        }
    }
                
}