﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Activation;

namespace TDD.ChristmasCreator.Web
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "CardDataService" in code, svc and config file together.
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class CardDataService : ICardDataService
    {
    
        public List<CardGreeting> GetAllCardGreetings()
        {
            // Add your operation implementation here
            return new List<CardGreeting>() 
            {
                new CardGreeting(){GreetingName="Simple Christmas wishes", GreetingText="Merry Christmas!"},
                new CardGreeting(){GreetingName="Simple New Year wishes", GreetingText="Happy New Year!"},
                new CardGreeting(){GreetingName="Long Christmas wishes", GreetingText="I wish you a very Merry Christmas!"},
                new CardGreeting(){GreetingName="Combined Christmas and New Year wishes", GreetingText="Merry Christmas and a Happy New Year!!"},
                new CardGreeting(){GreetingName="For partner wishes", GreetingText="Merry Christmas for my darling"}
            };
        }

        public List<CardColor> GetAllCardColors()
        {
            return new List<CardColor>() 
            {
                new CardColor(){ColorName="Azure", ColorCode="#FF007FFF"},
                new CardColor(){ColorName="Red", ColorCode="#FFFF0000"},
                new CardColor(){ColorName="Green", ColorCode="#FF00FF00"},
                new CardColor(){ColorName="Pink", ColorCode="#FFCF51E6"},
                new CardColor(){ColorName="Black", ColorCode="#FF000000"},
                new CardColor(){ColorName="White", ColorCode="#FFFFFFFF"}
            };
        }
    }

    [DataContract]
    public class CardGreeting
    {
        [DataMember]
        public string GreetingName { get; set; }

        [DataMember]
        public string GreetingText { get; set; }
    }

    [DataContract]
    //[KnownType(typeof(FancyCardColor))]
    public class CardColor
    {
        [DataMember]
        public string ColorName { get; set; }

        [DataMember]
        public string ColorCode { get; set; }
    }

    [DataContract]
    public class FancyCardColor : CardColor
    {
        [DataMember]
        public string FancyColorCode { get; set; }
    }
}
