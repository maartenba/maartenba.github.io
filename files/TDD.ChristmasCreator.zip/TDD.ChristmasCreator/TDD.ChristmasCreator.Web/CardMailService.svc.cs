﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.IO;
using System.Web;
using System.Configuration;
using System.ServiceModel.Activation;
using System.Net.Mail;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.StorageClient;

namespace TDD.ChristmasCreator.Web
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class CardMailService : ICardMailService
    {
        public string SendMailWithImage(CardToMail cardToMail)
        {
            string imageName = Guid.NewGuid().ToString() + ".png";

            try
            {
                //first save image to server disk
                SaveImageToDisk(cardToMail, imageName);

                //then send mail with link
                SendMail(cardToMail, imageName);

            }
            catch (Exception)
            {
                // Swallowing Exception...
            }
            return RoleEnvironment.GetConfigurationSettingValue("CardsRootUri") + imageName;
        }

        private static void SendMail(CardToMail cardToMail, string imageName)
        {
            MailMessage mailMessage = new MailMessage(cardToMail.SenderEmail, cardToMail.ReceiverEmail);

            mailMessage.Subject = "You got a card";
            mailMessage.SubjectEncoding = System.Text.Encoding.UTF8;
            StringBuilder builder = new StringBuilder();
            builder.Append("<html><body>");
            builder.Append("<a href=\"" + RoleEnvironment.GetConfigurationSettingValue("CardsRootUri") + imageName + "\">Click to view your card</a>");
            builder.Append("</body></html>");
            mailMessage.Body = builder.ToString();

            mailMessage.IsBodyHtml = true;

            SmtpClient smtp = CreateSmtpClient();

            smtp.Send(mailMessage);
        }

        private static SmtpClient CreateSmtpClient()
        {
            // Setup SMTP
            SmtpClient smtp = new SmtpClient();
            smtp.Credentials = new System.Net.NetworkCredential(
                RoleEnvironment.GetConfigurationSettingValue("SmtpUser"),
                RoleEnvironment.GetConfigurationSettingValue("SmtpPassword"));
            smtp.Port = int.Parse(RoleEnvironment.GetConfigurationSettingValue("SmtpPort"));
            smtp.Host = RoleEnvironment.GetConfigurationSettingValue("SmtpServer");
            smtp.EnableSsl = bool.Parse(RoleEnvironment.GetConfigurationSettingValue("SmtpUseSsl"));
            return smtp;
        }

        private static void SaveImageToDisk(CardToMail cardToMail, string imageName)
        {
            // Write image to memory stream
            using (MemoryStream stream = new MemoryStream())
            {
                using (BinaryWriter writer = new BinaryWriter(stream))
                {
                    writer.Write(cardToMail.Image);
                    stream.Seek(0, SeekOrigin.Begin);


                    // Save the image to blob storage
                    CloudStorageAccount account =
                        CloudStorageAccount.FromConfigurationSetting("CardsConnectionString");

                    CloudBlobClient blobClient =
                        account.CreateCloudBlobClient();
                    CloudBlobContainer blobContainer =
                        blobClient.GetContainerReference("cards");

                    BlobContainerPermissions permissions = new BlobContainerPermissions();
                    blobContainer.CreateIfNotExist();
                    permissions.PublicAccess = BlobContainerPublicAccessType.Blob;
                    blobContainer.SetPermissions(permissions);

                    CloudBlob blob = blobContainer.GetBlobReference(imageName);
                    blob.UploadFromStream(stream);
                }
            }
        }
    }
}
