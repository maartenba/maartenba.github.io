﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace TDD.ChristmasCreator.Web
{
    [DataContract]
    public class CardToMail
    {
        [DataMember]
        public string ReceiverName { get; set; }

        [DataMember]
        public string ReceiverEmail { get; set; }

        [DataMember]
        public string SenderName { get; set; }

        [DataMember]
        public string SenderEmail { get; set; }

        [DataMember]
        public DateTime SendDate { get; set; }

        [DataMember]
        public byte[] Image { get; set; }
    }
}