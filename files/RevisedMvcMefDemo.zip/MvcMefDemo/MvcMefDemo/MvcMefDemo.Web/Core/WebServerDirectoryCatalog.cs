﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.ComponentModel.Composition.Primitives;
using System.ComponentModel.Composition.Hosting;

namespace MvcMefDemo.Web.Core
{
    public sealed class WebServerDirectoryCatalog : ComposablePartCatalog
    {
        private FileSystemWatcher fileSystemWatcher;
        private DirectoryCatalog directoryCatalog;
        private string path;
        private string extension;

        public WebServerDirectoryCatalog(string path, string extension, string modulePattern)
        {
            Initialize(path, extension, modulePattern);
        }

        private void Initialize(string path, string extension, string modulePattern)
        {
            this.path = path;
            this.extension = extension;

            fileSystemWatcher = new FileSystemWatcher(path, modulePattern);
            fileSystemWatcher.Changed += new FileSystemEventHandler(fileSystemWatcher_Changed);
            fileSystemWatcher.Created += new FileSystemEventHandler(fileSystemWatcher_Created);
            fileSystemWatcher.Deleted += new FileSystemEventHandler(fileSystemWatcher_Deleted);
            fileSystemWatcher.Renamed += new RenamedEventHandler(fileSystemWatcher_Renamed);
            fileSystemWatcher.IncludeSubdirectories = false;
            fileSystemWatcher.EnableRaisingEvents = true;

            Refresh();
        }

        void fileSystemWatcher_Renamed(object sender, RenamedEventArgs e)
        {
            RemoveFromBin(e.OldName);
            Refresh();
        }

        void fileSystemWatcher_Deleted(object sender, FileSystemEventArgs e)
        {
            RemoveFromBin(e.Name);
            Refresh();
        }

        void fileSystemWatcher_Created(object sender, FileSystemEventArgs e)
        {
            Refresh();
        }

        void fileSystemWatcher_Changed(object sender, FileSystemEventArgs e)
        {
            Refresh();
        }

        private void Refresh()
        {
            // Determine /bin path
            string binPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "bin");

            // Copy files to /bin
            foreach (string file in Directory.GetFiles(path, extension, SearchOption.TopDirectoryOnly))
            {
                try
                {
                    File.Copy(file, Path.Combine(binPath, Path.GetFileName(file)), true);
                }
                catch
                {
                    // Not that big deal...
                }
            }

            // Create new directory catalog
            directoryCatalog = new DirectoryCatalog(binPath, extension);
        }

        public override IQueryable<ComposablePartDefinition> Parts
        {
            get { return directoryCatalog.Parts; }
        }


        private void RemoveFromBin(string name)
        {
            string binPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "bin");
            File.Delete(Path.Combine(binPath, name));
        }
    }
}
