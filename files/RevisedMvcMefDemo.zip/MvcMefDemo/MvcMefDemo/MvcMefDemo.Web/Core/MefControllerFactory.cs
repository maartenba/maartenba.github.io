﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;

namespace MvcMefDemo.Web.Core
{
    public class MefControllerFactory : IControllerFactory
    {
        private string pluginPath;
        private WebServerDirectoryCatalog catalog;
        private CompositionContainer container;

        private DefaultControllerFactory defaultControllerFactory;

        public MefControllerFactory(string pluginPath)
        {
            this.pluginPath = pluginPath;
            this.catalog = new WebServerDirectoryCatalog(pluginPath, "*.dll", "*.dll");
            this.container = new CompositionContainer(catalog);

            this.defaultControllerFactory = new DefaultControllerFactory();
        }

        #region IControllerFactory Members

        public IController CreateController(System.Web.Routing.RequestContext requestContext, string controllerName)
        {
            IController controller = null;

            if (controllerName != null)
            {
                Export<IController> export = this.container.GetExports<IController>()
                                                 .Where(c => c.Metadata.ContainsKey("ControllerName")
                                                     && c.Metadata["ControllerName"].ToString() == controllerName)
                                                 .FirstOrDefault();
                if (export != null)
                {
                    controller = export.GetExportedObject();
                }
            }

            if (controller == null)
            {
                return this.defaultControllerFactory.CreateController(requestContext, controllerName);
            }

            requestContext.HttpContext.Items["MEF_CONTROLLER_EXPORT"] = controller;
            return controller;
        }


        public void ReleaseController(IController controller)
        {
            var export = HttpContext.Current.Items["MEF_CONTROLLER_EXPORT"] as Export<IController>;
            if (export != null)
            {
                this.container.ReleaseExport(export);
            }
            else
            {
                IDisposable disposable = controller as IDisposable;
                if (disposable != null)
                {
                    disposable.Dispose();
                }
            }
        }

        #endregion
    }
}
