﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcMefDemo.Web.Core
{
    public class AlternateLocationViewEngine : WebFormViewEngine
    {
        public AlternateLocationViewEngine(string[] masterLocations, string[] viewLocations)
        {
            MasterLocationFormats = masterLocations;
            ViewLocationFormats = viewLocations;
            PartialViewLocationFormats = ViewLocationFormats;
        }
    }
}
