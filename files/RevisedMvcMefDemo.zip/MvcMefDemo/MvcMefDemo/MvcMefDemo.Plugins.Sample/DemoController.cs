﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.ComponentModel.Composition;
using MvcMefDemo.Plugins.Sample.Models;

namespace MvcMefDemo.Plugins.Sample
{
    [Export(typeof(IController))]
    [ExportMetadata("controllerName", "Demo")]
    [PartCreationPolicy(CreationPolicy.NonShared)]
    public class DemoController : Controller
    {
        public ActionResult Index()
        {
            return View(new DemoModel { DemoProperty = "Foo" });
        }
    }
}
