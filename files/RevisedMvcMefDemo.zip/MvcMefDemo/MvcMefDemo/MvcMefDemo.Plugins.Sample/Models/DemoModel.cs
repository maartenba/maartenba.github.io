﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MvcMefDemo.Plugins.Sample.Models
{
    public class DemoModel
    {
        public string DemoProperty { get; set; }
    }
}
