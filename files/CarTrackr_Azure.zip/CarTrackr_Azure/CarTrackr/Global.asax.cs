﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using CarTrackr.Data;
using System.Data.Linq;
using CarTrackr.Domain;
using Microsoft.Practices.Unity;
using CarTrackr.Core;
using CarTrackr.Controllers;
using System.Web.Security;
using CarTrackr.Repository;
using Microsoft.Samples.ServiceHosting.StorageClient;

namespace CarTrackr
{
    public class MvcApplication : System.Web.HttpApplication
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                "CarDetails",                                                   
                "Car/{licensePlate}/{action}",                                 
                new { controller = "Car", action = "List", licensePlate = "" },
                new { licensePlate = @"(.+)" } 
            );

            routes.MapRoute(
                "CarRefuellings",
                "Car/{licensePlate}/Refuelling/{action}",
                new { controller = "Refuelling", action = "Index", licensePlate = "" },
                new { licensePlate = @"(.+)" } 
            );

            routes.MapRoute(
                "Default",                                              // Route name
                "{controller}/{action}/{id}",                           // URL with parameters
                new { controller = "Home", action = "Index", id = "" }  // Parameter defaults
            );
        }

        protected void Application_Start()
        {
            RegisterRoutes(RouteTable.Routes);
            RegisterDependencies();
        }


        protected static bool tablesRegistered = false;
        protected static object syncLock = "";

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            if (!tablesRegistered)
            {
                lock (syncLock)
                {
                    if (!tablesRegistered)
                    {
                        StorageAccountInfo account = StorageAccountInfo.GetDefaultTableStorageAccountFromConfiguration();

                        try {
                            TableStorage.CreateTablesFromModel(typeof(CarTrackr.Data.CarTrackrCloudContext), account);
                            tablesRegistered = true;
                        }
                        catch (Exception ex) {
                            throw new ApplicationException(
                                string.Format("There was a problem creating table storage on {0} (account name {1})", account.BaseUri.ToString(), account.AccountName), 
                                ex);
                        }
                    }
                }
            }
        }

        protected static void RegisterDependencies() {
            IUnityContainer container = new UnityContainer();

            // Registrations
            container.RegisterType<IFormsAuthentication, FormsAuthenticationWrapper>();

            container.RegisterType<CarTrackrData, CarTrackrData>(new ContextLifetimeManager<CarTrackrData>());
            container.RegisterType<ICarRepository, CarRepository>(new ContextLifetimeManager<ICarRepository>());
            container.RegisterType<IUserRepository, UserRepository>(new ContextLifetimeManager<IUserRepository>());
            container.RegisterType<IRefuellingRepository, RefuellingRepository>(new ContextLifetimeManager<IRefuellingRepository>());
            container.RegisterType<ICostsRepository, CostsRepository>(new ContextLifetimeManager<ICostsRepository>());

            // Set controller factory
            ControllerBuilder.Current.SetControllerFactory(
                new UnityControllerFactory(container)    
            );
        }
    }
}