﻿using System.Data.Services.Client;
using CarTrackr.Domain;
using Microsoft.Samples.ServiceHosting.StorageClient;
using System.Linq;

namespace CarTrackr.Data
{
    public class CarTrackrCloudContext : TableStorageDataServiceContext
    {
        internal CarTrackrCloudContext(StorageAccountInfo accountInfo)
        : base(accountInfo)
        {
        }

        public IQueryable<Car> Cars
        {
            get
            {
                return CreateQuery<Car>("Cars");
            }
        }

        public IQueryable<Refuelling> Refuellings
        {
            get
            {
                return CreateQuery<Refuelling>("Refuellings");
            }
        }

        public IQueryable<User> Users
        {
            get
            {
                return CreateQuery<User>("Users");
            }
        }
    }
}
