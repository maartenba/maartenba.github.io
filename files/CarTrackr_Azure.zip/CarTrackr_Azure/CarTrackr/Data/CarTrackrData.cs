﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Linq;
using CarTrackr.Domain;
using Microsoft.Samples.ServiceHosting.StorageClient;

namespace CarTrackr.Data
{
    public class CarTrackrData
    {
        private CarTrackrCloudContext dataContext;

        public CarTrackrCloudContext DataContext
        { 
            get {
                if (dataContext == null)
                {
                    StorageAccountInfo account = StorageAccountInfo.GetDefaultTableStorageAccountFromConfiguration();
                    dataContext = new CarTrackrCloudContext(account);
                    dataContext.RetryPolicy = RetryPolicies.RetryN(3, TimeSpan.FromSeconds(1));
                }

                return dataContext;
            }
        }
    }
}
