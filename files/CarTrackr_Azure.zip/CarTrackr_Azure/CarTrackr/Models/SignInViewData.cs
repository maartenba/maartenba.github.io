﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CarTrackr.Models
{
    public class SignInViewData
    {
        public string AppId { get; set; }
        public string UserId { get; set; }
    }
}
