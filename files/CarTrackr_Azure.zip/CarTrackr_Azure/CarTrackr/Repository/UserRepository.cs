﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CarTrackr.Data;
using CarTrackr.Domain;
using Microsoft.Samples.ServiceHosting.StorageClient;
using System.Data.Services.Client;

namespace CarTrackr.Repository
{
    public class UserRepository : IDataBoundRepository, IUserRepository
    {
        #region Constructor

        public UserRepository(CarTrackrData dataSource)
        {
            DataSource = dataSource;
        }

        #endregion

        #region IDataBoundRepository Members

        public CarTrackrData DataSource { get; set; }

        #endregion

        #region IUserRepository Members

        public User RetrieveByUserName(string userName)
        {
            return DataSource.DataContext.Users.Where(u => u.UserName == userName).SingleOrDefault();
        }

        public void Add(User user)
        {
            user.EnsureValid();

            DataSource.DataContext.AddObject("Users", user);
            DataSource.DataContext.SaveChanges();
        }

        #endregion
    }
}
