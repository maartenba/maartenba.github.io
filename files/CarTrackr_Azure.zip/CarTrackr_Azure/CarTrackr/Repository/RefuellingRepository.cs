﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CarTrackr.Data;
using CarTrackr.Domain;

namespace CarTrackr.Repository
{
    public class RefuellingRepository : IDataBoundRepository, IRefuellingRepository
    {
        #region Constructor

        public RefuellingRepository(CarTrackrData dataSource)
        {
            DataSource = dataSource;
        }

        #endregion

        #region IDataBoundRepository Members

        public CarTrackrData DataSource { get; set; }

        #endregion

        #region IRefuellingRepository Members

        public List<Refuelling> List(Car car)
        {
            return DataSource.DataContext.Refuellings.Where(r => r.CarId == car.RowKey).ToList().OrderBy(r => r.Date).ToList();
        }

        public Refuelling RetrieveById(Guid id)
        {
            return DataSource.DataContext.Refuellings.Where(r => r.RowKey == id.ToString()).SingleOrDefault();
        }

        public void Add(Refuelling refuelling)
        {
            refuelling.EnsureValid();

            DataSource.DataContext.AddObject("Refuellings", refuelling);
            DataSource.DataContext.SaveChanges();
        }

        public void Update(Refuelling refuelling)
        {
            refuelling.EnsureValid();

            DataSource.DataContext.UpdateObject(refuelling);
            DataSource.DataContext.SaveChanges();
        }

        public void Remove(Refuelling refuelling)
        {
            DataSource.DataContext.DeleteObject(refuelling);
            DataSource.DataContext.SaveChanges();
        }

        #endregion
    }
}
