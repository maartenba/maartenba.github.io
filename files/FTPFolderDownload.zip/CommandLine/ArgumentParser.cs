using System;
using System.Collections.Generic;
using System.Text;

namespace FTPFolderDownload.CommandLine
{
    public class ArgumentParser
    {
        /// <summary>
        /// Parse command-line arguments into a IDictionary
        /// </summary>
        /// <param name="args">Command-line arguments array</param>
        /// <returns>IDictionary with parsed commands</returns>
        public static IDictionary<string, string> ParseArguments(object[] args)
        {
            // Returnvalue
            IDictionary<string, string> returnValue = new Dictionary<string, string>();

            // Parse arguments
            foreach (object arg in args)
            {
                // Parse argument name
                if (arg.ToString().StartsWith("/"))
                {
                    string tmp = arg.ToString().Substring(1);
                    string[] tmpArray = tmp.Split('=');

                    if (tmpArray.Length > 1) {
                        returnValue.Add(new KeyValuePair<string,string>(tmpArray[0], tmpArray[1].Replace("\"", "")));
                    } else {
                        returnValue.Add(new KeyValuePair<string,string>(tmpArray[0], ""));
                    }
                }
            }

            // Return
            return returnValue;
        }
    }
}
