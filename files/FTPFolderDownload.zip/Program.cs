using System;
using System.Collections.Generic;
using System.Text;

using FTPFolderDownload.CommandLine;
using FTPFolderDownload.Commands;

namespace FTPFolderDownload
{
    class Program
    {
        static void Main(string[] args)
        {
            // Print header
            ICommand headerCommand = new HeaderCommand();
            headerCommand.Execute();

            // Download command
            DownloadCommand downloadCommand = new DownloadCommand();

            // Parse arguments
            IDictionary<string, string> arguments = ArgumentParser.ParseArguments(args);

            // Loop trough arguments and decide action to perform
            foreach (KeyValuePair<string, string> argument in arguments)
            {
                // Help?
                if (argument.Key == "?")
                {
                    ICommand helpCommand = new HelpCommand();
                    helpCommand.Execute();
                    break;
                }

                // Other parameter type?
                downloadCommand.setPropertyByName(argument.Key, argument.Value);
            }

            // Can download command be executed?
            if (downloadCommand.IsExecutable)
            {
                downloadCommand.Execute();
            }

#if DEBUG
            Console.Out.WriteLine("--- Press enter to continue... ---");
            Console.ReadLine();
#endif
        }
    }
}
