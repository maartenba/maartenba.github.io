using System;
using System.Collections.Generic;
using System.Text;

namespace FTPFolderDownload.Commands
{
    public class HelpCommand : ICommand
    {
        #region ICommand Members

        public void Execute()
        {
            Console.WriteLine("List of arguments:");
            Console.WriteLine("\t/server=\"<server hostname>\"");
            Console.WriteLine("\t/username=\"<username>\"");
            Console.WriteLine("\t/password=\"<password>\"");
            Console.WriteLine("\t/remoteFolder=\"<remote folder>\"");
            Console.WriteLine("\t/localFolder=\"<local folder>\"");
            Console.WriteLine("\t/recursive");
        }

        #endregion
    }
}
