using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Net;

using FTPFolderDownload.FTP;
using System.IO;

namespace FTPFolderDownload.Commands
{
    public class DownloadCommand : ICommand
    {
        #region Private members

        private string _server;
        private string _username;
        private string _password;
        private string _remoteFolder;
        private string _localFolder;
        private bool _recursive;

        #endregion

        #region Public properties

        /// <summary>
        /// Server hostname
        /// </summary>
        public string Server
        {
            get { return _server; }
            set { _server = value; }
        }

        /// <summary>
        /// Username
        /// </summary>
        public string Username
        {
            get { return _username; }
            set { _username = value; }
        }

        /// <summary>
        /// Password
        /// </summary>
        public string Password
        {
            get { return _password; }
            set { _password = value; }
        }

        /// <summary>
        /// Remote folder
        /// </summary>
        public string RemoteFolder
        {
            get { return _remoteFolder; }
            set { _remoteFolder = value; }
        }

        /// <summary>
        /// Local folder
        /// </summary>
        public string LocalFolder
        {
            get { return _localFolder; }
            set { _localFolder = value; }
        }

        /// <summary>
        /// Download recursive?
        /// </summary>
        public bool Recursive
        {
            get { return _recursive; }
            set { _recursive = value; }
        }

        /// <summary>
        /// Is the current DownloadCommand ready for execution?
        /// </summary>
        public bool IsExecutable
        {
            get
            {
                return (
                       !String.IsNullOrEmpty(_server)
                    && !String.IsNullOrEmpty(_username)
                    && !String.IsNullOrEmpty(_password)
                    && !String.IsNullOrEmpty(_remoteFolder)
                    && !String.IsNullOrEmpty(_localFolder)
                );
            }
        }

        #endregion

        #region Public methods

        public void setPropertyByName(string key, string value)
        {
            // Switch on key
            switch (key.ToLower())
            {
                case "server":
                    _server = value;
                    break;
                case "username":
                    _username = value;
                    break;
                case "password":
                    _password = value;
                    break;
                case "remotefolder":
                    _remoteFolder = value;
                    break;
                case "localfolder":
                    _localFolder = value;
                    break;
                case "recursive":
                    _recursive = true;
                    break;
                default: throw new ArgumentException("Non-existing property referenced", "key");
            }
        }

        #endregion

        #region Private methods

        private void _downloadFTPFolderRecursive(FTPclient client, string remoteFolder, string localFolder, bool recursive)
        {
            // Get list of folders/files and download them 
            FTPdirectory remoteFolderInfo = client.ListDirectoryDetail(remoteFolder);
            foreach (FTPfileInfo fileInfo in remoteFolderInfo)
            {
                // Download file 
                if (fileInfo.FileType == FTPfileInfo.DirectoryEntryTypes.File)
                {
                    Console.WriteLine("Downloading file " + fileInfo.FullName + "...");
                    client.Download(fileInfo, localFolder + fileInfo.FullName.Replace(remoteFolder, ""), true);
                    Console.WriteLine("Downloaded " + fileInfo.FullName + ".");
                }
                else if (fileInfo.FileType == FTPfileInfo.DirectoryEntryTypes.Directory)
                {
                    // Recursive download? 
                    if (recursive)
                    {
                        // Folder exists? If not, create it! 
                        string benoetigterOrdner = localFolder + fileInfo.FullName.Replace(remoteFolder, "");
                        if (!Directory.Exists(benoetigterOrdner))
                        {
                            string newFolder = localFolder + fileInfo.FullName.Replace(remoteFolder, "");
                            Directory.CreateDirectory(newFolder);
                        }

                        // Download folder 
                        Console.WriteLine("Downloading folder " + fileInfo.FullName + "...");
                        _downloadFTPFolderRecursive(client, fileInfo.FullName, localFolder + fileInfo.FullName.Replace(remoteFolder, ""), recursive);
                        Console.WriteLine("Downloaded folder " + fileInfo.FullName + ".");
                    }
                }
            }
        } 

        #endregion

        #region ICommand Members

        public void Execute()
        {
            // Create FTP client
            FTPclient client = new FTPclient(_server, _username, _password);

            // Browse to remote folder
            client.CurrentDirectory = _remoteFolder;

            // Download remote folder
            _downloadFTPFolderRecursive(client, _remoteFolder, _localFolder, _recursive);
        }

        #endregion
    }
}