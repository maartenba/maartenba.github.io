using System;
using System.Collections.Generic;
using System.Text;

namespace FTPFolderDownload.Commands
{
    public interface ICommand
    {
        void Execute();
    }
}
