using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace FTPFolderDownload.Commands
{
    public class HeaderCommand : ICommand
    {
        #region ICommand Members

        public void Execute()
        {
            string headerString = "FTPFolderDownload - Version " + Assembly.GetExecutingAssembly().GetName().Version.ToString();

            Console.WriteLine(headerString);
            Console.WriteLine(new String('-', headerString.Length));
        }

        #endregion
    }
}
