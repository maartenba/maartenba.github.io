using System;
using System.Collections.Generic;

public class StateServers
{

    #region Private static members

    private static IList<StateServer> stateServers;

    #endregion

    #region Public static properties

    public static IList<StateServer> List
    {
        get
        {
            if (null == stateServers)
            {
                stateServers = new List<StateServer>();
                stateServers.Add(new StateServer("tcpip=127.0.0.1:42424", "."));
                stateServers.Add(new StateServer("tcpip=localhost:42424", "."));
            }

            return stateServers;
        }
    }

    #endregion

}
