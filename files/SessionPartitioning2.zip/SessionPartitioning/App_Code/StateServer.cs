using System;

public class StateServer
{
    #region Private members

    private string connectionString;
    private string serverName;

    #endregion

    #region Constructors

    public StateServer(string connectionString, string serverName)
    {
        this.connectionString = connectionString;
        this.serverName = serverName;
    }

    #endregion

    #region Public properties

    public string ConnectionString
    {
        get
        {
            return connectionString;
        }
    }

    public string ServerName
    {
        get
        {
            return serverName;
        }
    }

    #endregion
}
