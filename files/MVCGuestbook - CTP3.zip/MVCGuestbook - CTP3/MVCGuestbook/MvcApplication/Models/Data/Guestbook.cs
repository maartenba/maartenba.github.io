using System.Collections.Generic;
using MvcApplication.Models.Data;

namespace MvcApplication.Models.Data
{
    partial class GuestbookDataContext
    {
        public List<Guestbook> GetGuestbooks()
        {
            List<Guestbook> returnValue = new List<Guestbook>();
            foreach (Guestbook guestBook in Guestbooks)
            {
                returnValue.Add(guestBook);
            }
            return returnValue;
        }

        public void AddEntry(Entry entry)
        {
            Entries.InsertOnSubmit(entry);
        }
    }
}
