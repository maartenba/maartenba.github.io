﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace MvcApplication.Controllers
{
    public class LoginController : Controller
    {

        #region Properties

        private MembershipProvider membershipProvider;

        public MembershipProvider MembershipProviderInstance {
            get {
                return membershipProvider ?? Membership.Provider;
            } 
            set { membershipProvider = value; }
        }

        #endregion

        public ActionResult Index()
        {
            // Render index page
            return View("Index");
        }

        public ActionResult Authenticate(string Username, string Password)
        {
            // Authenticate
            if (MembershipProviderInstance.ValidateUser(Username, Password))
            {
                // Set authentication cookie
                try
                {
                    FormsAuthentication.SetAuthCookie(Username, false);
                }
                catch { } // Expected in unit test...

                // Return URL set?
                if (null != Request["returnUrl"] && !string.IsNullOrEmpty(Request["returnUrl"]))
                {
                    return Redirect(Server.UrlDecode(Request["returnUrl"]));
                }

                // Redirect to home
                return RedirectToAction("Index", "Home");
            }
            else
            {
                // Set error...
                ViewData.Add("ErrorMessage", "Invalid credentials! Please verify your username and password.");
                
                // Render index page
                return View("Index");
            }
        }

        public ActionResult Logout()
        {
            // Clear authentication cookie
            try {
                FormsAuthentication.SignOut();
            }
            catch { } // Expected in unit test...

            // Redirect to home
            return RedirectToAction("Index", "Home");
        }
    }
}
