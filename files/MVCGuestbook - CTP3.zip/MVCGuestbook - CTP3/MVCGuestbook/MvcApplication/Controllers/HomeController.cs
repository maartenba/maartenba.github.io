﻿using System;
using System.Web;
using System.Web.Mvc;
using MvcApplication.Models.Data;
using MvcApplication.Models.ViewData;

namespace MvcApplication.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            GuestbookDataContext ctx = new GuestbookDataContext();

            GuestbooksOverview viewData = new GuestbooksOverview
            {
                Guestbooks = ctx.GetGuestbooks()
            };

            return View("Index", viewData);
        }

        public ActionResult About()
        {
            return View("About");
        }
    }
}