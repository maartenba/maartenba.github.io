﻿using System.Text;
using System.Web.Mvc;
using System.Reflection;
using System;

namespace MaartenBalliauw.Mvc.Extensions
{
    public static class CacheExtensions
    {
        public static string Substitution<T>(this HtmlHelper helper, string method)
        {
            // Check input
            if (typeof(T).GetMethod(method, BindingFlags.Static | BindingFlags.Public) == null)
            {
                throw new ArgumentException(
                    string.Format("Type {0} does not implement a static method named {1}.",
                        typeof(T).FullName, method),
                            "method");
            }

            // Write output
            StringBuilder sb = new StringBuilder();

            sb.Append("<!--");
            sb.Append("SUBSTITUTION:");
            sb.Append(typeof(T).FullName);
            sb.Append(":");
            sb.Append(method);
            sb.Append("-->");

            return sb.ToString();
        }
    }
}
