﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcCaching.Views.Home
{
    public partial class Index : ViewPage
    {
        public static string SubstituteDate(ControllerContext context)
        {
            return DateTime.Now.ToString();
        }
    }
}
