﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CustomViewEngine.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            // Simple text
            ViewData["Title"] = "Home Page";
            ViewData["Message"] = "Welcome to ASP.NET MVC!";

            // An array of values
            ViewData["FruitStrings"] = new string[] { "Apple", "Pear", "Banana" };

            // Classes
            ViewData["FruitObjects"] = new [] {
                new { Name = "Apple" },
                new { Name = "Pear" },
                new { Name = "Banana" }
            };

            return RenderView();
        }
    }
}
