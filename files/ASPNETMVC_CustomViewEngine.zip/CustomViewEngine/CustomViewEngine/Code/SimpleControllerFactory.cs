﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace CustomViewEngine.Code
{
    public class SimpleControllerFactory : DefaultControllerFactory
    {
        protected override IController CreateController(RequestContext requestContext, string controllerName)
        {
            Controller controller = (Controller)base.CreateController(requestContext, controllerName);
            controller.ViewEngine = new SimpleViewEngine();
            return controller;
        }
    }
}
