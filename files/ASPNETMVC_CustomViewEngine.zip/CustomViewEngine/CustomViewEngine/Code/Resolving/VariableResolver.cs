﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text.RegularExpressions;
using System.Reflection;

namespace CustomViewEngine.Code.Resolving
{
    public static class VariableResolver
    {
        public static object Resolve(string sourceString, object sourceObject)
        {
            // Setup regular expressions engine
            Regex templatePattern = new Regex(@"(\$\w+((\.|\[)\w+\]?)*)", RegexOptions.Multiline);

            object resolvedObject = null;
            MatchEvaluator replaceCallback = new MatchEvaluator(
                delegate(Match m) {
                    // Split expression
                    string[] expressions = m.Value.Replace("{", "")
                                                  .Replace("$", "")
                                                  .Replace("}", "")
                                                  .Replace("[", ".")
                                                  .Replace("]", "")
                                                  .Split('.');

                    // Loop expressions
                    object lastObject = sourceObject;
                    string expression = "";
                    for (int i = 0; i < expressions.Length; i++)
                    {
                        expression = expressions[i];

                        if (lastObject != null)
                        {
                            if (lastObject is IDictionary)
                            {
                                lastObject = ((IDictionary)lastObject)[expression];
                            }
                            else if (lastObject is Array)
                            {
                                lastObject = ((Array)lastObject).GetValue(int.Parse(expression));
                            }
                            else
                            {
                                try
                                {
                                    lastObject = lastObject.GetType().InvokeMember(expression, BindingFlags.Instance | BindingFlags.Public | BindingFlags.GetField | BindingFlags.GetProperty, null, lastObject, null);
                                }
                                catch (MissingMethodException)
                                {
                                    lastObject = string.Format("Undefined: {0}", m.Value);
                                }
                            }
                        }
                    }

                    if (lastObject != null)
                    {
                        resolvedObject = lastObject;
                    }

                    return resolvedObject.ToString();
                }
            );

            // Fire up replacement engine!
            templatePattern.Replace(sourceString, replaceCallback);
            return resolvedObject;
        }
    }
}
