﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace CustomViewEngine.Code
{
    public class SimpleViewLocator : ViewLocator
    {
        public SimpleViewLocator()
        {
            base.ViewLocationFormats = new string[] { "~/Views/{1}/{0}.htm",
                                                      "~/Views/{1}/{0}.html",
                                                      "~/Views/Shared/{0}.htm",
                                                      "~/Views/Shared/{0}.html"
            };
            base.MasterLocationFormats = new string[] { "" };
        }
    }
}
