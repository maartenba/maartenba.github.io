﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using CustomViewEngine.Code.Rendering;

namespace CustomViewEngine.Code
{
    public class SimpleViewEngine : IViewEngine
    {
        #region Private members

        IViewLocator _viewLocator = null;

        #endregion

        #region IViewEngine Members

        public void RenderView(ViewContext viewContext)
        {
            string viewLocation = ViewLocator.GetViewLocation(viewContext, viewContext.ViewName);
            if (string.IsNullOrEmpty(viewLocation))
            {
                throw new InvalidOperationException(string.Format("View {0} could not be found.", viewContext.ViewName));
            }

            string viewPath = viewContext.HttpContext.Request.MapPath(viewLocation);
            string viewTemplate = File.ReadAllText(viewPath);

            IRenderer renderer = new PrintRenderer();
            viewTemplate = renderer.Render(viewTemplate, viewContext);

            viewContext.HttpContext.Response.Write(viewTemplate);
        }

        #endregion

        #region Public properties

        public IViewLocator ViewLocator
        {
            get
            {
                if (this._viewLocator == null)
                {
                    this._viewLocator = new SimpleViewLocator();
                }
                return this._viewLocator;
            }
            set
            {
                this._viewLocator = value;
            }
        }

        #endregion
    }
}
