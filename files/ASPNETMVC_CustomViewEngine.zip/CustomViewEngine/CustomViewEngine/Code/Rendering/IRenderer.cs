﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CustomViewEngine.Code.Rendering
{
    public interface IRenderer
    {
        string Render(string viewTemplate, object data);
    }
}
