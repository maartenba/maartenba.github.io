﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text.RegularExpressions;
using System.Reflection;
using CustomViewEngine.Code.Resolving;

namespace CustomViewEngine.Code.Rendering
{
    public class PrintRenderer : IRenderer
    {
        #region IRenderer Members

        public string Render(string viewTemplate, object data)
        {
            Regex templatePattern = new Regex(@"({\$\w+((\.|\[)\w+\]?)*})", RegexOptions.Multiline);
            MatchEvaluator replaceCallback = new MatchEvaluator(m => VariableResolver.Resolve(m.Value, data).ToString());
            return templatePattern.Replace(viewTemplate, replaceCallback);
        }

        #endregion
    }
}
